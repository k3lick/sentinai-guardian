import type { ReactNode } from "react";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

export function PageHeader({
  title,
  subtitle,
  action,
}: {
  title: string;
  subtitle?: string;
  action?: ReactNode;
}) {
  return (
    <div className="flex flex-wrap items-start justify-between gap-3">
      <div>
        <h1 className="text-lg font-semibold tracking-tight">{title}</h1>
        {subtitle ? <p className="mt-0.5 max-w-2xl text-sm text-muted-foreground">{subtitle}</p> : null}
      </div>
      {action ? <div className="flex flex-wrap items-center gap-2">{action}</div> : null}
    </div>
  );
}

export function StatCard({
  label,
  value,
  hint,
  tone = "muted",
  icon,
}: {
  label: string;
  value: ReactNode;
  hint?: string;
  tone?: "muted" | "primary" | "success" | "warning" | "destructive";
  icon?: ReactNode;
}) {
  return (
    <div className="rounded-xl border border-border bg-card/70 p-4">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground">{label}</div>
          <div className="mt-1 tabular text-2xl font-semibold tracking-tight">{value}</div>
          {hint ? <div className="mt-1 text-xs text-muted-foreground">{hint}</div> : null}
        </div>
        {icon ? (
          <span
            className={cn(
              "grid size-8 place-items-center rounded-md border",
              tone === "destructive" && "border-destructive/30 bg-destructive/10 text-destructive",
              tone === "warning" && "border-warning/30 bg-warning/10 text-warning",
              tone === "success" && "border-success/30 bg-success/10 text-success",
              tone === "primary" && "border-primary/30 bg-primary/10 text-primary",
              tone === "muted" && "border-border bg-muted text-muted-foreground",
            )}
          >
            {icon}
          </span>
        ) : null}
      </div>
    </div>
  );
}

export function Panel({
  title,
  subtitle,
  action,
  children,
  className,
}: {
  title?: string;
  subtitle?: string;
  action?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <section className={cn("rounded-xl border border-border bg-card/70 p-4", className)}>
      {title ? (
        <div className="mb-3 flex flex-wrap items-start justify-between gap-2">
          <div>
            <h2 className="text-sm font-semibold">{title}</h2>
            {subtitle ? <p className="text-xs text-muted-foreground">{subtitle}</p> : null}
          </div>
          {action}
        </div>
      ) : null}
      {children}
    </section>
  );
}

export function EmptyState({
  title,
  body,
  children,
}: {
  title: string;
  body: string;
  children?: ReactNode;
}) {
  return (
    <div className="rounded-lg border border-dashed border-border bg-background/40 px-4 py-6 text-center">
      <div className="text-sm font-medium">{title}</div>
      <p className="mx-auto mt-1 max-w-md text-sm text-muted-foreground">{body}</p>
      {children ? <div className="mt-3 flex flex-wrap justify-center gap-2">{children}</div> : null}
    </div>
  );
}

export function StatusBadge({
  status,
}: {
  status:
    | "healthy"
    | "degraded"
    | "offline"
    | "unknown"
    | "clean"
    | "flagged"
    | "quarantined"
    | "released"
    | "blocked"
    | "false_positive";
}) {
  const map: Record<string, { label: string; tone: "success" | "warning" | "destructive" | "muted" | "primary" }> = {
    healthy: { label: "Healthy", tone: "success" },
    degraded: { label: "Degraded", tone: "warning" },
    offline: { label: "Offline / Failed", tone: "destructive" },
    unknown: { label: "Not probed", tone: "muted" },
    clean: { label: "Clean", tone: "success" },
    flagged: { label: "Flagged", tone: "warning" },
    quarantined: { label: "Quarantined", tone: "destructive" },
    released: { label: "Released to ingestion", tone: "success" },
    blocked: { label: "Blocked & archived", tone: "destructive" },
    false_positive: { label: "False positive", tone: "muted" },
  };
  const item = map[status] ?? { label: status, tone: "muted" as const };
  return (
    <Badge tone={item.tone} dot>
      {item.label}
    </Badge>
  );
}
