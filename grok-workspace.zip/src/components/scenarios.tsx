import { Link } from "@tanstack/react-router";
import { Play, X } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { SCENARIOS, type ScenarioId, useSentinai } from "@/lib/sentinai/store";
import { formatTime } from "@/lib/utils";

export function ScenarioLauncher() {
  const open = useSentinai((s) => s.launcherOpen);
  const setOpen = useSentinai((s) => s.setLauncherOpen);
  const run = useSentinai((s) => s.runScenario);
  const running = useSentinai((s) => s.runningScenario);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-background/70 p-4 sm:items-center">
      <div className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-xl border border-border bg-card p-5 shadow-2xl">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h2 className="text-base font-semibold">Security Ops Sandbox</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              Play a realistic story through the whole product surface. Every scenario writes real state: documents,
              alerts, incidents, policy decisions and audit records.
            </p>
          </div>
          <Button variant="ghost" size="icon" onClick={() => setOpen(false)} aria-label="Close">
            <X className="size-4" />
          </Button>
        </div>
        <div className="mt-4 grid gap-2">
          {SCENARIOS.map((s) => (
            <button
              key={s.id}
              disabled={Boolean(running)}
              onClick={() => void run(s.id)}
              className="rounded-lg border border-border bg-background/50 p-3 text-left transition-colors hover:border-primary/40 hover:bg-accent/40 disabled:opacity-50"
            >
              <div className="flex flex-wrap items-center gap-2">
                <Badge tone={s.tone}>{s.title}</Badge>
                {running === s.id ? <Badge tone="primary">running</Badge> : null}
              </div>
              <p className="mt-1.5 text-sm text-muted-foreground">{s.blurb}</p>
              <p className="mt-1 text-xs text-foreground/80">{s.outcome}</p>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

export function ScenarioProgressBar() {
  const progress = useSentinai((s) => s.progress);
  const running = useSentinai((s) => s.runningScenario);
  if (!running || !progress) return null;
  const pct = Math.round(((progress.index + 1) / progress.total) * 100);
  return (
    <div className="border-b border-border bg-primary/5 px-4 py-2">
      <div className="flex items-center justify-between gap-3 text-xs">
        <span className="truncate font-medium">{progress.label}</span>
        <span className="tabular text-muted-foreground">
          {progress.index + 1}/{progress.total}
        </span>
      </div>
      <div className="mt-1.5 h-1 overflow-hidden rounded-full bg-muted">
        <div className="h-full bg-primary transition-[width] duration-300" style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

export function ScenarioDrawer() {
  const open = useSentinai((s) => s.drawerOpen);
  const setOpen = useSentinai((s) => s.setDrawerOpen);
  const activity = useSentinai((s) => s.activity);
  const clear = useSentinai((s) => s.clearActivity);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-background/50">
      <button className="flex-1" onClick={() => setOpen(false)} aria-label="Close activity" />
      <aside className="flex h-full w-full max-w-md flex-col border-l border-border bg-card shadow-2xl">
        <div className="flex items-start justify-between gap-3 border-b border-border px-4 py-4">
          <div>
            <h2 className="text-sm font-semibold">What just happened?</h2>
            <p className="text-xs text-muted-foreground">Cascading effects from the scenarios you ran, newest first.</p>
          </div>
          <Button variant="ghost" size="icon" onClick={() => setOpen(false)} aria-label="Close">
            <X className="size-4" />
          </Button>
        </div>
        <div className="flex-1 overflow-y-auto p-4">
          {activity.length === 0 ? (
            <p className="text-sm text-muted-foreground">
              No sandbox activity yet. Run a scenario to see the cascade across the console.
            </p>
          ) : (
            <ul className="space-y-3">
              {activity.map((item) => (
                <li key={item.id} className="rounded-lg border border-border bg-background/40 p-3">
                  <div className="text-sm font-medium">{item.label}</div>
                  <p className="mt-0.5 text-xs text-muted-foreground">{item.detail}</p>
                  <div className="mt-2 flex flex-wrap items-center gap-2 text-mono-xs text-muted-foreground">
                    <span>{formatTime(item.at)}</span>
                    <span>· {item.scenarioTitle}</span>
                    {item.route ? (
                      <Button asChild size="sm" variant="outline">
                        <Link to={item.route} onClick={() => setOpen(false)}>
                          {item.routeLabel ?? "Open"}
                        </Link>
                      </Button>
                    ) : null}
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
        {activity.length ? (
          <div className="border-t border-border p-3">
            <Button variant="ghost" size="sm" onClick={clear}>
              Clear activity
            </Button>
          </div>
        ) : null}
      </aside>
    </div>
  );
}

export function ScenarioCta({
  title,
  body,
  scenario,
}: {
  title: string;
  body: string;
  scenario: ScenarioId;
}) {
  const run = useSentinai((s) => s.runScenario);
  const running = useSentinai((s) => s.runningScenario);
  const setLauncher = useSentinai((s) => s.setLauncherOpen);
  const item = SCENARIOS.find((s) => s.id === scenario);
  return (
    <div className="rounded-lg border border-dashed border-border bg-background/30 px-4 py-5">
      <div className="text-sm font-medium">{title}</div>
      <p className="mt-1 text-sm text-muted-foreground">{body}</p>
      <div className="mt-3 flex flex-wrap gap-2">
        {item ? (
          <Button size="sm" disabled={Boolean(running)} onClick={() => void run(scenario)}>
            <Play className="size-3.5" />
            Run “{item.title}”
          </Button>
        ) : null}
        <Button size="sm" variant="outline" onClick={() => setLauncher(true)}>
          Browse scenarios
        </Button>
      </div>
    </div>
  );
}
