import { useState, type FormEvent } from "react";
import { Mark } from "@/components/mark";
import { Button } from "@/components/ui/button";
import { Input, Label } from "@/components/ui/input";
import { ENROLLMENT_CODE } from "@/lib/seed";
import { useGuardian } from "@/lib/store";
import type { Mode } from "@/lib/types";

export function LockScreen() {
  const enterDemo = useGuardian((s) => s.enterDemo);
  const signUp = useGuardian((s) => s.signUp);
  const mode = useGuardian((s) => s.mode);
  const setMode = useGuardian((s) => s.setMode);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [code, setCode] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [advanced, setAdvanced] = useState(false);

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    const msg = signUp(email.trim(), password, code.trim());
    setError(msg);
  }

  return (
    <div className="relative min-h-dvh overflow-hidden bg-bg text-fg">
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(900px 480px at 50% -8%, color-mix(in oklab, var(--color-elevated) 80%, transparent), transparent 70%)",
        }}
      />
      <div className="relative mx-auto flex min-h-dvh w-full max-w-md flex-col justify-center px-5 py-12">
        <div className="stagger-in">
          <div className="mb-8 flex items-center gap-3">
            <Mark className="size-9" />
            <div>
              <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted">
                SentinAI
              </p>
              <p className="text-lg font-medium tracking-tight">Guardian</p>
            </div>
          </div>

          <h1 className="text-3xl font-medium tracking-tight text-balance">
            Operator access
          </h1>
          <p className="mt-2 text-sm text-pretty text-muted">
            Tenant acme-core · on-prem. Policy, quarantine and audit stay on
            this console.
          </p>

          <div className="mt-6 flex rounded-lg border border-border bg-surface p-1">
            {(["demo", "live"] as Mode[]).map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => setMode(m)}
                className={`h-9 flex-1 rounded-md text-xs font-medium uppercase tracking-wide transition-colors duration-150 ${
                  mode === m
                    ? "bg-elevated text-fg"
                    : "text-muted hover:text-fg"
                }`}
              >
                {m} mode
              </button>
            ))}
          </div>
          <p className="mt-2 text-xs text-subtle">
            {mode === "demo"
              ? "Fleet probes are simulated. Policy, scanner and the hash chain are real."
              : "Probes local Ollama, LM Studio and vLLM endpoints. Unreachable nodes go offline."}
          </p>

          <Button className="mt-6 w-full" size="lg" onClick={enterDemo}>
            Enter as Maya Chen, CISO
          </Button>
          <p className="mt-2 text-center text-xs text-subtle">
            Demo workspace · PIN 2210 for dual-control
          </p>

          <button
            type="button"
            onClick={() => setAdvanced((v) => !v)}
            className="mt-8 text-xs text-muted underline-offset-4 hover:text-fg hover:underline"
          >
            {advanced ? "Hide enrollment" : "Create an operator instead"}
          </button>

          {advanced ? (
            <form onSubmit={onSubmit} className="mt-4 space-y-3">
              <div className="space-y-1.5">
                <Label htmlFor="email">Work email</Label>
                <Input
                  id="email"
                  type="email"
                  autoComplete="username"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@acme-core.internal"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  autoComplete="new-password"
                  minLength={8}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="At least 8 characters"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="code">Enrollment code</Label>
                <Input
                  id="code"
                  inputMode="numeric"
                  required
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                  placeholder="Six-digit code"
                />
                <p className="font-mono text-xs text-subtle">
                  Shown once: {ENROLLMENT_CODE}
                </p>
              </div>
              {error ? <p className="text-sm text-danger">{error}</p> : null}
              <Button type="submit" variant="secondary" className="w-full">
                Enroll operator
              </Button>
            </form>
          ) : null}
        </div>
      </div>
    </div>
  );
}

export function BootScreen() {
  return (
    <div className="flex min-h-dvh flex-col items-center justify-center bg-bg px-6 text-fg">
      <Mark className="size-10" />
      <p className="mt-4 text-xs font-medium uppercase tracking-[0.18em] text-muted">
        SentinAI Guardian
      </p>
      <div className="mt-6 h-px w-40 overflow-hidden bg-border">
        <div className="load-bar h-full w-full bg-accent" />
      </div>
    </div>
  );
}
