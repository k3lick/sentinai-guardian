import type { ReactNode } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import {
  Activity,
  Bell,
  BookOpen,
  ClipboardList,
  FileSearch,
  Gauge,
  Gavel,
  LayoutDashboard,
  Menu,
  Radio,
  Scale,
  ShieldCheck,
  ShieldEllipsis,
  Timer,
  X,
} from "lucide-react";
import { useMemo, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ScenarioDrawer, ScenarioLauncher, ScenarioProgressBar } from "@/components/scenarios";
import { ROLES, type RoleId } from "@/lib/sentinai/roles";
import { TENANT } from "@/lib/sentinai/seed";
import { useSentinai } from "@/lib/sentinai/store";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", label: "Overview", icon: LayoutDashboard },
  { to: "/models", label: "Orchestration", icon: Gauge },
  { to: "/registry", label: "Model Registry", icon: BookOpen },
  { to: "/documents", label: "Documents", icon: FileSearch },
  { to: "/guardrails", label: "Guardrails", icon: ShieldEllipsis },
  { to: "/incidents", label: "Incidents", icon: Activity },
  { to: "/sla", label: "SLA & Escalation", icon: Timer },
  { to: "/approvals", label: "Approvals & SoD", icon: Scale },
  { to: "/audit", label: "Audit Log", icon: ClipboardList },
  { to: "/siem", label: "SIEM Streaming", icon: Radio },
  { to: "/governance", label: "Governance", icon: Gavel },
  { to: "/compliance", label: "Compliance", icon: ShieldCheck },
];

function Sidebar({ open, onClose }: { open: boolean; onClose: () => void }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  return (
    <aside
      className={cn(
        "z-40 flex w-64 shrink-0 flex-col border-r border-sidebar-border bg-sidebar",
        "max-lg:fixed max-lg:inset-y-0 max-lg:left-0",
        open ? "max-lg:flex" : "max-lg:hidden",
        "lg:static lg:flex",
      )}
    >
      <div className="flex items-center justify-between gap-2 border-b border-sidebar-border px-4 py-4">
        <Link to="/" className="flex items-center gap-2.5" onClick={onClose}>
          <span className="grid size-8 place-items-center rounded-md border border-primary/40 bg-primary/10 text-primary">
            <ShieldCheck className="size-4" />
          </span>
          <span>
            <span className="block text-sm font-semibold tracking-tight">SentinAI</span>
            <span className="block text-mono-xs text-muted-foreground">agent security ops</span>
          </span>
        </Link>
        <Button variant="ghost" size="icon" className="lg:hidden" onClick={onClose} aria-label="Close menu">
          <X className="size-4" />
        </Button>
      </div>
      <nav className="flex-1 space-y-0.5 overflow-y-auto px-2 py-3">
        {NAV.map((item) => {
          const active = item.to === "/" ? pathname === "/" : pathname === item.to || pathname.startsWith(`${item.to}/`);
          const Icon = item.icon;
          return (
            <Link
              key={item.to}
              to={item.to}
              onClick={onClose}
              className={cn(
                "flex min-h-11 items-center gap-2.5 rounded-md px-2.5 py-2 text-sm transition-colors",
                active
                  ? "bg-sidebar-accent text-foreground"
                  : "text-muted-foreground hover:bg-sidebar-accent hover:text-foreground",
              )}
            >
              <Icon className="size-4 shrink-0" />
              {item.label}
            </Link>
          );
        })}
      </nav>
      <RoleSwitcher />
    </aside>
  );
}

function RoleSwitcher() {
  const role = useSentinai((s) => s.role);
  const setRole = useSentinai((s) => s.setRole);
  return (
    <div className="border-t border-sidebar-border p-3">
      <div className="text-mono-xs uppercase tracking-wider text-muted-foreground">Active role</div>
      <select
        value={role}
        onChange={(e) => setRole(e.target.value as RoleId)}
        className="mt-1.5 h-11 w-full rounded-md border border-border bg-background px-2 text-xs"
      >
        {(Object.keys(ROLES) as RoleId[]).map((id) => (
          <option key={id} value={id}>
            {ROLES[id].label}
          </option>
        ))}
      </select>
      <p className="mt-1.5 text-[11px] leading-snug text-muted-foreground">{ROLES[role].blurb}</p>
      <div className="mt-2 text-mono-xs text-muted-foreground">
        tenant: {TENANT} · region: on-prem
      </div>
    </div>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const role = useSentinai((s) => s.role);
  const alerts = useSentinai((s) => s.alerts);
  const acknowledgeAlert = useSentinai((s) => s.acknowledgeAlert);
  const updateEndpoint = useSentinai((s) => s.updateEndpoint);
  const endpoints = useSentinai((s) => s.endpoints);
  const setLauncherOpen = useSentinai((s) => s.setLauncherOpen);
  const activity = useSentinai((s) => s.activity);
  const setDrawerOpen = useSentinai((s) => s.setDrawerOpen);

  const title = useMemo(
    () => NAV.find((n) => (n.to === "/" ? pathname === "/" : pathname.startsWith(n.to)))?.label ?? "SentinAI",
    [pathname],
  );
  const live = alerts.filter((a) => !a.acknowledged);

  return (
    <div className="flex min-h-screen w-full">
      {open ? (
        <button className="fixed inset-0 z-30 bg-background/60 lg:hidden" onClick={() => setOpen(false)} aria-label="Close overlay" />
      ) : null}
      <Sidebar open={open} onClose={() => setOpen(false)} />
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-20 flex items-center gap-3 border-b border-border bg-background/80 px-4 py-3 backdrop-blur">
          <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setOpen(true)} aria-label="Open menu">
            <Menu className="size-4" />
          </Button>
          <div className="min-w-0 flex-1">
            <div className="truncate text-sm font-semibold">{title}</div>
            <div className="text-mono-xs text-muted-foreground">tenant: {TENANT} · region: on-prem</div>
          </div>
          {live.length === 0 ? (
            <Badge tone="success" dot>
              All systems nominal
            </Badge>
          ) : (
            <Badge tone="warning" dot>
              {live.length} active alert{live.length > 1 ? "s" : ""}
            </Badge>
          )}
          <Badge tone="primary">{ROLES[role].short}</Badge>
          <Button size="sm" onClick={() => setLauncherOpen(true)}>
            Run Scenario
          </Button>
          <button
            className="relative grid size-11 place-items-center rounded-md hover:bg-accent"
            onClick={() => setDrawerOpen(true)}
            aria-label="Activity"
          >
            <Bell className="size-4" />
            {activity.length ? <span className="absolute right-2 top-2 size-1.5 rounded-full bg-primary" /> : null}
          </button>
        </header>
        <ScenarioProgressBar />
        {live.length ? (
          <div className="border-b border-border bg-warning/5 px-4 py-2">
            <div className="space-y-1.5">
              {live.slice(0, 3).map((alert) => {
                const fallback = endpoints
                  .filter((e) => e.id !== alert.endpointId && e.status !== "offline")
                  .sort((a, b) => a.priority - b.priority)[0];
                return (
                  <div key={alert.id} className="flex flex-wrap items-center gap-2 text-sm">
                    <span className="min-w-0 flex-1 truncate">{alert.message}</span>
                    {fallback ? (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          const current = endpoints.find((e) => e.id === alert.endpointId);
                          if (current) updateEndpoint(current.id, { priority: fallback.priority + 1 });
                          updateEndpoint(fallback.id, { priority: 1 });
                          acknowledgeAlert(alert.id);
                        }}
                      >
                        Failover → {fallback.name}
                      </Button>
                    ) : null}
                    <Button size="sm" variant="ghost" onClick={() => acknowledgeAlert(alert.id)}>
                      Acknowledge
                    </Button>
                  </div>
                );
              })}
            </div>
          </div>
        ) : null}
        <main className="flex-1 space-y-6 p-4 md:p-6">{children}</main>
      </div>
      <ScenarioLauncher />
      <ScenarioDrawer />
    </div>
  );
}
