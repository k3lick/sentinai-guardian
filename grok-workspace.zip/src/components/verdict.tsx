import { Badge } from "@/components/ui/badge";
import type { Severity, Verdict } from "@/lib/types";

export function VerdictBadge({ verdict }: { verdict: Verdict }) {
  const tone =
    verdict === "ALLOW"
      ? "ok"
      : verdict === "DENY"
        ? "danger"
        : verdict === "HUMAN"
          ? "warn"
          : "info";
  return <Badge tone={tone}>{verdict}</Badge>;
}

export function SeverityBadge({ severity }: { severity: Severity }) {
  const tone =
    severity === "critical"
      ? "danger"
      : severity === "high"
        ? "warn"
        : severity === "medium"
          ? "info"
          : "neutral";
  return <Badge tone={tone}>{severity}</Badge>;
}

export function StatusDot({
  status,
}: {
  status: "healthy" | "degraded" | "offline" | "unprobed" | "probing";
}) {
  const color =
    status === "healthy"
      ? "bg-ok"
      : status === "degraded" || status === "probing"
        ? "bg-warn"
        : status === "offline"
          ? "bg-danger"
          : "bg-subtle";
  return (
    <span
      className={`inline-block size-1.5 rounded-full ${color} ${status === "probing" ? "live-dot" : ""}`}
    />
  );
}
