import { Link } from "@tanstack/react-router";
import {
  FileSearch,
  FolderLock,
  LayoutDashboard,
  Menu,
  ScrollText,
  Server,
  Settings,
  ShieldCheck,
  TriangleAlert,
  X,
} from "lucide-react";
import { useState, type ReactNode } from "react";
import { Mark } from "@/components/mark";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/cn";
import { deriveMetrics } from "@/lib/metrics";
import { useGuardian } from "@/lib/store";

const NAV = [
  { to: "/", label: "Overview", icon: LayoutDashboard, exact: true },
  { to: "/fleet", label: "Fleet", icon: Server, exact: false },
  { to: "/policies", label: "Policies", icon: ShieldCheck, exact: false },
  { to: "/scanner", label: "Scanner", icon: FileSearch, exact: false },
  { to: "/quarantine", label: "Quarantine", icon: FolderLock, exact: false },
  { to: "/incidents", label: "Incidents", icon: TriangleAlert, exact: false },
  { to: "/audit", label: "Audit", icon: ScrollText, exact: false },
  { to: "/settings", label: "Settings", icon: Settings, exact: false },
] as const;

function SideNav({ onNavigate }: { onNavigate?: () => void }) {
  const documents = useGuardian((s) => s.documents);
  const incidents = useGuardian((s) => s.incidents);
  const integrityOk = useGuardian((s) => s.integrityOk);
  const session = useGuardian((s) => s.session);
  const mode = useGuardian((s) => s.mode);
  const pending = documents.filter(
    (d) => d.status === "quarantined" || d.status === "awaiting-second",
  ).length;
  const openInc = incidents.filter((i) => i.status !== "closed").length;

  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center gap-2.5 px-4 py-5">
        <Mark className="size-7" />
        <div className="min-w-0">
          <p className="truncate text-sm font-medium tracking-tight">SentinAI</p>
          <p className="truncate text-[0.6875rem] uppercase tracking-[0.14em] text-muted">
            Guardian
          </p>
        </div>
      </div>
      <nav className="flex flex-1 flex-col gap-0.5 px-2">
        {NAV.map((item) => {
          const Icon = item.icon;
          const count =
            item.to === "/quarantine"
              ? pending
              : item.to === "/incidents"
                ? openInc
                : 0;
          return (
            <Link
              key={item.to}
              to={item.to}
              activeOptions={{ exact: item.exact }}
              onClick={onNavigate}
              className="flex h-11 items-center gap-2.5 rounded-md px-3 text-sm text-muted transition-colors duration-150 hover:bg-elevated hover:text-fg"
              activeProps={{
                className:
                  "flex h-11 items-center gap-2.5 rounded-md bg-elevated px-3 text-sm text-fg",
              }}
            >
              <Icon className="size-4 shrink-0" strokeWidth={1.75} />
              <span className="flex-1">{item.label}</span>
              {count > 0 ? (
                <span className="tabular min-w-5 rounded-full bg-danger/15 px-1.5 text-center text-[0.6875rem] text-danger">
                  {count}
                </span>
              ) : null}
            </Link>
          );
        })}
      </nav>
      <div className="mt-auto space-y-3 border-t border-border px-4 py-4">
        <div className="flex items-center justify-between gap-2">
          <span className="text-xs text-muted">Audit chain</span>
          {integrityOk ? (
            <Badge tone="ok">Intact</Badge>
          ) : (
            <Badge tone="danger">Broken</Badge>
          )}
        </div>
        <div className="flex items-center justify-between gap-2 text-xs text-subtle">
          <span className="truncate">{session?.name}</span>
          <span className="uppercase tracking-wide">{mode}</span>
        </div>
        <p className="text-[0.6875rem] text-subtle">acme-core · on-prem</p>
      </div>
    </div>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);
  const documents = useGuardian((s) => s.documents);
  const incidents = useGuardian((s) => s.incidents);
  const models = useGuardian((s) => s.models);
  const integrityOk = useGuardian((s) => s.integrityOk);
  const metrics = deriveMetrics(models, documents, incidents);
  const attention =
    !integrityOk || metrics.openIncidents > 0 || metrics.pendingReview > 0;

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-56 border-r border-border bg-surface lg:block">
        <SideNav />
      </aside>

      {open ? (
        <div className="fixed inset-0 z-40 lg:hidden">
          <button
            type="button"
            className="absolute inset-0 bg-bg/70"
            aria-label="Close menu"
            onClick={() => setOpen(false)}
          />
          <div className="relative h-full w-72 max-w-[85%] border-r border-border bg-surface">
            <button
              type="button"
              className="absolute right-3 top-3 rounded-md p-2 text-muted hover:text-fg"
              onClick={() => setOpen(false)}
              aria-label="Close"
            >
              <X className="size-4" />
            </button>
            <SideNav onNavigate={() => setOpen(false)} />
          </div>
        </div>
      ) : null}

      <div className="lg:pl-56">
        <div className="sticky top-0 z-20 flex h-12 items-center gap-3 border-b border-border bg-bg/90 px-4 backdrop-blur-sm lg:h-11">
          <button
            type="button"
            className="rounded-md p-2 text-muted hover:text-fg lg:hidden"
            onClick={() => setOpen(true)}
            aria-label="Open menu"
          >
            <Menu className="size-5" />
          </button>
          <p className="text-xs text-muted">
            <span
              className={cn(
                "mr-2 inline-block size-1.5 rounded-full",
                attention ? "bg-warn" : "bg-ok",
              )}
            />
            {integrityOk
              ? attention
                ? "Attention required"
                : "All systems nominal"
              : "Integrity failure"}
          </p>
          <div className="ml-auto hidden text-xs text-subtle sm:block">
            tenant: acme-core · region: on-prem
          </div>
        </div>
        <div className="px-4 py-6 sm:px-6 lg:px-8">{children}</div>
      </div>
    </div>
  );
}

export function IntegrityBanner() {
  const ok = useGuardian((s) => s.integrityOk);
  if (ok) return null;
  return (
    <div className="mb-6 rounded-lg border border-danger/40 bg-danger/10 px-4 py-3 text-sm text-danger">
      Audit chain verification failed. Treat the log as compromised — see Audit
      and Settings.
    </div>
  );
}

export function Surface({
  className,
  children,
}: {
  className?: string;
  children: ReactNode;
}) {
  return (
    <section
      className={cn(
        "rounded-xl border border-border bg-surface p-4 sm:p-5",
        className,
      )}
    >
      {children}
    </section>
  );
}

export function EmptyState({
  title,
  body,
}: {
  title: string;
  body: string;
}) {
  return (
    <div className="flex flex-col items-start gap-2 py-8">
      <p className="text-sm font-medium text-fg">{title}</p>
      <p className="max-w-md text-sm text-pretty text-muted">{body}</p>
    </div>
  );
}
