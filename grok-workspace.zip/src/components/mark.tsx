import { cn } from "@/lib/cn";

export function Mark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 32 32"
      className={cn("text-accent", className)}
      fill="none"
      aria-hidden
    >
      <path
        d="M16 2.5 28 9.2v13.6L16 29.5 4 22.8V9.2L16 2.5Z"
        stroke="currentColor"
        strokeWidth="1.4"
        strokeLinejoin="round"
      />
      <rect x="15.15" y="10" width="1.7" height="12" rx="0.6" fill="currentColor" />
      <circle cx="16" cy="8.2" r="1.05" fill="currentColor" />
    </svg>
  );
}
