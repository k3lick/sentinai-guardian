import { cn } from "@/lib/cn";
import type { ReactNode } from "react";

type Tone = "neutral" | "ok" | "warn" | "danger" | "info" | "accent";

const TONE: Record<Tone, string> = {
  neutral: "bg-elevated text-muted border-border",
  ok: "bg-ok/15 text-ok border-ok/25",
  warn: "bg-warn/15 text-warn border-warn/25",
  danger: "bg-danger/15 text-danger border-danger/25",
  info: "bg-info/15 text-info border-info/25",
  accent: "bg-accent/12 text-accent border-accent/20",
};

export function Badge({
  tone = "neutral",
  className,
  children,
}: {
  tone?: Tone;
  className?: string;
  children: ReactNode;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[0.6875rem] font-medium uppercase tracking-wide",
        TONE[tone],
        className,
      )}
    >
      {children}
    </span>
  );
}
