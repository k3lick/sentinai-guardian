import type { Mode, ModelEndpoint, ModelStatus } from "./types";

const LIVE_PATH: Record<ModelEndpoint["runtime"], string> = {
  ollama: "http://127.0.0.1:11434/api/tags",
  lmstudio: "http://127.0.0.1:1234/v1/models",
  vllm: "http://127.0.0.1:8000/v1/models",
};

function jitter(base: number, pct = 0.08): number {
  const delta = base * pct * (Math.random() * 2 - 1);
  return Math.max(8, Math.round(base + delta));
}

export async function probeEndpoint(
  model: ModelEndpoint,
  mode: Mode,
): Promise<ModelEndpoint> {
  if (mode === "demo") {
    await new Promise((r) => setTimeout(r, 280 + Math.random() * 420));
    const degraded = model.runtime === "ollama";
    const status: ModelStatus = degraded ? "degraded" : "healthy";
    return {
      ...model,
      status,
      p50: jitter(model.p50 || (degraded ? 1240 : 400)),
      p95: jitter(model.p95 || (degraded ? 2100 : 520)),
      tokPerSec: jitter(model.tokPerSec || (degraded ? 31 : 90), 0.05),
      lastProbedAt: Date.now(),
      lastError: null,
    };
  }

  const url = LIVE_PATH[model.runtime];
  const t0 = performance.now();
  try {
    const res = await fetch(url, {
      method: "GET",
      signal: AbortSignal.timeout(2500),
    });
    const ms = Math.round(performance.now() - t0);
    if (!res.ok) {
      return {
        ...model,
        status: "offline",
        lastProbedAt: Date.now(),
        lastError: `HTTP ${res.status}`,
      };
    }
    return {
      ...model,
      status: ms > 1500 ? "degraded" : "healthy",
      p50: ms,
      p95: Math.round(ms * 1.2),
      tokPerSec: model.tokPerSec,
      lastProbedAt: Date.now(),
      lastError: null,
    };
  } catch (err) {
    return {
      ...model,
      status: "offline",
      lastProbedAt: Date.now(),
      lastError: err instanceof Error ? err.message : "unreachable",
    };
  }
}
