import type { Finding, Severity } from "./types";
import { uid } from "./cn";
import { evaluatePolicy } from "./policy";

type Detector = {
  kind: Finding["kind"];
  severity: Severity;
  ruleId: string;
  label: string;
  re: RegExp;
  weight: number;
};

const DETECTORS: Detector[] = [
  {
    kind: "api_key",
    severity: "critical",
    ruleId: "KEY-001",
    label: "AWS access key",
    re: /AKIA[0-9A-Z]{16}/g,
    weight: 40,
  },
  {
    kind: "api_key",
    severity: "critical",
    ruleId: "KEY-001",
    label: "AWS secret key",
    re: /(?:aws)?.{0,12}secret.{0,12}['\"]?[A-Za-z0-9/+=]{40}/gi,
    weight: 40,
  },
  {
    kind: "api_key",
    severity: "critical",
    ruleId: "KEY-001",
    label: "OpenAI-style secret",
    re: /sk-[A-Za-z0-9]{20,}/g,
    weight: 36,
  },
  {
    kind: "token",
    severity: "critical",
    ruleId: "KEY-001",
    label: "GitHub PAT",
    re: /ghp_[A-Za-z0-9]{36}/g,
    weight: 36,
  },
  {
    kind: "token",
    severity: "high",
    ruleId: "KEY-001",
    label: "Slack token",
    re: /xox[baprs]-[\w-]+/g,
    weight: 28,
  },
  {
    kind: "private_key",
    severity: "critical",
    ruleId: "KEY-001",
    label: "PEM private key",
    re: /-----BEGIN [A-Z ]*PRIVATE KEY-----/g,
    weight: 45,
  },
  {
    kind: "pii",
    severity: "high",
    ruleId: "PII-001",
    label: "US Social Security number",
    re: /\b\d{3}-\d{2}-\d{4}\b/g,
    weight: 22,
  },
  {
    kind: "pii",
    severity: "high",
    ruleId: "PII-001",
    label: "Payment card number",
    re: /\b(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14})\b/g,
    weight: 24,
  },
  {
    kind: "pii",
    severity: "medium",
    ruleId: "PII-001",
    label: "Email address",
    re: /\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/gi,
    weight: 6,
  },
  {
    kind: "injection",
    severity: "critical",
    ruleId: "PR-001",
    label: "Instruction override",
    re: /ignore\s+(all\s+)?(previous|prior|above)\s+instructions/gi,
    weight: 30,
  },
  {
    kind: "connection_string",
    severity: "high",
    ruleId: "KEY-001",
    label: "Database connection string",
    re: /\b(?:postgres|mysql|mongodb(\+srv)?):\/\/[^\s]+/gi,
    weight: 26,
  },
];

function excerptAt(text: string, index: number, length: number): string {
  const start = Math.max(0, index - 4);
  return text.slice(start, index + length + 8).replace(/\s+/g, " ").trim();
}

export function scanText(content: string): Finding[] {
  const findings: Finding[] = [];
  const seen = new Set<string>();
  for (const det of DETECTORS) {
    const re = new RegExp(det.re.source, det.re.flags.includes("g") ? det.re.flags : `${det.re.flags}g`);
    let m: RegExpExecArray | null;
    while ((m = re.exec(content))) {
      const key = `${det.label}:${m[0]}`;
      if (seen.has(key)) continue;
      seen.add(key);
      findings.push({
        id: uid("f"),
        kind: det.kind,
        severity: det.severity,
        ruleId: det.ruleId,
        label: det.label,
        excerpt: excerptAt(content, m.index, m[0].length),
        index: m.index,
        length: m[0].length,
      });
      if (findings.length > 80) return findings;
    }
  }
  return findings.sort((a, b) => {
    const order: Record<Severity, number> = {
      critical: 0,
      high: 1,
      medium: 2,
      low: 3,
    };
    return order[a.severity] - order[b.severity];
  });
}

export function riskFromFindings(findings: Finding[]): number {
  const weights: Record<Severity, number> = {
    critical: 34,
    high: 18,
    medium: 8,
    low: 3,
  };
  const raw = findings.reduce((sum, f) => sum + weights[f.severity], 0);
  return Math.min(100, raw);
}

export function scanDocumentContent(content: string) {
  const findings = scanText(content);
  const riskScore = riskFromFindings(findings);
  const evaluation = evaluatePolicy(content, "scanner");
  return { findings, riskScore, evaluation };
}
