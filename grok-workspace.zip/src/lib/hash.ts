export const GENESIS_HASH = "0".repeat(64);

export function canonicalize(payload: unknown): string {
  return JSON.stringify(payload);
}

export async function sha256Hex(message: string): Promise<string> {
  const buf = await crypto.subtle.digest(
    "SHA-256",
    new TextEncoder().encode(message),
  );
  return Array.from(new Uint8Array(buf), (b) =>
    b.toString(16).padStart(2, "0"),
  ).join("");
}

export async function chainHash(
  prevHash: string,
  canonical: string,
): Promise<string> {
  return sha256Hex(`${prevHash}|${canonical}`);
}

export async function verifyChain(
  entries: Array<{ hash: string; prevHash: string; canonical: string }>,
): Promise<{ ok: boolean; brokenAt: number | null }> {
  let prev = GENESIS_HASH;
  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i];
    if (!entry) continue;
    if (entry.prevHash !== prev) return { ok: false, brokenAt: i };
    const expected = await chainHash(entry.prevHash, entry.canonical);
    if (expected !== entry.hash) return { ok: false, brokenAt: i };
    prev = entry.hash;
  }
  return { ok: true, brokenAt: null };
}
