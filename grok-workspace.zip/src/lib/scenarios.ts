import type { ScenarioId } from "./types";

export type ScenarioDef = {
  id: ScenarioId;
  title: string;
  blurb: string;
};

export const SCENARIOS: ScenarioDef[] = [
  {
    id: "cred-leak",
    title: "Credential leak in vendor runbook",
    blurb:
      "A markdown file with live cloud keys is submitted to the finance copilot.",
  },
  {
    id: "prompt-inject",
    title: "Prompt injection on support RAG",
    blurb:
      "An inbound ticket tries to override the system prompt and list tools.",
  },
  {
    id: "drop-table",
    title: "DROP TABLE from coding agent",
    blurb: "A coding agent proposes destroying the users table to 'fix' a migration.",
  },
  {
    id: "crm-export",
    title: "Bulk CRM extract",
    blurb: "An agent is asked to dump every customer record to a vendor.",
  },
];
