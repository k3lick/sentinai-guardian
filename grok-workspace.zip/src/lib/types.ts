export type Verdict = "ALLOW" | "DENY" | "HUMAN" | "QUARANTINE";
export type Severity = "critical" | "high" | "medium" | "low";
export type Runtime = "ollama" | "lmstudio" | "vllm";
export type ModelStatus = "healthy" | "degraded" | "offline" | "unprobed" | "probing";
export type DocStatus = "clean" | "quarantined" | "awaiting-second" | "released";
export type IncidentStatus = "open" | "investigating" | "contained" | "closed";
export type Mode = "demo" | "live";
export type PolicyCategory =
  | "database"
  | "prompt"
  | "secrets"
  | "pii"
  | "egress"
  | "identity"
  | "agent";

export type Operator = {
  id: string;
  name: string;
  role: string;
  email: string;
  pin: string;
};

export type Session = {
  operatorId: string;
  email: string;
  name: string;
  role: string;
};

export type PolicyRule = {
  id: string;
  title: string;
  category: PolicyCategory;
  verdict: Verdict;
  severity: Severity;
  description: string;
  match: (text: string) => { index: number; excerpt: string } | null;
};

export type PolicyHit = {
  ruleId: string;
  title: string;
  category: PolicyCategory;
  verdict: Verdict;
  severity: Severity;
  excerpt: string;
  index: number;
};

export type Evaluation = {
  id: string;
  ts: number;
  input: string;
  source: "playground" | "scanner" | "scenario" | "agent";
  verdict: Verdict;
  matched: PolicyHit[];
  primaryId: string | null;
  latencyMs: number;
};

export type Finding = {
  id: string;
  kind:
    | "api_key"
    | "private_key"
    | "pii"
    | "injection"
    | "token"
    | "connection_string";
  severity: Severity;
  ruleId: string;
  label: string;
  excerpt: string;
  index: number;
  length: number;
};

export type ReleaseAuth = {
  operatorId: string;
  name: string;
  ts: number;
};

export type GuardianDoc = {
  id: string;
  name: string;
  kind: string;
  content: string;
  ts: number;
  findings: Finding[];
  riskScore: number;
  status: DocStatus;
  firstAuth: ReleaseAuth | null;
  secondAuth: ReleaseAuth | null;
};

export type ModelEndpoint = {
  id: string;
  name: string;
  place: string;
  runtime: Runtime;
  model: string;
  endpoint: string;
  status: ModelStatus;
  p50: number;
  p95: number;
  tokPerSec: number;
  lastProbedAt: number | null;
  lastError: string | null;
};

export type IncidentEvent = {
  ts: number;
  text: string;
};

export type Incident = {
  id: string;
  title: string;
  severity: Severity;
  status: IncidentStatus;
  summary: string;
  assignee: string;
  openedAt: number;
  documentIds: string[];
  evaluationIds: string[];
  timeline: IncidentEvent[];
};

export type AuditEntry = {
  id: string;
  ts: number;
  actor: string;
  action: string;
  verdict?: Verdict;
  policyId?: string;
  severity?: Severity;
  payload: Record<string, unknown>;
  canonical: string;
  prevHash: string;
  hash: string;
};

export type SiemEvent = {
  id: string;
  ts: number;
  source: "sentinai.guardian";
  type:
    | "policy.verdict"
    | "document.scan"
    | "document.quarantine"
    | "release.signed"
    | "release.approved"
    | "incident.opened"
    | "incident.updated"
    | "fleet.probe"
    | "integrity.alert"
    | "role.change";
  severity: Severity;
  message: string;
  extras: Record<string, unknown>;
};

export type ScenarioId =
  | "cred-leak"
  | "prompt-inject"
  | "drop-table"
  | "crm-export";
