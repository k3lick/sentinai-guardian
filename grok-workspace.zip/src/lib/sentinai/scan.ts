import type { Finding, FindingKind, Severity } from "./types";

export const FINDING_KIND_LABEL: Record<FindingKind, string> = {
  prompt_injection: "Prompt Injection",
  credential: "Leaked Credential",
  api_token: "API Token",
  pii: "PII",
};

interface ScanRule {
  kind: FindingKind;
  label: string;
  severity: Severity;
  pattern: RegExp;
  mask: string;
}

const RULES: ScanRule[] = [
  {
    kind: "prompt_injection",
    label: "Instruction override attempt",
    severity: "critical",
    pattern:
      /(ignore (all )?(previous|prior|above) (instructions|prompts)|disregard (the )?(system|previous) (prompt|instructions)|you are now (a|an|in) [^.\n]{2,40}|do not follow (your|the) (system|safety) (prompt|rules))/gi,
    mask: "[BLOCKED_INSTRUCTION]",
  },
  {
    kind: "prompt_injection",
    label: "Exfiltration directive",
    severity: "critical",
    pattern:
      /(reveal|print|output|send|leak|forward)\s+(the\s+)?(system prompt|api key[s]?|secret[s]?|credentials|all documents)/gi,
    mask: "[BLOCKED_EXFIL]",
  },
  {
    kind: "api_token",
    label: "OpenAI-style API key",
    severity: "critical",
    pattern: /\bsk-[A-Za-z0-9_-]{16,}\b/g,
    mask: "[REDACTED_API_KEY]",
  },
  {
    kind: "api_token",
    label: "Bearer token",
    severity: "high",
    pattern: /\bBearer\s+[A-Za-z0-9._~+/=-]{16,}\b/g,
    mask: "Bearer [REDACTED_TOKEN]",
  },
  {
    kind: "api_token",
    label: "AWS access key id",
    severity: "critical",
    pattern: /\b(AKIA|ASIA)[0-9A-Z]{16}\b/g,
    mask: "[REDACTED_AWS_KEY]",
  },
  {
    kind: "credential",
    label: "Password assignment",
    severity: "high",
    pattern: /\b(password|passwd|pwd|secret|client_secret)\s*[:=]\s*\S{4,}/gi,
    mask: "password=[REDACTED]",
  },
  {
    kind: "credential",
    label: "Database connection string",
    severity: "critical",
    pattern: /\b(postgres|postgresql|mysql|mongodb(\+srv)?):\/\/\S+:\S+@\S+/gi,
    mask: "[REDACTED_DB_URI]",
  },
  {
    kind: "credential",
    label: "Private key block",
    severity: "critical",
    pattern: /-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----/g,
    mask: "[REDACTED_PRIVATE_KEY]",
  },
  {
    kind: "pii",
    label: "Email address",
    severity: "medium",
    pattern: /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b/g,
    mask: "[REDACTED_EMAIL]",
  },
  {
    kind: "pii",
    label: "Phone number",
    severity: "medium",
    pattern: /\b(\+\d{1,3}[ -]?)?(\(?\d{3}\)?[ -]?)\d{3}[ -]?\d{4}\b/g,
    mask: "[REDACTED_PHONE]",
  },
  {
    kind: "pii",
    label: "National ID / SSN",
    severity: "high",
    pattern: /\b\d{3}-\d{2}-\d{4}\b/g,
    mask: "[REDACTED_SSN]",
  },
  {
    kind: "pii",
    label: "Payment card number",
    severity: "high",
    pattern: /\b(?:\d[ -]?){13,16}\b/g,
    mask: "[REDACTED_CARD]",
  },
];

function lineOf(source: string, index: number) {
  return source.slice(0, index).split("\n").length;
}

export function scanDocument(source: string) {
  const findings: Finding[] = [];
  let sanitized = source;
  let i = 0;
  for (const rule of RULES) {
    const re = new RegExp(rule.pattern.source, rule.pattern.flags);
    let match: RegExpExecArray | null;
    while ((match = re.exec(source)) !== null && match[0].trim().length !== 0) {
      const start = Math.max(0, match.index - 40);
      findings.push({
        id: `f${i++}`,
        kind: rule.kind,
        label: rule.label,
        severity: rule.severity,
        match: match[0].slice(0, 80),
        line: lineOf(source, match.index),
        excerpt: source.slice(start, match.index + match[0].length + 40).replace(/\n/g, " "),
      });
      if (match.index === re.lastIndex) re.lastIndex++;
    }
    sanitized = sanitized.replace(new RegExp(rule.pattern.source, rule.pattern.flags), rule.mask);
  }
  return { findings, sanitized };
}

export function riskScore(findings: Finding[]) {
  const weights: Record<Severity, number> = { critical: 34, high: 18, medium: 8, low: 3, info: 1 };
  return Math.min(100, findings.reduce((sum, f) => sum + (weights[f.severity] ?? 0), 0));
}
