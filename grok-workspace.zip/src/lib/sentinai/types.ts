import type { Permission, RoleId } from "./roles";

export type Severity = "critical" | "high" | "medium" | "low" | "info";
export type EndpointStatus = "healthy" | "degraded" | "offline" | "unknown";
export type DocumentStatus =
  | "clean"
  | "flagged"
  | "quarantined"
  | "released"
  | "blocked"
  | "false_positive";
export type IncidentStatus = "open" | "investigating" | "mitigated" | "resolved";
export type SevLevel = "sev1" | "sev2" | "sev3";
export type ToolKind = "db.query" | "http.request" | "fs.write" | "mcp.invoke" | "mail.send";
export type Verdict = "allowed" | "denied" | "approval_required";
export type FindingKind = "prompt_injection" | "credential" | "api_token" | "pii";

export interface Endpoint {
  id: string;
  name: string;
  provider: string;
  url: string;
  token: string;
  models: string[];
  model: string;
  priority: number;
  status: EndpointStatus;
  latencies: number[];
  tokensPerSec: number | null;
  baselineTps: number;
  consecutiveFailures: number;
  totalRequests: number;
  failedRequests: number;
  lastError: string | null;
  lastPing: number | null;
}

export interface Finding {
  id: string;
  kind: FindingKind;
  label: string;
  severity: Severity;
  match: string;
  line: number;
  excerpt: string;
}

export interface DocEvent {
  at: number;
  label: string;
  detail: string;
  actor: string;
  role: RoleId;
}

export interface DocumentRecord {
  id: string;
  name: string;
  tenant: string;
  status: DocumentStatus;
  raw: string;
  sanitized: string;
  findings: Finding[];
  risk: number;
  size: number;
  createdAt: number;
  history: DocEvent[];
}

export interface AuditEvent {
  id: string;
  at: number;
  category: "scan" | "access" | "policy" | "incident" | "model" | "sla" | "approval" | "siem" | "role";
  action: string;
  message: string;
  severity: Severity;
  actor: string;
  role: RoleId;
  documentId?: string;
  documentName?: string;
  threat?: string;
  payload?: Record<string, unknown>;
}

export interface IncidentNote {
  at: number;
  actor: string;
  body: string;
  kind: "note" | "status";
}

export interface Incident {
  id: string;
  title: string;
  severity: SevLevel;
  status: IncidentStatus;
  assignee: string;
  createdAt: number;
  linkedDocumentIds: string[];
  linkedAuditIds: string[];
  notes: IncidentNote[];
}

export interface Alert {
  id: string;
  at: number;
  endpointId: string;
  endpointName: string;
  kind: "latency" | "failures" | "throughput";
  message: string;
  acknowledged: boolean;
}

export interface ModelVersion {
  id: string;
  family: string;
  version: string;
  provider: string;
  tags: string[];
  quantization: string;
  contextWindow: number;
  temperature: number;
  active: boolean;
  stable: boolean;
  problematic?: boolean;
  compat: {
    contextLength: boolean;
    toolCallingSchema: boolean;
    streamingSse: boolean;
    embeddings: boolean;
  };
}

export interface Deployment {
  id: string;
  at: number;
  versionId: string;
  versionLabel: string;
  actor: string;
  role: RoleId;
  kind: "deploy" | "rollback" | "flag";
  config: { contextWindow: number; temperature: number; quantization: string };
}

export interface PolicyDecision {
  verdict: Verdict;
  rule: string;
  rationale: string;
  checks: { field: string; label: string; pass: boolean }[];
}

export interface ToolCall {
  id: string;
  at: number;
  agent: string;
  tool: ToolKind;
  params: Record<string, string | number>;
  tenant: string;
  latencyMs: number;
  verdict: Verdict;
  rule: string;
  rationale: string;
  checks: PolicyDecision["checks"];
}

export interface Approval {
  id: string;
  at: number;
  title: string;
  detail: string;
  kind: "exfil" | "tool" | "rollback" | "release";
  status: "pending" | "approved" | "rejected";
  requestedBy: string;
  resolvedBy?: string;
  resolvedAt?: number;
}

export interface SiemDestination {
  id: string;
  name: string;
  platform: "splunk_hec" | "datadog" | "sentinel" | "otel";
  endpoint: string;
  token: string;
  schema: "cef" | "ecs" | "otel";
  index: string;
  enabled: boolean;
  channels: { audit: boolean; incident: boolean; quarantine: boolean; model: boolean };
  sent: number;
  failed: number;
}

export interface SiemEvent {
  id: string;
  at: number;
  channel: keyof SiemDestination["channels"];
  message: string;
  severity: Severity;
  destinationIds: string[];
}

export interface SlaPolicy {
  sev1Minutes: number;
  sev2Minutes: number;
  sev3Minutes: number;
  quarantineMinutes: number;
  rollbackMinutes: number;
  tier2Pct: number;
  tier3Pct: number;
}

export interface ActivityItem {
  id: string;
  at: number;
  scenario: string;
  scenarioTitle: string;
  label: string;
  detail: string;
  route?: string;
  routeLabel?: string;
}

export interface ScenarioProgress {
  id: string;
  label: string;
  index: number;
  total: number;
}

export type DualControlKey = "quarantine_release" | "model_rollback" | "document_purge";

export type { Permission, RoleId };
