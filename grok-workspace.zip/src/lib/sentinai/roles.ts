export type Permission =
  | "model.configure"
  | "model.execute"
  | "registry.manage"
  | "rollback.execute"
  | "document.ingest"
  | "document.review"
  | "document.release"
  | "document.raw_view"
  | "guardrail.manage"
  | "guardrail.author"
  | "guardrail.test"
  | "retention.authorize"
  | "purge.execute"
  | "sla.manage"
  | "siem.manage"
  | "evidence.verify"
  | "incident.triage"
  | "approval.countersign"
  | "audit.read";

export type RoleId =
  | "security_admin"
  | "policy_admin"
  | "compliance_officer"
  | "ml_platform_operator"
  | "dpo"
  | "security_analyst"
  | "ml_engineer"
  | "compliance_auditor"
  | "viewer";

export const PERMISSION_LABELS: Record<Permission, string> = {
  "model.configure": "Model configuration",
  "model.execute": "Model execution",
  "registry.manage": "Model registry management",
  "rollback.execute": "Model rollback",
  "document.ingest": "Document ingestion",
  "document.review": "Document review",
  "document.release": "Quarantine release",
  "document.raw_view": "Raw document view",
  "guardrail.manage": "Guardrail management",
  "guardrail.author": "Guardrail authoring",
  "guardrail.test": "Guardrail testbed",
  "retention.authorize": "Retention authorization",
  "purge.execute": "Document purge",
  "sla.manage": "SLA & escalation configuration",
  "siem.manage": "SIEM streaming configuration",
  "evidence.verify": "Evidence package verification",
  "incident.triage": "Incident triage",
  "approval.countersign": "Four-eyes counter-signature",
  "audit.read": "Audit log access",
};

export const ROLES: Record<
  RoleId,
  { label: string; short: string; blurb: string; authority: string; delegated: boolean }
> = {
  security_admin: {
    label: "Security Admin",
    short: "ADMIN",
    blurb: "Break-glass authority over endpoints, quarantine and policy.",
    authority: "administration",
    delegated: false,
  },
  policy_admin: {
    label: "Policy Administrator",
    short: "POLICY",
    blurb: "Authors and updates guardrails and safety rules.",
    authority: "policy",
    delegated: true,
  },
  compliance_officer: {
    label: "Compliance Officer / Reviewer",
    short: "CO",
    blurb: "Reviews and approves or rejects quarantined files. Cannot administer models.",
    authority: "compliance",
    delegated: true,
  },
  ml_platform_operator: {
    label: "ML Platform Operator",
    short: "MLOPS",
    blurb: "Manages model registry, endpoint configuration and rollbacks.",
    authority: "platform",
    delegated: true,
  },
  dpo: {
    label: "Data Protection Officer",
    short: "DPO",
    blurb: "Authorizes retention policies and document purge operations.",
    authority: "data_protection",
    delegated: true,
  },
  security_analyst: {
    label: "Security Analyst / Auditor",
    short: "ANALYST",
    blurb: "Inspects audit trails, triages incidents and manages event streaming.",
    authority: "analysis",
    delegated: true,
  },
  ml_engineer: {
    label: "ML Engineer",
    short: "MLE",
    blurb: "Configures inference endpoints and runs models.",
    authority: "platform",
    delegated: false,
  },
  compliance_auditor: {
    label: "Compliance Auditor",
    short: "AUDIT",
    blurb: "Reviews documents, releases quarantine, reads the audit trail.",
    authority: "compliance",
    delegated: false,
  },
  viewer: {
    label: "Viewer",
    short: "VIEW",
    blurb: "Read-only metrics, logs and sanitized document views.",
    authority: "readonly",
    delegated: false,
  },
};

export const ROLE_PERMISSIONS: Record<RoleId, Permission[]> = {
  security_admin: Object.keys(PERMISSION_LABELS) as Permission[],
  policy_admin: [
    "guardrail.author",
    "guardrail.manage",
    "guardrail.test",
    "model.execute",
    "sla.manage",
    "approval.countersign",
    "audit.read",
  ],
  compliance_officer: [
    "document.ingest",
    "document.review",
    "document.release",
    "document.raw_view",
    "evidence.verify",
    "incident.triage",
    "approval.countersign",
    "audit.read",
  ],
  ml_platform_operator: [
    "model.configure",
    "model.execute",
    "registry.manage",
    "rollback.execute",
    "document.ingest",
    "guardrail.test",
    "audit.read",
  ],
  dpo: [
    "retention.authorize",
    "purge.execute",
    "evidence.verify",
    "document.review",
    "approval.countersign",
    "audit.read",
  ],
  security_analyst: [
    "incident.triage",
    "evidence.verify",
    "guardrail.test",
    "siem.manage",
    "audit.read",
  ],
  ml_engineer: [
    "model.configure",
    "model.execute",
    "registry.manage",
    "document.ingest",
    "guardrail.test",
    "audit.read",
  ],
  compliance_auditor: [
    "document.review",
    "document.release",
    "document.raw_view",
    "document.ingest",
    "evidence.verify",
    "incident.triage",
    "audit.read",
  ],
  viewer: ["audit.read"],
};

export const ACTORS: Record<RoleId, string> = {
  security_admin: "Dana Reyes (Security Admin)",
  policy_admin: "Noah Kim (Policy Administrator)",
  compliance_officer: "Priya Shah (Compliance Officer)",
  ml_platform_operator: "Elena Voss (ML Platform Operator)",
  dpo: "Marcus Hill (DPO)",
  security_analyst: "Jules Okonkwo (Security Analyst)",
  ml_engineer: "Ilya Novak (ML Engineer)",
  compliance_auditor: "Priya Shah (Compliance Auditor)",
  viewer: "Guest Viewer",
};

export function hasPermission(role: RoleId, permission: Permission) {
  return ROLE_PERMISSIONS[role].includes(permission);
}

export const SOD_ACTIONS = [
  {
    id: "quarantine_release" as const,
    label: "Quarantine release",
    blurb: "Returning an isolated document to agent retrieval.",
    allowed: ["compliance_officer", "compliance_auditor", "security_admin"] as RoleId[],
  },
  {
    id: "model_rollback" as const,
    label: "Model rollback",
    blurb: "Reverting the active build for a model family.",
    allowed: ["ml_platform_operator", "security_admin"] as RoleId[],
  },
  {
    id: "document_purge" as const,
    label: "Permanent document purge",
    blurb: "Irreversible deletion of documents and scan artifacts.",
    allowed: ["dpo", "security_admin"] as RoleId[],
  },
];
