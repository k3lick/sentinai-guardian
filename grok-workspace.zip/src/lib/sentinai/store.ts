import { create } from "zustand";
import { nid, percentile, sleep } from "@/lib/utils";
import { ACTORS, hasPermission, type Permission, type RoleId } from "./roles";
import { evaluateTool } from "./policies";
import { riskScore, scanDocument } from "./scan";
import {
  DEFAULT_SLA,
  ENDPOINTS,
  GOVERNANCE_POLICIES,
  MODEL_VERSIONS,
  PARTNER_RUNBOOK,
  RELIABILITY_SUMMARY,
  SEED_INCIDENT,
  SIEM_DESTINATIONS,
  TENANT,
  VENDOR_RUNBOOK,
} from "./seed";
import type {
  ActivityItem,
  Alert,
  Approval,
  AuditEvent,
  Deployment,
  DocumentRecord,
  DualControlKey,
  Endpoint,
  Incident,
  ModelVersion,
  ScenarioProgress,
  Severity,
  SiemDestination,
  SiemEvent,
  SlaPolicy,
  ToolCall,
  ToolKind,
} from "./types";

const STATUS_FLOW: Incident["status"][] = ["open", "investigating", "mitigated", "resolved"];

function makeAudit(partial: Omit<AuditEvent, "id" | "at"> & { at?: number }): AuditEvent {
  return { id: nid("aud"), at: partial.at ?? Date.now(), ...partial };
}

function slaMinutes(policy: SlaPolicy, kind: "incident" | "quarantine" | "rollback", sev?: Incident["severity"]) {
  if (kind === "quarantine") return policy.quarantineMinutes;
  if (kind === "rollback") return policy.rollbackMinutes;
  if (sev === "sev1") return policy.sev1Minutes;
  if (sev === "sev3") return policy.sev3Minutes;
  return policy.sev2Minutes;
}

export function slaClock(
  policy: SlaPolicy,
  kind: "incident" | "quarantine" | "rollback",
  startedAt: number,
  sev?: Incident["severity"],
  now = Date.now(),
) {
  const minutes = slaMinutes(policy, kind, sev);
  const window = minutes * 60_000;
  const elapsed = Math.max(0, now - startedAt);
  const pct = window > 0 ? (elapsed / window) * 100 : 0;
  const tier = pct >= 100 ? 3 : pct >= policy.tier3Pct ? 2 : pct >= policy.tier2Pct ? 1 : 0;
  return {
    minutes,
    dueAt: startedAt + window,
    elapsedMs: elapsed,
    remainingMs: startedAt + window - now,
    pct: Math.min(100, Math.round(pct)),
    tier,
    breached: pct >= 100,
  };
}

export const SCENARIOS = [
  {
    id: "credential_leak",
    title: "Credential leak in vendor runbook",
    blurb: "A partner-supplied runbook lands in the ingest queue carrying live secrets and an injected instruction.",
    outcome: "Quarantine + SEV-1 incident + scan audit trail + webhook notification",
    tone: "destructive" as const,
    steps: [
      "Ingesting partner-supplied runbook",
      "Scanning for injection, credentials, tokens and PII",
      "Isolating document from retrieval",
      "Opening SEV-1 incident and linking evidence",
      "Dispatching quarantine notification",
    ],
  },
  {
    id: "latency_spike",
    title: "Edge node latency spike + fallback",
    blurb: "The Ollama edge node starts timing out under vendor-ingest load and consecutive failures climb.",
    outcome: "Degraded health, rising failures, automatic fallback priority, SEV-2 incident",
    tone: "warning" as const,
    steps: [
      "Sending inference probes to the edge node",
      "Recording timeouts and context overflow",
      "Crossing the consecutive-failure threshold",
      "Promoting the GPU cluster as fallback",
      "Opening SEV-2 incident",
    ],
  },
  {
    id: "malicious_tool",
    title: "Malicious tool call attempt",
    blurb: "An agent tries a destructive database statement and a bulk CRM export through MCP.",
    outcome: "One denial, one human-approval escalation, both logged as policy decisions",
    tone: "primary" as const,
    steps: [
      "Agent requests a destructive SQL statement",
      "Guardrail engine denies the call",
      "Agent retries via a bulk MCP export",
      "Escalating to human-in-the-loop approval",
    ],
  },
  {
    id: "bad_deploy",
    title: "Model rollback after bad deploy",
    blurb: "A release candidate ships without tool-calling support and breaks agent workflows.",
    outcome: "Candidate deployed, marked problematic, rolled back to the last stable version",
    tone: "warning" as const,
    steps: [
      "Deploying Llama-3-8B-Instruct v1.2-rc",
      "Detecting tool-calling schema incompatibility",
      "Rolling back to v1.1 stable",
      "Writing governance and audit records",
    ],
  },
  {
    id: "quiet_reset",
    title: "Quiet / healthy state",
    blurb: "Return the sandbox to a calm baseline: healthy fleet, acknowledged alerts, nominal latency.",
    outcome: "All endpoints healthy, alerts cleared, latency and throughput restored",
    tone: "success" as const,
    steps: ["Re-probing every endpoint", "Restoring baseline latency and throughput", "Acknowledging open alerts"],
  },
] as const;

export type ScenarioId = (typeof SCENARIOS)[number]["id"];

interface SentinaiState {
  role: RoleId;
  actor: string;
  endpoints: Endpoint[];
  alerts: Alert[];
  documents: DocumentRecord[];
  audit: AuditEvent[];
  incidents: Incident[];
  models: ModelVersion[];
  deployments: Deployment[];
  toolCalls: ToolCall[];
  approvals: Approval[];
  dualControl: Record<DualControlKey, boolean>;
  sla: SlaPolicy;
  siem: SiemDestination[];
  siemEvents: SiemEvent[];
  activity: ActivityItem[];
  runningScenario: ScenarioId | null;
  progress: ScenarioProgress | null;
  launcherOpen: boolean;
  drawerOpen: boolean;
  webhookUrl: string;
  emails: string[];
  retention: { documentDays: number; scanArtifactHours: number; auditYears: number; autoPurge: boolean };
  setRole: (role: RoleId) => void;
  allow: (permission: Permission) => boolean;
  log: (event: Omit<AuditEvent, "id" | "at" | "actor" | "role"> & { actor?: string; role?: RoleId }) => AuditEvent;
  ingest: (name: string, tenant: string, body: string) => DocumentRecord;
  setDocumentStatus: (id: string, status: DocumentRecord["status"], note?: string) => void;
  pingEndpoint: (id: string) => Promise<void>;
  updateEndpoint: (id: string, patch: Partial<Endpoint>) => void;
  addEndpoint: (input: Pick<Endpoint, "name" | "provider" | "url" | "model">) => void;
  removeEndpoint: (id: string) => void;
  acknowledgeAlert: (id: string) => void;
  createIncident: (input: Omit<Incident, "id" | "createdAt" | "notes" | "linkedDocumentIds" | "linkedAuditIds"> & Partial<Incident>) => Incident;
  advanceIncident: (id: string) => void;
  runToolCall: (agent: string, tool: ToolKind, params: Record<string, string | number>, tenant?: string) => ToolCall;
  deploy: (versionId: string) => Deployment | null;
  rollback: (family: string) => Deployment | null;
  flagVersion: (versionId: string) => void;
  resolveApproval: (id: string, status: "approved" | "rejected") => void;
  toggleDualControl: (key: DualControlKey) => void;
  updateSla: (patch: Partial<SlaPolicy>) => void;
  toggleSiem: (id: string) => void;
  streamSiem: (channel: keyof SiemDestination["channels"], message: string, severity: Severity) => void;
  setLauncherOpen: (open: boolean) => void;
  setDrawerOpen: (open: boolean) => void;
  clearActivity: () => void;
  runScenario: (id: ScenarioId) => Promise<void>;
  resetSandbox: () => void;
}

function seedDeployments(): Deployment[] {
  return [
    {
      id: "dep-seed-1",
      at: Date.now() - 108_000_000,
      versionId: "mv-llama-11",
      versionLabel: "Llama-3-8B-Instruct v1.1",
      actor: "Ilya Novak (ML Engineer)",
      role: "ml_engineer",
      kind: "deploy",
      config: { contextWindow: 8192, temperature: 0.2, quantization: "Q4_K_M" },
    },
    {
      id: "dep-seed-2",
      at: Date.now() - 21_600_000,
      versionId: "mv-deepseek-r1",
      versionLabel: "DeepSeek-R1-Distill v1.0",
      actor: "Dana Reyes (Security Admin)",
      role: "security_admin",
      kind: "deploy",
      config: { contextWindow: 65536, temperature: 0.6, quantization: "FP8" },
    },
  ];
}

function initial(): Pick<
  SentinaiState,
  | "role"
  | "actor"
  | "endpoints"
  | "alerts"
  | "documents"
  | "audit"
  | "incidents"
  | "models"
  | "deployments"
  | "toolCalls"
  | "approvals"
  | "dualControl"
  | "sla"
  | "siem"
  | "siemEvents"
  | "activity"
  | "runningScenario"
  | "progress"
  | "launcherOpen"
  | "drawerOpen"
  | "webhookUrl"
  | "emails"
  | "retention"
> {
  return {
    role: "security_admin",
    actor: ACTORS.security_admin,
    endpoints: ENDPOINTS.map((e) => ({ ...e })),
    alerts: [],
    documents: [],
    audit: [],
    incidents: [{ ...SEED_INCIDENT, createdAt: Date.now() - 5_400_000, notes: [...SEED_INCIDENT.notes] }],
    models: MODEL_VERSIONS.map((m) => ({ ...m })),
    deployments: seedDeployments(),
    toolCalls: [],
    approvals: [],
    dualControl: { quarantine_release: true, model_rollback: true, document_purge: true },
    sla: { ...DEFAULT_SLA },
    siem: SIEM_DESTINATIONS.map((s) => ({ ...s })),
    siemEvents: [],
    activity: [],
    runningScenario: null,
    progress: null,
    launcherOpen: false,
    drawerOpen: false,
    webhookUrl: "https://hooks.internal.company.com/sentinai",
    emails: ["soc@company.com", "compliance@company.com"],
    retention: { documentDays: 90, scanArtifactHours: 72, auditYears: 7, autoPurge: false },
  };
}

export const useSentinai = create<SentinaiState>((set, get) => ({
  ...initial(),

  setRole: (role) => {
    const prev = get().role;
    set({ role, actor: ACTORS[role] });
    get().log({
      category: "role",
      action: "role.switch",
      message: `Active role changed from ${ACTORS[prev]} to ${ACTORS[role]}`,
      severity: "info",
      payload: { from: prev, to: role },
    });
  },

  allow: (permission) => hasPermission(get().role, permission),

  log: (event) => {
    const record = makeAudit({
      ...event,
      actor: event.actor ?? get().actor,
      role: event.role ?? get().role,
    });
    set((s) => ({ audit: [record, ...s.audit].slice(0, 500) }));
    if (record.category === "incident" || record.category === "scan" || record.severity === "critical") {
      queueMicrotask(() =>
        get().streamSiem(
          record.category === "scan" ? "quarantine" : record.category === "model" ? "model" : "audit",
          record.message,
          record.severity,
        ),
      );
    }
    return record;
  },

  ingest: (name, tenant, body) => {
    const { findings, sanitized } = scanDocument(body);
    const risk = riskScore(findings);
    const critical = findings.filter((f) => f.severity === "critical");
    const status: DocumentRecord["status"] = critical.length ? "quarantined" : findings.length ? "flagged" : "clean";
    const now = Date.now();
    const doc: DocumentRecord = {
      id: nid("doc"),
      name,
      tenant,
      status,
      raw: body,
      sanitized,
      findings,
      risk,
      size: body.length,
      createdAt: now,
      history: [
        { at: now, label: "Uploaded", detail: `Ingested into tenant ${tenant}`, actor: get().actor, role: get().role },
      ],
    };
    if (status === "quarantined") {
      doc.history.push({
        at: now + 1,
        label: "Quarantined by Scanner",
        detail: `Critical: ${[...new Set(critical.map((f) => f.label))].join(", ")}`,
        actor: "SentinAI Scanner",
        role: get().role,
      });
    }
    set((s) => ({ documents: [doc, ...s.documents] }));
    get().log({
      category: "scan",
      action: "document.scanned",
      message: `Scanned "${name}" — ${findings.length} finding(s), risk ${risk}/100`,
      severity: critical.length ? "critical" : findings.length ? "medium" : "info",
      documentId: doc.id,
      documentName: name,
      payload: {
        tenant,
        bytes: body.length,
        findings: findings.length,
        risk,
        categories: [...new Set(findings.map((f) => f.kind))],
      },
    });
    if (status === "quarantined") {
      get().streamSiem("quarantine", `Quarantined ${name}`, "critical");
    }
    return doc;
  },

  setDocumentStatus: (id, status, note) => {
    set((s) => ({
      documents: s.documents.map((d) =>
        d.id === id
          ? {
              ...d,
              status,
              history: [
                ...d.history,
                {
                  at: Date.now(),
                  label:
                    status === "released"
                      ? "Approved & released to ingestion"
                      : status === "false_positive"
                        ? "Marked as false positive"
                        : status === "blocked"
                          ? "Permanently blocked & archived"
                          : status,
                  detail: note ?? `Status set to ${status}`,
                  actor: s.actor,
                  role: s.role,
                },
              ],
            }
          : d,
      ),
    }));
    const doc = get().documents.find((d) => d.id === id);
    get().log({
      category: "access",
      action: `document.${status}`,
      message: `${status} "${doc?.name ?? id}"${note ? ` — ${note}` : ""}`,
      severity: status === "blocked" ? "high" : "info",
      documentId: id,
      documentName: doc?.name,
    });
  },

  pingEndpoint: async (id) => {
    const ep = get().endpoints.find((e) => e.id === id);
    if (!ep) return;
    get().updateEndpoint(id, { status: "unknown" });
    await sleep(380);
    const fail = Math.random() > 0.94;
    const status: Endpoint["status"] = fail ? "offline" : ep.consecutiveFailures >= 2 ? "degraded" : "healthy";
    const latency = Math.round(fail ? 2400 + Math.random() * 2600 : 42 + Math.random() * 138 + (ep.latencies.at(-1) ?? 200) * 0.15);
    const latencies = [...ep.latencies, latency].slice(-25);
    const tps = fail ? 0 : Math.max(8, (ep.baselineTps ?? 60) * (0.85 + Math.random() * 0.3));
    get().updateEndpoint(id, {
      status,
      latencies,
      tokensPerSec: fail ? 0 : tps,
      consecutiveFailures: fail ? ep.consecutiveFailures + 1 : 0,
      totalRequests: ep.totalRequests + 1,
      failedRequests: ep.failedRequests + (fail ? 1 : 0),
      lastError: fail ? "timeout" : null,
      lastPing: Date.now(),
    });
    const updated = get().endpoints.find((e) => e.id === id);
    if (!updated) return;
    const p95 = percentile(updated.latencies, 95);
    if (p95 !== null && p95 > 1800) {
      get().log({
        category: "model",
        action: "endpoint.latency",
        message: `${updated.name} p95 ${p95}ms exceeds SLO`,
        severity: "high",
      });
      set((s) => {
        if (s.alerts.some((a) => !a.acknowledged && a.endpointId === id && a.kind === "latency")) return {};
        const next: Alert = {
          id: nid("al"),
          at: Date.now(),
          endpointId: id,
          endpointName: updated.name,
          kind: "latency",
          message: `${updated.name} p95 ${p95}ms — latency SLO breach`,
          acknowledged: false,
        };
        return { alerts: [next, ...s.alerts].slice(0, 50) };
      });
    }
  },

  updateEndpoint: (id, patch) =>
    set((s) => ({ endpoints: s.endpoints.map((e) => (e.id === id ? { ...e, ...patch } : e)) })),

  addEndpoint: (input) => {
    const ep: Endpoint = {
      id: nid("ep"),
      name: input.name,
      provider: input.provider,
      url: input.url,
      token: "",
      models: [input.model],
      model: input.model,
      priority: get().endpoints.length + 1,
      status: "unknown",
      latencies: [],
      tokensPerSec: null,
      baselineTps: 60,
      consecutiveFailures: 0,
      totalRequests: 0,
      failedRequests: 0,
      lastError: null,
      lastPing: null,
    };
    set((s) => ({ endpoints: [...s.endpoints, ep] }));
    get().log({
      category: "model",
      action: "endpoint.register",
      message: `Registered ${ep.name}`,
      severity: "info",
      payload: { url: ep.url, provider: ep.provider, model: ep.model },
    });
  },

  removeEndpoint: (id) => {
    const ep = get().endpoints.find((e) => e.id === id);
    set((s) => ({ endpoints: s.endpoints.filter((e) => e.id !== id) }));
    if (ep) {
      get().log({
        category: "model",
        action: "endpoint.remove",
        message: `Removed ${ep.name}`,
        severity: "medium",
      });
    }
  },

  acknowledgeAlert: (id) =>
    set((s) => ({ alerts: s.alerts.map((a) => (a.id === id ? { ...a, acknowledged: true } : a)) })),

  createIncident: (input) => {
    const incident: Incident = {
      id: `INC-${Math.floor(1000 + Math.random() * 9000)}`,
      createdAt: Date.now(),
      linkedDocumentIds: input.linkedDocumentIds ?? [],
      linkedAuditIds: input.linkedAuditIds ?? [],
      notes: input.notes ?? [],
      title: input.title,
      severity: input.severity,
      status: input.status,
      assignee: input.assignee,
    };
    set((s) => ({ incidents: [incident, ...s.incidents] }));
    get().log({
      category: "incident",
      action: "incident.opened",
      message: `${incident.id} opened — ${incident.title}`,
      severity: incident.severity === "sev1" ? "critical" : incident.severity === "sev2" ? "high" : "medium",
    });
    get().streamSiem("incident", `${incident.id} ${incident.title}`, incident.severity === "sev1" ? "critical" : "high");
    return incident;
  },

  advanceIncident: (id) => {
    set((s) => ({
      incidents: s.incidents.map((inc) => {
        if (inc.id !== id) return inc;
        const idx = STATUS_FLOW.indexOf(inc.status);
        const next = STATUS_FLOW[Math.min(STATUS_FLOW.length - 1, idx + 1)];
        return {
          ...inc,
          status: next,
          notes: [
            ...inc.notes,
            { at: Date.now(), actor: s.actor, body: `Status advanced to ${next}`, kind: "status" as const },
          ],
        };
      }),
    }));
  },

  runToolCall: (agent, tool, params, tenant = TENANT) => {
    const decision = evaluateTool(tool, params);
    const call: ToolCall = {
      id: nid("tc"),
      at: Date.now(),
      agent,
      tool,
      params,
      tenant,
      latencyMs: Math.round(8 + Math.random() * 40),
      ...decision,
    };
    set((s) => ({ toolCalls: [call, ...s.toolCalls].slice(0, 200) }));
    get().log({
      category: "policy",
      action: `tool.${decision.verdict}`,
      message: `${decision.rule} — ${decision.rationale}`,
      severity: decision.verdict === "denied" ? "high" : decision.verdict === "approval_required" ? "medium" : "info",
    });
    if (decision.verdict === "approval_required") {
      set((s) => ({
        approvals: [
          {
            id: nid("ap"),
            at: Date.now(),
            title: `${decision.rule}`,
            detail: decision.rationale,
            kind: "tool",
            status: "pending",
            requestedBy: agent,
          },
          ...s.approvals,
        ],
      }));
    }
    return call;
  },

  deploy: (versionId) => {
    const version = get().models.find((m) => m.id === versionId);
    if (!version) return null;
    set((s) => ({
      models: s.models.map((m) => (m.family === version.family ? { ...m, active: m.id === versionId } : m)),
    }));
    const dep: Deployment = {
      id: nid("dep"),
      at: Date.now(),
      versionId,
      versionLabel: `${version.family} ${version.version}`,
      actor: get().actor,
      role: get().role,
      kind: "deploy",
      config: {
        contextWindow: version.contextWindow,
        temperature: version.temperature,
        quantization: version.quantization,
      },
    };
    set((s) => ({ deployments: [dep, ...s.deployments] }));
    get().log({
      category: "model",
      action: "version.deploy",
      message: `Deployed ${dep.versionLabel}`,
      severity: "info",
      payload: { versionId },
    });
    return dep;
  },

  rollback: (family) => {
    const stable = get().models.find((m) => m.family === family && m.stable);
    if (!stable) return null;
    set((s) => ({
      models: s.models.map((m) =>
        m.family === family ? { ...m, active: m.id === stable.id, problematic: m.id !== stable.id && m.problematic } : m,
      ),
    }));
    const dep: Deployment = {
      id: nid("dep"),
      at: Date.now(),
      versionId: stable.id,
      versionLabel: `${stable.family} ${stable.version}`,
      actor: get().actor,
      role: get().role,
      kind: "rollback",
      config: {
        contextWindow: stable.contextWindow,
        temperature: stable.temperature,
        quantization: stable.quantization,
      },
    };
    set((s) => ({ deployments: [dep, ...s.deployments] }));
    get().log({
      category: "model",
      action: "version.rollback",
      message: `Rolled back to ${dep.versionLabel}`,
      severity: "high",
    });
    get().streamSiem("model", `rollback_completed → ${get().webhookUrl}`, "high");
    return dep;
  },

  flagVersion: (versionId) => {
    set((s) => ({ models: s.models.map((m) => (m.id === versionId ? { ...m, problematic: true } : m)) }));
    const v = get().models.find((m) => m.id === versionId);
    get().log({
      category: "model",
      action: "version.flagged",
      message: `${v?.family} ${v?.version} flagged as problematic`,
      severity: "high",
    });
  },

  resolveApproval: (id, status) => {
    set((s) => ({
      approvals: s.approvals.map((a) =>
        a.id === id ? { ...a, status, resolvedBy: s.actor, resolvedAt: Date.now() } : a,
      ),
    }));
    const a = get().approvals.find((x) => x.id === id);
    get().log({
      category: "approval",
      action: status === "approved" ? "approval.approved" : "approval.rejected",
      message: `${status} ${a?.title ?? id}`,
      severity: status === "rejected" ? "medium" : "info",
    });
  },

  toggleDualControl: (key) => {
    set((s) => ({ dualControl: { ...s.dualControl, [key]: !s.dualControl[key] } }));
    get().log({
      category: "approval",
      action: "dual_control.updated",
      message: `Dual control ${key} ${get().dualControl[key] ? "enabled" : "disabled"}`,
      severity: "info",
    });
  },

  updateSla: (patch) => {
    set((s) => ({ sla: { ...s.sla, ...patch } }));
    const sla = get().sla;
    get().log({
      category: "sla",
      action: "sla.updated",
      message: `SLA policy updated (SEV-1 ${sla.sev1Minutes}m, SEV-2 ${sla.sev2Minutes}m, SEV-3 ${sla.sev3Minutes}m, quarantine ${sla.quarantineMinutes}m, rollback ${sla.rollbackMinutes}m)`,
      severity: "info",
    });
  },

  toggleSiem: (id) =>
    set((s) => ({ siem: s.siem.map((d) => (d.id === id ? { ...d, enabled: !d.enabled } : d)) })),

  streamSiem: (channel, message, severity) => {
    const dest = get().siem.filter((d) => d.enabled && d.channels[channel]);
    set((s) => ({
      siem: s.siem.map((d) => (d.enabled && d.channels[channel] ? { ...d, sent: d.sent + 1 } : d)),
      siemEvents: [
        {
          id: nid("siem"),
          at: Date.now(),
          channel,
          message,
          severity,
          destinationIds: dest.map((d) => d.id),
        },
        ...s.siemEvents,
      ].slice(0, 200),
    }));
  },

  setLauncherOpen: (open) => set({ launcherOpen: open }),
  setDrawerOpen: (open) => set({ drawerOpen: open }),
  clearActivity: () => set({ activity: [] }),

  runScenario: async (id) => {
    if (get().runningScenario) return;
    const scenario = SCENARIOS.find((s) => s.id === id);
    if (!scenario) return;
    set({ runningScenario: id, launcherOpen: false, progress: { id, label: scenario.steps[0], index: 0, total: scenario.steps.length } });

    const note = (label: string, detail: string, route?: string, routeLabel?: string) => {
      set((s) => ({
        activity: [
          {
            id: nid("act"),
            at: Date.now(),
            scenario: scenario.id,
            scenarioTitle: scenario.title,
            label,
            detail,
            route,
            routeLabel,
          },
          ...s.activity,
        ].slice(0, 120),
        progress: s.progress
          ? { ...s.progress, label, index: Math.min(s.progress.index + (s.progress.label === scenario.steps[0] && label !== scenario.steps[0] ? 1 : 0), s.progress.total - 1) }
          : s.progress,
      }));
    };

    const step = async (index: number) => {
      set((s) => ({
        progress: s.progress ? { ...s.progress, index, label: scenario.steps[index] } : s.progress,
      }));
      await sleep(720);
    };

    try {
      if (id === "credential_leak") {
        await step(0);
        const doc = get().ingest("Acme Partner Runbook v3.2", TENANT, PARTNER_RUNBOOK);
        note("Document ingested", `${doc.name} · tenant ${doc.tenant} · ${doc.size} bytes`, "/documents", "Open Documents");
        await step(1);
        note("Findings detected", `Risk score ${doc.risk}/100 — ${[...new Set(doc.findings.map((f) => f.label))].slice(0, 4).join(", ")}`, "/documents", "Review findings");
        await step(2);
        note("Quarantined", "Document isolated from agent context and RAG retrieval pending review", "/documents", "Review queue");
        await step(3);
        const inc = get().createIncident({
          title: `Credential exposure in ${doc.name}`,
          severity: "sev1",
          status: "open",
          assignee: "Dana Reyes (Security Admin)",
          linkedDocumentIds: [doc.id],
        });
        note("SEV-1 incident opened", `Assigned to Dana Reyes · linked document ${doc.name}`, "/incidents", "Open incident");
        await step(4);
        get().streamSiem("quarantine", `quarantine_decision → ${get().webhookUrl}`, "critical");
        note("Webhook dispatched", `quarantine_decision → ${get().webhookUrl}`, "/siem", "Delivery log");
        note("Credential leak contained", `${doc.findings.length} findings · ${inc.id} opened`);
      } else if (id === "latency_spike") {
        const edge = get().endpoints.find((e) => e.id === "ep-ollama");
        const gpu = get().endpoints.find((e) => e.id === "ep-vllm");
        if (!edge || !gpu) return;
        await step(0);
        get().updateEndpoint(edge.id, {
          status: "degraded",
          latencies: [...edge.latencies, 2840],
          tokensPerSec: 18,
          consecutiveFailures: 1,
          lastError: "timeout",
          lastPing: Date.now(),
          totalRequests: edge.totalRequests + 1,
          failedRequests: edge.failedRequests + 1,
        });
        note("Probe 1 timed out", `${edge.name} · 2840ms · no first token inside deadline`, "/models", "Orchestration");
        await step(1);
        get().updateEndpoint(edge.id, {
          status: "degraded",
          latencies: [...get().endpoints.find((e) => e.id === edge.id)!.latencies, 4310],
          tokensPerSec: 11,
          consecutiveFailures: 2,
          lastError: "timeout",
          failedRequests: edge.failedRequests + 2,
          totalRequests: edge.totalRequests + 2,
        });
        note("Probe 2 timed out", `${edge.name} · 4310ms · token velocity down to 11 tok/s`);
        await step(2);
        get().updateEndpoint(edge.id, {
          status: "offline",
          consecutiveFailures: 3,
          lastError: "context_overflow",
          tokensPerSec: 0,
        });
        set((s) => ({
          alerts: [
            {
              id: nid("al"),
              at: Date.now(),
              endpointId: edge.id,
              endpointName: edge.name,
              kind: "failures",
              message: `${edge.name} crossed consecutive-failure threshold`,
              acknowledged: false,
            },
            ...s.alerts,
          ],
        }));
        note("Failure threshold crossed", "3 consecutive failures — latency and throughput alerts raised", "/models", "View alerts");
        await step(3);
        get().updateEndpoint(gpu.id, { priority: 1, status: "healthy" });
        get().updateEndpoint(edge.id, { priority: 3 });
        get().log({
          category: "model",
          action: "endpoint.failover",
          message: `${gpu.name} is now priority 1`,
          severity: "high",
        });
        note("Failover", `${gpu.name} is now priority 1`, "/models", "Orchestration");
        await step(4);
        const inc = get().createIncident({
          title: `${edge.name} latency spike and failover`,
          severity: "sev2",
          status: "investigating",
          assignee: "Ilya Novak (ML Engineer)",
        });
        note("Edge node degraded", `Failover to ${gpu.name} · ${inc.id} opened`, "/incidents", "Open incident");
      } else if (id === "malicious_tool") {
        await step(0);
        const denied = get().runToolCall("rag-assistant", "db.query", {
          statement: "drop table customer_invoices; select * from users",
        });
        note("Tool call denied", `${denied.rule} — ${denied.rationale}`, "/guardrails", "Policy inspector");
        await step(1);
        await step(2);
        const escalated = get().runToolCall("rag-assistant", "mcp.invoke", {
          server: "internal-crm",
          tool: "export_dump",
        });
        note("Tool call escalated", `${escalated.rule} — ${escalated.rationale}`, "/approvals", "Pending approvals");
        await step(3);
        note("Policy decisions logged", "Both attempts written to the immutable audit log", "/audit", "Audit log");
        note("Malicious tool call blocked", `${denied.rule} · escalation pending approval`);
      } else if (id === "bad_deploy") {
        await step(0);
        const dep = get().deploy("mv-llama-12");
        note("Candidate deployed", `${dep?.versionLabel} · ctx ${dep?.config.contextWindow} · ${dep?.config.quantization}`, "/registry", "Model registry");
        await step(1);
        get().flagVersion("mv-llama-12");
        note("Incompatibility", "Tool-calling JSON schema unsupported — agent workflows failing", "/registry", "Compatibility matrix");
        await step(2);
        const rb = get().rollback("Llama-3-8B-Instruct");
        note("Rollback complete", `Restored ${rb?.versionLabel}`, "/registry", "Deployment history");
        await step(3);
        note("Rolled back to v1.1 stable", "Registry and audit records updated", "/audit", "Audit log");
      } else if (id === "quiet_reset") {
        await step(0);
        for (const ep of get().endpoints) {
          get().updateEndpoint(ep.id, {
            status: "healthy",
            consecutiveFailures: 0,
            lastError: null,
            lastPing: Date.now(),
            tokensPerSec: ep.baselineTps,
            latencies: ep.id === "ep-vllm" ? [190, 210, 230, 200, 220] : ep.id === "ep-lmstudio" ? [420, 450, 470, 440, 460] : [880, 910, 940, 900, 930],
            priority: ep.id === "ep-lmstudio" ? 1 : ep.id === "ep-ollama" ? 2 : 3,
          });
        }
        await step(1);
        note("Fleet restored", `${get().endpoints.length} endpoints healthy with nominal latency`, "/models", "Orchestration");
        await step(2);
        set((s) => ({ alerts: s.alerts.map((a) => ({ ...a, acknowledged: true })) }));
        note("Alerts acknowledged", "Sandbox returned to a quiet baseline", "/", "Overview");
      }
    } finally {
      set({ runningScenario: null, progress: null, drawerOpen: true });
    }
  },

  resetSandbox: () => set({ ...initial() }),
}));

export { GOVERNANCE_POLICIES, RELIABILITY_SUMMARY, TENANT, VENDOR_RUNBOOK };
