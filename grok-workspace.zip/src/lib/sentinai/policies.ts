import type { PolicyDecision, ToolKind } from "./types";

const EGRESS_ALLOW = ["company.com", "internal.company.com", "localhost", "vllm.internal.company.com"];
const SECRET_PATH = /(\.env|id_rsa|secrets?|\/etc\/|\/root\/)/i;

function check(field: string, label: string, pass: boolean) {
  return { field, label, pass };
}

export function evaluateTool(
  tool: ToolKind,
  params: Record<string, string | number>,
): PolicyDecision {
  switch (tool) {
    case "db.query": {
      const statement = String(params.statement ?? "");
      const destructive = /\b(drop|truncate|alter|delete|update|insert)\b/i.test(statement);
      const unbounded = !/\blimit\s+\d+/i.test(statement) && /\bselect\b/i.test(statement);
      const pii = /\b(ssn|password|card|email|phone)\b/i.test(statement);
      const checks = [
        check("statement", "no destructive DDL/DML verbs", !destructive),
        check("statement", "bounded result set (LIMIT present)", !unbounded),
        check("statement", "no direct PII column projection", !pii),
      ];
      if (destructive) {
        return {
          verdict: "denied",
          rule: "DB-001 · Read-only agent scope",
          rationale: "Statement contains a destructive verb outside the agent's read-only grant.",
          checks,
        };
      }
      if (pii || unbounded) {
        return {
          verdict: "approval_required",
          rule: "DB-014 · PII projection review",
          rationale: "Query projects sensitive columns or is unbounded; an operator must approve.",
          checks,
        };
      }
      return {
        verdict: "allowed",
        rule: "DB-000 · Baseline read",
        rationale: "Bounded read within scope.",
        checks,
      };
    }
    case "http.request": {
      const url = String(params.url ?? "");
      let host = "";
      try {
        host = new URL(url).hostname;
      } catch {
        host = "";
      }
      const allowed = EGRESS_ALLOW.some((d) => host === d || host.endsWith(`.${d}`));
      const tls = url.startsWith("https://") || host === "localhost";
      const mutating = (String(params.method ?? "GET")).toUpperCase() !== "GET";
      const checks = [
        check("url", "host on egress allowlist", allowed),
        check("url", "TLS enforced", tls),
        check("method", "non-mutating method", !mutating),
      ];
      if (!allowed || !tls) {
        return {
          verdict: "denied",
          rule: "NET-002 · Egress allowlist",
          rationale: `Host "${host || "invalid"}" is not permitted for outbound agent traffic.`,
          checks,
        };
      }
      if (mutating) {
        return {
          verdict: "approval_required",
          rule: "NET-009 · Mutating egress",
          rationale: "Write request to an external system requires human approval.",
          checks,
        };
      }
      return {
        verdict: "allowed",
        rule: "NET-000 · Allowlisted read",
        rationale: "Allowlisted GET over TLS.",
        checks,
      };
    }
    case "fs.write": {
      const path = String(params.path ?? "");
      const confined = path.startsWith("/workspace/");
      const secret = SECRET_PATH.test(path);
      const bytes = Number(params.bytes ?? 0);
      const checks = [
        check("path", "confined to /workspace/", confined),
        check("path", "not a secret or system path", !secret),
        check("bytes", "payload under 1 MB", bytes <= 1048576),
      ];
      if (!confined || secret) {
        return {
          verdict: "denied",
          rule: "FS-003 · Workspace confinement",
          rationale: "Write target escapes the agent sandbox or touches protected material.",
          checks,
        };
      }
      return {
        verdict: "allowed",
        rule: "FS-000 · Sandboxed write",
        rationale: "Write confined to sandbox.",
        checks,
      };
    }
    case "mcp.invoke": {
      const server = String(params.server ?? "");
      const toolName = String(params.tool ?? "");
      const registered = ["internal-crm", "docs-index", "ticketing"].includes(server);
      const bulk = /export|dump|download|delete/i.test(toolName);
      const checks = [
        check("server", "registered MCP server", registered),
        check("tool", "non-bulk-export operation", !bulk),
      ];
      if (!registered) {
        return {
          verdict: "denied",
          rule: "MCP-001 · Registered servers only",
          rationale: "Unregistered MCP server cannot be reached by agents.",
          checks,
        };
      }
      if (bulk) {
        return {
          verdict: "approval_required",
          rule: "MCP-007 · Bulk data operation",
          rationale: "Bulk export/delete through MCP is gated on human approval.",
          checks,
        };
      }
      return {
        verdict: "allowed",
        rule: "MCP-000 · Scoped invoke",
        rationale: "Scoped call to a registered server.",
        checks,
      };
    }
    case "mail.send": {
      const to = String(params.to ?? "");
      const internal = /@company\.com$/i.test(to);
      const checks = [
        check("to", "internal recipient domain", internal),
        check("subject", "subject present", Boolean(params.subject)),
      ];
      if (internal) {
        return {
          verdict: "allowed",
          rule: "COMM-000 · Internal mail",
          rationale: "Internal recipient.",
          checks,
        };
      }
      return {
        verdict: "approval_required",
        rule: "COMM-004 · External recipient",
        rationale: "Outbound mail to an external domain needs approval.",
        checks,
      };
    }
    default:
      return {
        verdict: "denied",
        rule: "GEN-000 · Unknown tool",
        rationale: "Tool is not present in the approved capability registry.",
        checks: [],
      };
  }
}

export const TOOL_LABELS: Record<ToolKind, string> = {
  "db.query": "Database query",
  "http.request": "External API call",
  "fs.write": "File write",
  "mcp.invoke": "MCP tool invoke",
  "mail.send": "Send email",
};
