import type { GuardianDoc, Incident, ModelEndpoint, Severity } from "./types";

export type DerivedMetrics = {
  availability: number;
  healthy: number;
  degraded: number;
  offline: number;
  avgP95: number;
  quarantine: number;
  pendingReview: number;
  releaseRate: number;
  findings: number;
  criticalFindings: number;
  documents: number;
  openIncidents: number;
  totalIncidents: number;
  severity: Record<Severity, number>;
};

export function deriveMetrics(
  models: ModelEndpoint[],
  docs: GuardianDoc[],
  incidents: Incident[],
): DerivedMetrics {
  const healthy = models.filter((m) => m.status === "healthy").length;
  const degraded = models.filter((m) => m.status === "degraded").length;
  const offline = models.filter(
    (m) => m.status === "offline" || m.status === "unprobed",
  ).length;
  const n = models.length || 1;
  const availability = Math.round(
    (healthy * 100 + degraded * 88 + offline * 0) / n,
  );
  const probed = models.filter((m) => m.p95 > 0);
  const avgP95 = probed.length
    ? Math.round(probed.reduce((s, m) => s + m.p95, 0) / probed.length)
    : 0;

  const quarantine = docs.filter(
    (d) => d.status === "quarantined" || d.status === "awaiting-second",
  ).length;
  const pendingReview = docs.filter(
    (d) => d.status === "quarantined" || d.status === "awaiting-second",
  ).length;
  const released = docs.filter((d) => d.status === "released").length;
  const everHeld = docs.filter((d) => d.status !== "clean").length;
  const releaseRate = everHeld ? Math.round((released / everHeld) * 100) : 0;

  const findings = docs.reduce((s, d) => s + d.findings.length, 0);
  const criticalFindings = docs.reduce(
    (s, d) => s + d.findings.filter((f) => f.severity === "critical").length,
    0,
  );

  const severity: Record<Severity, number> = {
    critical: 0,
    high: 0,
    medium: 0,
    low: 0,
  };
  for (const d of docs) {
    if (d.status === "released" || d.status === "clean") continue;
    for (const f of d.findings) severity[f.severity] += 1;
  }

  const openIncidents = incidents.filter((i) => i.status !== "closed").length;

  return {
    availability,
    healthy,
    degraded,
    offline,
    avgP95,
    quarantine,
    pendingReview,
    releaseRate,
    findings,
    criticalFindings,
    documents: docs.length,
    openIncidents,
    totalIncidents: incidents.length,
    severity,
  };
}
