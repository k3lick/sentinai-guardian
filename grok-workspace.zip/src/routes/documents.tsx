import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader, Panel, StatusBadge } from "@/components/chrome";
import { ScenarioCta } from "@/components/scenarios";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { TENANT, VENDOR_RUNBOOK, RELIABILITY_SUMMARY } from "@/lib/sentinai/seed";
import { useSentinai } from "@/lib/sentinai/store";
import { formatTime } from "@/lib/utils";

export const Route = createFileRoute("/documents")({
  head: () => ({ meta: [{ title: "Secure Document Workflow · SentinAI" }] }),
  component: DocumentsPage,
});

function DocumentsPage() {
  const documents = useSentinai((s) => s.documents);
  const ingest = useSentinai((s) => s.ingest);
  const setStatus = useSentinai((s) => s.setDocumentStatus);
  const allow = useSentinai((s) => s.allow);
  const role = useSentinai((s) => s.role);
  const [name, setName] = useState("q3-reliability-summary.txt");
  const [body, setBody] = useState(RELIABILITY_SUMMARY);
  const [openId, setOpenId] = useState<string | null>(null);
  const selected = documents.find((d) => d.id === openId) ?? documents[0];
  const canRaw = allow("document.raw_view");

  return (
    <div className="space-y-6">
      <PageHeader
        title="Document library"
        subtitle={`${documents.length} documents · scanned before agent context · quarantined docs excluded from RAG`}
      />
      <div className="grid gap-4 lg:grid-cols-3">
        <Panel title="Ingest document" className="lg:col-span-1">
          <form
            className="space-y-3"
            onSubmit={(e) => {
              e.preventDefault();
              if (!allow("document.ingest")) return;
              const doc = ingest(name || "untitled.txt", TENANT, body);
              setOpenId(doc.id);
            }}
          >
            <label className="block text-xs text-muted-foreground">
              Filename
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="mt-1 h-9 w-full rounded-md border border-input bg-background px-2 text-sm"
              />
            </label>
            <label className="block text-xs text-muted-foreground">
              Contents
              <textarea
                value={body}
                onChange={(e) => setBody(e.target.value)}
                rows={8}
                className="mt-1 w-full rounded-md border border-input bg-background p-2 font-mono text-xs"
              />
            </label>
            <div className="flex flex-wrap gap-2">
              <Button type="submit" size="sm" disabled={!allow("document.ingest")}>
                Scan & ingest
              </Button>
              <Button
                type="button"
                size="sm"
                variant="outline"
                onClick={() => {
                  setName("vendor-runbook.txt");
                  setBody(VENDOR_RUNBOOK);
                }}
              >
                Load vendor runbook
              </Button>
            </div>
          </form>
        </Panel>
        <Panel title="Library" className="lg:col-span-2">
          {documents.length === 0 ? (
            <ScenarioCta
              title="No documents ingested yet"
              body="Run the credential-leak scenario or paste a runbook to see the scanner quarantine live secrets."
              scenario="credential_leak"
            />
          ) : (
            <ul className="space-y-1.5">
              {documents.map((d) => (
                <li key={d.id}>
                  <button
                    onClick={() => setOpenId(d.id)}
                    className={`flex w-full flex-wrap items-center gap-2 rounded-md border px-3 py-2 text-left text-sm ${selected?.id === d.id ? "border-primary/40 bg-primary/5" : "border-border bg-background/40"}`}
                  >
                    <StatusBadge status={d.status} />
                    <span className="font-medium">{d.name}</span>
                    <span className="text-mono-xs text-muted-foreground">risk {d.risk}</span>
                    <span className="ml-auto text-mono-xs text-muted-foreground">{formatTime(d.createdAt)}</span>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </Panel>
      </div>
      {selected ? (
        <Panel title={selected.name} subtitle={`${selected.findings.length} findings · tenant ${selected.tenant}`}>
          <div className="flex flex-wrap gap-2">
            <Button
              size="sm"
              disabled={!allow("document.release")}
              onClick={() => setStatus(selected.id, "released", `Notes: released by ${role}`)}
            >
              Release
            </Button>
            <Button size="sm" variant="outline" onClick={() => setStatus(selected.id, "false_positive")}>
              False positive
            </Button>
            <Button size="sm" variant="ghost" onClick={() => setStatus(selected.id, "blocked")}>
              Block & archive
            </Button>
          </div>
          <div className="mt-3 space-y-2">
            {selected.findings.map((f) => (
              <div key={f.id} className="rounded-md border border-border bg-background/40 px-3 py-2 text-sm">
                <div className="flex flex-wrap items-center gap-2">
                  <Badge tone={f.severity === "critical" || f.severity === "high" ? "destructive" : "warning"}>
                    {f.severity}
                  </Badge>
                  <span>{f.label}</span>
                  <span className="ml-auto text-mono-xs text-muted-foreground">line {f.line}</span>
                </div>
                <p className="mt-1 truncate font-mono text-xs text-muted-foreground">{f.excerpt}</p>
              </div>
            ))}
          </div>
          <pre className="mt-3 max-h-64 overflow-auto rounded-md border border-border bg-background/60 p-3 font-mono text-xs whitespace-pre-wrap">
            {canRaw ? selected.raw : selected.sanitized}
          </pre>
        </Panel>
      ) : null}
    </div>
  );
}
