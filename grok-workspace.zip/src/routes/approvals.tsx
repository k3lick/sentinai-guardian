import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, Panel } from "@/components/chrome";
import { ScenarioCta } from "@/components/scenarios";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { PERMISSION_LABELS, ROLE_PERMISSIONS, ROLES, SOD_ACTIONS, type RoleId } from "@/lib/sentinai/roles";
import { useSentinai } from "@/lib/sentinai/store";
import { formatTime } from "@/lib/utils";

export const Route = createFileRoute("/approvals")({
  head: () => ({ meta: [{ title: "Delegated Administration & SoD · SentinAI" }] }),
  component: ApprovalsPage,
});

function ApprovalsPage() {
  const approvals = useSentinai((s) => s.approvals);
  const resolve = useSentinai((s) => s.resolveApproval);
  const dual = useSentinai((s) => s.dualControl);
  const toggle = useSentinai((s) => s.toggleDualControl);
  const allow = useSentinai((s) => s.allow);
  const pending = approvals.filter((a) => a.status === "pending");
  const resolved = approvals.filter((a) => a.status !== "pending");
  const canSign = allow("approval.countersign");
  const roles = Object.keys(ROLES) as RoleId[];
  const perms = Object.keys(PERMISSION_LABELS) as (keyof typeof PERMISSION_LABELS)[];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Pending human approvals"
        subtitle="Bulk exfiltration & high-risk actions escalated for review"
      />
      <Panel>
        {pending.length === 0 ? (
          <ScenarioCta
            title="No pending approvals"
            body="High-risk MCP exports and mutating egress land here. Run the malicious tool-call scenario to generate one."
            scenario="malicious_tool"
          />
        ) : (
          <ul className="space-y-2">
            {pending.map((a) => (
              <li key={a.id} className="rounded-lg border border-border bg-background/40 p-3">
                <div className="text-sm font-medium">{a.title}</div>
                <p className="text-xs text-muted-foreground">{a.detail}</p>
                <div className="mt-2 flex flex-wrap gap-2">
                  <Button size="sm" disabled={!canSign} onClick={() => resolve(a.id, "approved")}>
                    Approve — allow to take effect
                  </Button>
                  <Button size="sm" variant="outline" disabled={!canSign} onClick={() => resolve(a.id, "rejected")}>
                    Reject — block
                  </Button>
                  <span className="text-mono-xs text-muted-foreground">{a.requestedBy}</span>
                </div>
              </li>
            ))}
          </ul>
        )}
      </Panel>
      <Panel title="Resolved approvals" subtitle="Signed-off or rejected decisions (take effect on sign-off)">
        {resolved.length === 0 ? (
          <p className="text-sm text-muted-foreground">None yet.</p>
        ) : (
          <ul className="divide-y divide-border/70">
            {resolved.map((a) => (
              <li key={a.id} className="flex flex-wrap items-center gap-3 py-2 text-sm">
                <Badge tone={a.status === "approved" ? "success" : "destructive"}>{a.status}</Badge>
                <span className="flex-1">{a.title}</span>
                <span className="text-mono-xs text-muted-foreground">{a.resolvedBy}</span>
                <span className="text-mono-xs text-muted-foreground">
                  {a.resolvedAt ? formatTime(a.resolvedAt) : ""}
                </span>
              </li>
            ))}
          </ul>
        )}
      </Panel>
      <Panel title="Segregation of duties matrix" subtitle="Which role may perform which action">
        <div className="mb-4 flex flex-wrap gap-3">
          {SOD_ACTIONS.map((a) => (
            <label key={a.id} className="flex items-center gap-2 text-xs">
              <input type="checkbox" checked={dual[a.id]} onChange={() => toggle(a.id)} />
              Dual control · {a.label}
            </label>
          ))}
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[720px] text-left text-xs">
            <thead>
              <tr className="border-b border-border text-muted-foreground">
                <th className="py-2 pr-2 font-medium">Permission</th>
                {roles.map((r) => (
                  <th key={r} className="px-1 py-2 font-medium">
                    {ROLES[r].short}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {perms.map((p) => (
                <tr key={p} className="border-b border-border/60">
                  <td className="py-1.5 pr-2">{PERMISSION_LABELS[p]}</td>
                  {roles.map((r) => (
                    <td key={r} className="px-1 py-1.5 text-center">
                      {ROLE_PERMISSIONS[r].includes(p) ? (
                        <span className="text-success">yes</span>
                      ) : (
                        <span className="text-muted-foreground">—</span>
                      )}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-3 text-xs text-muted-foreground">
          A reviewer who adjudicates quarantined content must not also administer models or endpoints. Purge
          authorization stays independent of the platform team.
        </p>
      </Panel>
    </div>
  );
}
