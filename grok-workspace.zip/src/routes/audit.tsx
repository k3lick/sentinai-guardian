import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { PageHeader, Panel } from "@/components/chrome";
import { ScenarioCta } from "@/components/scenarios";
import { Badge } from "@/components/ui/badge";
import { useSentinai } from "@/lib/sentinai/store";
import { formatTime } from "@/lib/utils";

export const Route = createFileRoute("/audit")({
  head: () => ({ meta: [{ title: "Audit Log · SentinAI" }] }),
  component: AuditPage,
});

function AuditPage() {
  const audit = useSentinai((s) => s.audit);
  const allow = useSentinai((s) => s.allow);
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("all");
  const filtered = useMemo(
    () =>
      audit.filter((e) => {
        if (cat !== "all" && e.category !== cat) return false;
        if (!q) return true;
        const hay = `${e.action} ${e.message} ${e.actor}`.toLowerCase();
        return hay.includes(q.toLowerCase());
      }),
    [audit, q, cat],
  );

  if (!allow("audit.read")) {
    return (
      <div className="rounded-xl border border-border bg-card/70 p-6">
        <h1 className="text-lg font-semibold">Access restricted</h1>
        <p className="mt-1 text-sm text-muted-foreground">Audit log access is not granted to the active role.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Audit log" subtitle={`${audit.length} immutable records · tamper-evident chain`} />
      <div className="flex flex-wrap gap-2">
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search actions, actors, messages"
          className="h-9 min-w-56 flex-1 rounded-md border border-input bg-background px-2 text-sm"
        />
        <select
          value={cat}
          onChange={(e) => setCat(e.target.value)}
          className="h-9 rounded-md border border-input bg-background px-2 text-sm"
        >
          {["all", "scan", "access", "policy", "incident", "model", "sla", "approval", "siem", "role"].map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
      </div>
      <Panel>
        {filtered.length === 0 ? (
          <ScenarioCta
            title="No access-control activity recorded yet"
            body="Scenarios drive real quarantine decisions, policy verdicts and role events straight into this stream."
            scenario="credential_leak"
          />
        ) : (
          <ul className="divide-y divide-border/70">
            {filtered.map((e) => (
              <li key={e.id} className="flex flex-wrap items-start gap-3 py-2.5 text-sm">
                <Badge
                  tone={
                    e.severity === "critical" || e.severity === "high"
                      ? "destructive"
                      : e.severity === "medium"
                        ? "warning"
                        : "muted"
                  }
                >
                  {e.action}
                </Badge>
                <div className="min-w-0 flex-1">
                  <div>{e.message}</div>
                  <div className="text-mono-xs text-muted-foreground">
                    {e.actor} · {e.role} · {e.category}
                  </div>
                </div>
                <span className="text-mono-xs text-muted-foreground">{formatTime(e.at)}</span>
              </li>
            ))}
          </ul>
        )}
      </Panel>
    </div>
  );
}
