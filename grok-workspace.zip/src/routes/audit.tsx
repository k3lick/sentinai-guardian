import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { IntegrityBanner, Surface } from "@/components/app-shell";
import { PageHeader } from "@/components/page-header";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { VerdictBadge } from "@/components/verdict";
import { downloadJson, formatClock, truncateHash } from "@/lib/cn";
import { useGuardian } from "@/lib/store";

export const Route = createFileRoute("/audit")({ component: AuditPage });

function AuditPage() {
  const audit = useGuardian((s) => s.audit);
  const siem = useGuardian((s) => s.siem);
  const ok = useGuardian((s) => s.integrityOk);
  const brokenAt = useGuardian((s) => s.integrityBrokenAt);
  const recheck = useGuardian((s) => s.recheckIntegrity);
  const [tab, setTab] = useState<"chain" | "siem">("chain");
  const [open, setOpen] = useState<string | null>(null);

  return (
    <div className="stagger-in space-y-6">
      <IntegrityBanner />
      <PageHeader
        kicker="Audit"
        title="Tamper-evident chain"
        description="Each entry commits SHA-256(prevHash | canonical payload). SIEM is a fan-out of the same events, not a second source of truth."
        actions={
          <>
            <Button size="sm" variant="secondary" onClick={() => recheck()}>
              Recheck
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() =>
                downloadJson(`sentinai-audit-${Date.now()}.json`, audit)
              }
            >
              Export JSON
            </Button>
          </>
        }
      />

      <Surface className="flex flex-wrap items-center gap-3">
        {ok ? <Badge tone="ok">Chain intact</Badge> : <Badge tone="danger">Chain broken</Badge>}
        <span className="tabular text-sm text-muted">
          {audit.length} entries
          {brokenAt !== null ? ` · first break at index ${brokenAt}` : ""}
        </span>
      </Surface>

      <div className="flex gap-1 rounded-lg border border-border bg-surface p-1 w-fit">
        {(["chain", "siem"] as const).map((t) => (
          <button
            key={t}
            type="button"
            onClick={() => setTab(t)}
            className={`h-9 rounded-md px-3 text-xs font-medium uppercase tracking-wide ${
              tab === t ? "bg-elevated text-fg" : "text-muted hover:text-fg"
            }`}
          >
            {t === "chain" ? "Hash chain" : "SIEM fan-out"}
          </button>
        ))}
      </div>

      {tab === "chain" ? (
        <Surface className="overflow-x-auto p-0">
          <table className="w-full min-w-[48rem] text-left text-sm">
            <thead className="border-b border-border text-xs uppercase tracking-wide text-muted">
              <tr>
                <th className="px-4 py-3 font-medium">Time</th>
                <th className="px-3 py-3 font-medium">Actor</th>
                <th className="px-3 py-3 font-medium">Action</th>
                <th className="px-3 py-3 font-medium">Verdict</th>
                <th className="px-4 py-3 font-medium">Hash</th>
              </tr>
            </thead>
            <tbody>
              {[...audit].reverse().map((e) => (
                <tr
                  key={e.id}
                  className="border-b border-border last:border-0 align-top"
                >
                  <td className="px-4 py-3 tabular text-xs text-subtle whitespace-nowrap">
                    {formatClock(e.ts)}
                  </td>
                  <td className="px-3 py-3 text-xs">{e.actor}</td>
                  <td className="px-3 py-3">
                    <button
                      type="button"
                      className="text-left text-xs hover:underline"
                      onClick={() => setOpen(open === e.id ? null : e.id)}
                    >
                      {e.action}
                      {e.policyId ? (
                        <span className="ml-1 font-mono text-subtle">
                          {e.policyId}
                        </span>
                      ) : null}
                    </button>
                    {open === e.id ? (
                      <pre className="mt-2 max-w-md overflow-auto rounded-md bg-bg p-2 font-mono text-[0.6875rem] text-muted">
                        {e.canonical}
                      </pre>
                    ) : null}
                  </td>
                  <td className="px-3 py-3">
                    {e.verdict ? <VerdictBadge verdict={e.verdict} /> : "—"}
                  </td>
                  <td className="px-4 py-3 font-mono text-[0.6875rem] text-subtle">
                    {truncateHash(e.hash)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Surface>
      ) : (
        <Surface>
          <ul className="space-y-3">
            {siem.map((e) => (
              <li key={e.id} className="flex gap-3 border-b border-border pb-3 last:border-0 last:pb-0">
                <span className="w-32 shrink-0 tabular text-xs text-subtle">
                  {formatClock(e.ts)}
                </span>
                <div className="min-w-0">
                  <p className="text-sm">{e.message}</p>
                  <p className="font-mono text-[0.6875rem] text-subtle">
                    {e.source} · {e.type} · {e.severity}
                  </p>
                </div>
              </li>
            ))}
          </ul>
        </Surface>
      )}
    </div>
  );
}
