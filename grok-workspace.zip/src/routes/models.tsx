import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader, Panel, StatusBadge } from "@/components/chrome";
import { Button } from "@/components/ui/button";
import { percentile } from "@/lib/utils";
import { useSentinai } from "@/lib/sentinai/store";

export const Route = createFileRoute("/models")({
  head: () => ({ meta: [{ title: "Orchestration Console · SentinAI" }] }),
  component: ModelsPage,
});

function ModelsPage() {
  const endpoints = useSentinai((s) => s.endpoints);
  const ping = useSentinai((s) => s.pingEndpoint);
  const add = useSentinai((s) => s.addEndpoint);
  const remove = useSentinai((s) => s.removeEndpoint);
  const allow = useSentinai((s) => s.allow);
  const [name, setName] = useState("");
  const [url, setUrl] = useState("");
  const [model, setModel] = useState("llama-3.1-8b-instruct");
  const canConfigure = allow("model.configure");
  const canExecute = allow("model.execute");

  return (
    <div className="space-y-6">
      <PageHeader
        title="Local model endpoints"
        subtitle="Ping to probe health · fallback priority 1 = primary"
      />
      <div className="grid gap-4 lg:grid-cols-3">
        <Panel title="Register endpoint" className="lg:col-span-1">
          <form
            className="space-y-3"
            onSubmit={(e) => {
              e.preventDefault();
              if (!canConfigure || !name || !url) return;
              add({ name, provider: "custom", url, model });
              setName("");
              setUrl("");
            }}
          >
            <label className="block text-xs text-muted-foreground">
              Name
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="mt-1 h-9 w-full rounded-md border border-input bg-background px-2 text-sm"
              />
            </label>
            <label className="block text-xs text-muted-foreground">
              Base URL
              <input
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="http://localhost:11434"
                className="mt-1 h-9 w-full rounded-md border border-input bg-background px-2 text-sm"
              />
            </label>
            <label className="block text-xs text-muted-foreground">
              Model
              <input
                value={model}
                onChange={(e) => setModel(e.target.value)}
                className="mt-1 h-9 w-full rounded-md border border-input bg-background px-2 text-sm"
              />
            </label>
            <Button type="submit" size="sm" disabled={!canConfigure}>
              Register endpoint
            </Button>
            {!canConfigure ? <p className="text-xs text-warning">Model configuration is restricted for this role.</p> : null}
          </form>
        </Panel>
        <Panel title="Fleet" subtitle={`${endpoints.length} endpoints`} className="lg:col-span-2">
          <div className="space-y-2">
            {endpoints
              .slice()
              .sort((a, b) => a.priority - b.priority)
              .map((ep) => (
                <div key={ep.id} className="rounded-lg border border-border bg-background/40 p-3">
                  <div className="flex flex-wrap items-center gap-2">
                    <StatusBadge status={ep.status} />
                    <span className="text-sm font-medium">{ep.name}</span>
                    <span className="text-mono-xs text-muted-foreground">P{ep.priority}</span>
                    <span className="ml-auto text-mono-xs text-muted-foreground">{ep.provider}</span>
                  </div>
                  <div className="mt-1 truncate text-mono-xs text-muted-foreground">{ep.url}</div>
                  <div className="mt-2 flex flex-wrap items-center gap-3 text-mono-xs text-muted-foreground">
                    <span>{ep.model}</span>
                    <span>p50 {percentile(ep.latencies, 50) ?? "—"}ms</span>
                    <span>p95 {percentile(ep.latencies, 95) ?? "—"}ms</span>
                    <span>{ep.tokensPerSec != null ? `${ep.tokensPerSec.toFixed(0)} tok/s` : "awaiting first probe"}</span>
                    <span>
                      {ep.failedRequests}/{ep.totalRequests} failed
                    </span>
                  </div>
                  <div className="mt-3 flex flex-wrap gap-2">
                    <Button size="sm" variant="outline" disabled={!canExecute} onClick={() => void ping(ep.id)}>
                      Ping
                    </Button>
                    <Button size="sm" variant="ghost" disabled={!canConfigure} onClick={() => remove(ep.id)}>
                      Remove
                    </Button>
                  </div>
                </div>
              ))}
          </div>
        </Panel>
      </div>
    </div>
  );
}
