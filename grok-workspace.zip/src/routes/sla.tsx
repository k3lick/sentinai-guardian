import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, Panel } from "@/components/chrome";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { slaClock, useSentinai } from "@/lib/sentinai/store";
import { formatDuration } from "@/lib/utils";

export const Route = createFileRoute("/sla")({
  head: () => ({ meta: [{ title: "SLA Timers & Escalation · SentinAI" }] }),
  component: SlaPage,
});

const TIERS = [
  { id: 0, label: "On track", tone: "success" as const },
  { id: 1, label: "Tier 1 · assignee warned", tone: "warning" as const },
  { id: 2, label: "Tier 2 · escalated to team lead", tone: "warning" as const },
  { id: 3, label: "Tier 3 · critical SLA breach", tone: "destructive" as const },
];

function SlaPage() {
  const sla = useSentinai((s) => s.sla);
  const update = useSentinai((s) => s.updateSla);
  const incidents = useSentinai((s) => s.incidents);
  const documents = useSentinai((s) => s.documents);
  const allow = useSentinai((s) => s.allow);
  const can = allow("sla.manage");
  const quarantined = documents.filter((d) => d.status === "quarantined");

  function field(key: keyof typeof sla, label: string) {
    return (
      <label className="block text-xs text-muted-foreground">
        {label}
        <input
          type="number"
          min={1}
          value={sla[key]}
          disabled={!can}
          onChange={(e) => update({ [key]: Number(e.target.value) })}
          className="mt-1 h-9 w-full rounded-md border border-input bg-background px-2 text-sm"
        />
      </label>
    );
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Response deadlines" subtitle="Configurable SLA per severity (hours to response)" />
      <div className="grid gap-4 lg:grid-cols-2">
        <Panel title="Policy">
          <div className="grid grid-cols-2 gap-3">
            {field("sev1Minutes", "SEV-1 minutes")}
            {field("sev2Minutes", "SEV-2 minutes")}
            {field("sev3Minutes", "SEV-3 minutes")}
            {field("quarantineMinutes", "Quarantine triage minutes")}
            {field("rollbackMinutes", "Rollback minutes")}
            {field("tier2Pct", "Tier 2 %")}
            {field("tier3Pct", "Tier 3 %")}
          </div>
        </Panel>
        <Panel title="Escalation tiers" subtitle="Thresholds for human escalation">
          <ul className="space-y-2">
            {TIERS.map((t) => (
              <li key={t.id}>
                <Badge tone={t.tone}>{t.label}</Badge>
              </li>
            ))}
          </ul>
        </Panel>
      </div>
      <Panel title="Live countdowns" subtitle="Incidents & quarantine triage deadlines">
        <ul className="space-y-3">
          {incidents
            .filter((i) => i.status !== "resolved")
            .map((i) => {
              const c = slaClock(sla, "incident", i.createdAt, i.severity);
              return (
                <li key={i.id} className="rounded-md border border-border px-3 py-2">
                  <div className="flex justify-between text-sm">
                    <span>
                      {i.id} · {i.title}
                    </span>
                    <span className="text-mono-xs text-muted-foreground">
                      {c.breached ? "breach" : formatDuration(c.remainingMs)}
                    </span>
                  </div>
                  <div className="mt-1 h-1 overflow-hidden rounded-full bg-muted">
                    <div className="h-full bg-primary" style={{ width: `${c.pct}%` }} />
                  </div>
                </li>
              );
            })}
          {quarantined.map((d) => {
            const c = slaClock(sla, "quarantine", d.createdAt);
            return (
              <li key={d.id} className="rounded-md border border-border px-3 py-2">
                <div className="flex justify-between text-sm">
                  <span>quarantine triage → Compliance Officer · {d.name}</span>
                  <span className="text-mono-xs text-muted-foreground">
                    {c.breached ? "breach" : formatDuration(c.remainingMs)}
                  </span>
                </div>
                <div className="mt-1 h-1 overflow-hidden rounded-full bg-muted">
                  <div className="h-full bg-warning" style={{ width: `${c.pct}%` }} />
                </div>
              </li>
            );
          })}
        </ul>
        {!can ? (
          <p className="mt-3 text-xs text-warning">SLA configuration is restricted for this role.</p>
        ) : (
          <Button className="mt-3" size="sm" variant="outline" onClick={() => update({})}>
            Write SLA audit event
          </Button>
        )}
      </Panel>
    </div>
  );
}
