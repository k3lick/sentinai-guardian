import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { IntegrityBanner, Surface } from "@/components/app-shell";
import { PageHeader } from "@/components/page-header";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { SeverityBadge } from "@/components/verdict";
import { formatAgo, formatClock } from "@/lib/cn";
import { useGuardian } from "@/lib/store";
import type { IncidentStatus } from "@/lib/types";

export const Route = createFileRoute("/incidents")({
  component: IncidentsPage,
});

const NEXT: Record<IncidentStatus, IncidentStatus | null> = {
  open: "investigating",
  investigating: "contained",
  contained: "closed",
  closed: null,
};

function IncidentsPage() {
  const incidents = useGuardian((s) => s.incidents);
  const documents = useGuardian((s) => s.documents);
  const setStatus = useGuardian((s) => s.setIncidentStatus);
  const [id, setId] = useState(incidents[0]?.id ?? null);
  const selected = incidents.find((i) => i.id === id) ?? incidents[0];
  const next = selected ? NEXT[selected.status] : null;

  return (
    <div className="stagger-in space-y-6">
      <IntegrityBanner />
      <PageHeader
        kicker="Incidents"
        title="Response queue"
        description="Opened automatically when a scan crosses the critical risk band, or from a denied high-severity verdict."
      />

      <div className="grid gap-3 lg:grid-cols-[0.9fr_1.1fr]">
        <Surface className="p-2 sm:p-3">
          <ul>
            {incidents.map((i) => (
              <li key={i.id}>
                <button
                  type="button"
                  onClick={() => setId(i.id)}
                  className={`w-full rounded-lg px-3 py-3 text-left transition-colors duration-150 ${
                    selected?.id === i.id
                      ? "bg-elevated"
                      : "hover:bg-elevated/60"
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <SeverityBadge severity={i.severity} />
                    <Badge tone={i.status === "closed" ? "ok" : "warn"}>
                      {i.status}
                    </Badge>
                  </div>
                  <p className="mt-1.5 text-sm">{i.title}</p>
                  <p className="mt-1 text-xs text-subtle">{formatAgo(i.openedAt)}</p>
                </button>
              </li>
            ))}
          </ul>
        </Surface>

        {selected ? (
          <Surface className="space-y-4">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <p className="font-mono text-xs text-subtle">{selected.id}</p>
                <h2 className="mt-1 text-lg font-medium tracking-tight text-balance">
                  {selected.title}
                </h2>
                <p className="mt-2 text-sm text-pretty text-muted">
                  {selected.summary}
                </p>
              </div>
              {next ? (
                <Button
                  size="sm"
                  variant="secondary"
                  onClick={() => setStatus(selected.id, next)}
                >
                  Mark {next}
                </Button>
              ) : null}
            </div>
            <p className="text-xs text-muted">
              Assignee {selected.assignee} · opened {formatClock(selected.openedAt)}
            </p>
            <div>
              <h3 className="text-xs font-medium uppercase tracking-wide text-muted">
                Linked documents
              </h3>
              <ul className="mt-2 space-y-1">
                {selected.documentIds.map((did) => {
                  const d = documents.find((x) => x.id === did);
                  return (
                    <li key={did} className="font-mono text-xs text-fg">
                      {d?.name ?? did}
                      {d ? (
                        <span className="ml-2 text-subtle">{d.status}</span>
                      ) : null}
                    </li>
                  );
                })}
              </ul>
            </div>
            <div>
              <h3 className="text-xs font-medium uppercase tracking-wide text-muted">
                Timeline
              </h3>
              <ol className="mt-2 space-y-2">
                {selected.timeline.map((t, idx) => (
                  <li key={`${t.ts}-${idx}`} className="flex gap-3 text-sm">
                    <span className="w-28 shrink-0 tabular text-xs text-subtle">
                      {formatClock(t.ts)}
                    </span>
                    <span>{t.text}</span>
                  </li>
                ))}
              </ol>
            </div>
          </Surface>
        ) : null}
      </div>
    </div>
  );
}
