import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader, Panel } from "@/components/chrome";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import type { SevLevel } from "@/lib/sentinai/types";
import { slaClock, useSentinai } from "@/lib/sentinai/store";
import { formatDuration, formatTime } from "@/lib/utils";

export const Route = createFileRoute("/incidents")({
  head: () => ({ meta: [{ title: "Incident Workspaces · SentinAI" }] }),
  component: IncidentsPage,
});

const SEV: Record<SevLevel, { label: string; tone: "destructive" | "warning" | "muted" }> = {
  sev1: { label: "SEV-1 Critical", tone: "destructive" },
  sev2: { label: "SEV-2 High", tone: "warning" },
  sev3: { label: "SEV-3 Medium", tone: "muted" },
};

const STATUS: Record<string, string> = {
  open: "Open",
  investigating: "Under Investigation",
  mitigated: "Mitigated",
  resolved: "Resolved",
};

function IncidentsPage() {
  const incidents = useSentinai((s) => s.incidents);
  const sla = useSentinai((s) => s.sla);
  const create = useSentinai((s) => s.createIncident);
  const advance = useSentinai((s) => s.advanceIncident);
  const allow = useSentinai((s) => s.allow);
  const [title, setTitle] = useState("");
  const canTriage = allow("incident.triage");

  return (
    <div className="space-y-6">
      <PageHeader
        title="Incidents"
        subtitle={`${incidents.length} total · click status to advance`}
        action={
          <form
            className="flex flex-wrap gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              if (!canTriage || !title.trim()) return;
              create({ title: title.trim(), severity: "sev3", status: "open", assignee: "Unassigned" });
              setTitle("");
            }}
          >
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Create incident"
              className="h-9 w-56 rounded-md border border-input bg-background px-2 text-sm"
            />
            <Button size="sm" disabled={!canTriage}>
              Create
            </Button>
          </form>
        }
      />
      <div className="space-y-3">
        {incidents.map((inc) => {
          const clock = slaClock(sla, "incident", inc.createdAt, inc.severity);
          return (
            <Panel key={inc.id} title={inc.id} subtitle={inc.title}>
              <div className="flex flex-wrap items-center gap-2">
                <Badge tone={SEV[inc.severity].tone}>{SEV[inc.severity].label}</Badge>
                <Button size="sm" variant="outline" disabled={!canTriage} onClick={() => advance(inc.id)}>
                  {STATUS[inc.status]} · Advance status
                </Button>
                <span className="text-xs text-muted-foreground">{inc.assignee}</span>
                <span className="ml-auto text-mono-xs text-muted-foreground">{formatTime(inc.createdAt)}</span>
              </div>
              <div className="mt-3">
                <div className="flex justify-between text-mono-xs text-muted-foreground">
                  <span>SLA {clock.minutes}m</span>
                  <span>{clock.breached ? "breached" : `${formatDuration(clock.remainingMs)} remaining`}</span>
                </div>
                <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-muted">
                  <div
                    className={`h-full ${clock.breached ? "bg-destructive" : clock.tier >= 2 ? "bg-warning" : "bg-success"}`}
                    style={{ width: `${clock.pct}%` }}
                  />
                </div>
              </div>
              {inc.notes.length ? (
                <ul className="mt-3 space-y-1 text-xs text-muted-foreground">
                  {inc.notes.map((n, i) => (
                    <li key={i}>
                      {n.actor}: {n.body}
                    </li>
                  ))}
                </ul>
              ) : null}
            </Panel>
          );
        })}
      </div>
    </div>
  );
}
