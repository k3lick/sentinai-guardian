import {
  createRootRoute,
  HeadContent,
  Outlet,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Toaster } from "sonner";
import { AppShell } from "@/components/app-shell";
import { BootScreen, LockScreen } from "@/components/lock-screen";
import { PreviewHostBridge } from "@/components/preview-host-bridge";
import { AuthProvider } from "@/lib/auth/provider";
import { useGuardian } from "@/lib/store";
import appCss from "../styles.css?url";

const APP_NAME = "SentinAI Guardian";

function Gate() {
  const booted = useGuardian((s) => s.booted);
  const session = useGuardian((s) => s.session);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    let cancelled = false;
    async function run() {
      try {
        await useGuardian.persist.rehydrate();
      } catch {
        /* empty persist is fine */
      }
      if (cancelled) return;
      setHydrated(true);
      await useGuardian.getState().boot();
    }
    void run();
    return () => {
      cancelled = true;
    };
  }, []);

  if (!hydrated) return <BootScreen />;
  if (!session) return <LockScreen />;
  if (!booted) return <BootScreen />;
  return (
    <AppShell>
      <Outlet />
    </AppShell>
  );
}

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: APP_NAME },
      { name: "theme-color", content: "#090a0c" },
      {
        name: "description",
        content:
          "AI fleet policy, document quarantine, and a tamper-evident audit chain.",
      },
    ],
    links: [
      { rel: "icon", type: "image/svg+xml", href: "/favicon.svg" },
      { rel: "stylesheet", href: appCss },
      { rel: "manifest", href: "/__grok/manifest.webmanifest" },
      { rel: "apple-touch-icon", href: "/__grok/icon-180.png" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      {
        rel: "preconnect",
        href: "https://fonts.gstatic.com",
        crossOrigin: "anonymous",
      },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500&family=IBM+Plex+Sans:ital,wght@0,400;0,500;0,600;1,400&display=swap",
      },
    ],
  }),
  component: () => (
    <html lang="en" className="dark antialiased" suppressHydrationWarning>
      <head>
        <HeadContent />
      </head>
      <body className="bg-bg text-fg">
        <PreviewHostBridge />
        <AuthProvider>
          <Gate />
        </AuthProvider>
        <Toaster
          theme="dark"
          position="bottom-right"
          toastOptions={{
            className: "sonner-toast",
            style: {
              background: "var(--color-elevated)",
              border: "1px solid var(--color-border)",
              color: "var(--color-fg)",
            },
          }}
        />
        <Scripts />
      </body>
    </html>
  ),
});
