import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { IntegrityBanner, Surface } from "@/components/app-shell";
import { PageHeader } from "@/components/page-header";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { StatusDot } from "@/components/verdict";
import { formatAgo } from "@/lib/cn";
import { useGuardian } from "@/lib/store";

export const Route = createFileRoute("/fleet")({ component: FleetPage });

function FleetPage() {
  const models = useGuardian((s) => s.models);
  const mode = useGuardian((s) => s.mode);
  const probing = models.some((m) => m.status === "probing");
  const probeAll = useGuardian((s) => s.probeAll);

  async function onProbe() {
    toast.message(mode === "demo" ? "Simulated probe" : "Live probe");
    await probeAll();
    toast.success("Fleet probe complete");
  }

  return (
    <div className="stagger-in space-y-6">
      <IntegrityBanner />
      <PageHeader
        kicker="Fleet"
        title="Model registry"
        description="Ollama, LM Studio and vLLM endpoints. Demo mode uses deterministic latency; live mode probes the local runtimes."
        actions={
          <Button onClick={onProbe} disabled={probing} size="sm">
            {probing ? "Probing…" : "Probe fleet"}
          </Button>
        }
      />

      <div className="grid gap-3">
        {models.map((m) => (
          <Surface key={m.id} className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2">
                <StatusDot status={m.status} />
                <h2 className="text-sm font-medium">{m.name}</h2>
                <Badge tone="neutral">{m.runtime}</Badge>
                <span className="capitalize text-xs text-muted">{m.status}</span>
              </div>
              <p className="mt-1 font-mono text-xs text-subtle">
                {m.model} · {m.endpoint}
              </p>
              <p className="mt-1 text-xs text-muted">{m.place}</p>
              {m.lastError ? (
                <p className="mt-1 text-xs text-danger">{m.lastError}</p>
              ) : null}
            </div>
            <dl className="grid grid-cols-3 gap-4 text-right">
              <div>
                <dt className="text-[0.6875rem] uppercase tracking-wide text-subtle">
                  p50
                </dt>
                <dd className="tabular text-sm">{m.p50} ms</dd>
              </div>
              <div>
                <dt className="text-[0.6875rem] uppercase tracking-wide text-subtle">
                  p95
                </dt>
                <dd className="tabular text-sm">{m.p95} ms</dd>
              </div>
              <div>
                <dt className="text-[0.6875rem] uppercase tracking-wide text-subtle">
                  tok/s
                </dt>
                <dd className="tabular text-sm">{m.tokPerSec}</dd>
              </div>
            </dl>
            <p className="text-xs text-subtle sm:w-28 sm:text-right">
              {m.lastProbedAt ? formatAgo(m.lastProbedAt) : "Never probed"}
            </p>
          </Surface>
        ))}
      </div>
    </div>
  );
}
