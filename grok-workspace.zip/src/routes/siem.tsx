import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, Panel } from "@/components/chrome";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useSentinai } from "@/lib/sentinai/store";
import { formatTime } from "@/lib/utils";

export const Route = createFileRoute("/siem")({
  head: () => ({ meta: [{ title: "SIEM Event Streaming · SentinAI" }] }),
  component: SiemPage,
});

function SiemPage() {
  const siem = useSentinai((s) => s.siem);
  const events = useSentinai((s) => s.siemEvents);
  const toggle = useSentinai((s) => s.toggleSiem);
  const stream = useSentinai((s) => s.streamSiem);
  const webhook = useSentinai((s) => s.webhookUrl);
  const allow = useSentinai((s) => s.allow);
  const can = allow("siem.manage");

  return (
    <div className="space-y-6">
      <PageHeader title="Stream status" subtitle="Event stream in real time" />
      <div className="grid gap-4 lg:grid-cols-2">
        {siem.map((d) => (
          <Panel key={d.id} title={d.name} subtitle={`${d.platform} · ${d.schema} · index ${d.index}`}>
            <div className="flex flex-wrap items-center gap-2">
              <Badge tone={d.enabled ? "success" : "muted"}>{d.enabled ? "enabled" : "paused"}</Badge>
              <span className="text-mono-xs text-muted-foreground">
                sent {d.sent} · failed {d.failed}
              </span>
            </div>
            <div className="mt-2 truncate text-mono-xs text-muted-foreground">{d.endpoint}</div>
            <div className="mt-3 flex flex-wrap gap-2">
              <Button size="sm" variant="outline" disabled={!can} onClick={() => toggle(d.id)}>
                {d.enabled ? "Disable" : "Enable"}
              </Button>
            </div>
          </Panel>
        ))}
      </div>
      <Panel title="Slack notification rules" subtitle="Only critical events page the security team — minor logs stay in SIEM/audit">
        <ul className="space-y-2 text-sm">
          <li className="flex flex-wrap items-center gap-2 rounded-md border border-border px-3 py-2">
            <span>SEV-1 incident created</span>
            <span className="text-mono-xs text-muted-foreground">immediate · severity critical</span>
            <span className="ml-auto text-xs">→ Slack</span>
          </li>
          <li className="flex flex-wrap items-center gap-2 rounded-md border border-border px-3 py-2">
            <span>Critical policy breach (deny + critical)</span>
            <span className="text-mono-xs text-muted-foreground">immediate · severity critical</span>
            <span className="ml-auto text-xs">→ Slack</span>
          </li>
          <li className="flex flex-wrap items-center gap-2 rounded-md border border-border px-3 py-2">
            <span>All other SIEM & audit events</span>
            <span className="text-mono-xs text-muted-foreground">logged only · no Slack alert</span>
            <span className="ml-auto text-xs">→ SIEM/audit</span>
          </li>
        </ul>
        <div className="mt-3 text-xs text-muted-foreground">Webhook endpoint {webhook}</div>
        <Button className="mt-3" size="sm" onClick={() => stream("incident", "SEV-1 incident created", "critical")}>
          Send test event
        </Button>
      </Panel>
      <Panel title="Event stream" subtitle={`${events.length} events · live feed`}>
        {events.length === 0 ? (
          <p className="text-sm text-muted-foreground">Waiting for the first streamed event.</p>
        ) : (
          <ul className="divide-y divide-border/70">
            {events.slice(0, 40).map((e) => (
              <li key={e.id} className="flex flex-wrap items-center gap-3 py-2 text-sm">
                <Badge tone={e.severity === "critical" || e.severity === "high" ? "destructive" : "muted"}>
                  {e.channel}
                </Badge>
                <span className="flex-1 truncate">{e.message}</span>
                <span className="text-mono-xs text-muted-foreground">{formatTime(e.at)}</span>
              </li>
            ))}
          </ul>
        )}
      </Panel>
    </div>
  );
}
