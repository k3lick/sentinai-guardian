import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, Panel, StatCard, StatusBadge } from "@/components/chrome";
import { Button } from "@/components/ui/button";
import { useSentinai } from "@/lib/sentinai/store";
import { formatTime } from "@/lib/utils";

export const Route = createFileRoute("/compliance")({
  head: () => ({ meta: [{ title: "Compliance & Reports · SentinAI" }] }),
  component: CompliancePage,
});

function CompliancePage() {
  const documents = useSentinai((s) => s.documents);
  const audit = useSentinai((s) => s.audit);
  const incidents = useSentinai((s) => s.incidents);
  const siem = useSentinai((s) => s.siem);
  const setStatus = useSentinai((s) => s.setDocumentStatus);
  const allow = useSentinai((s) => s.allow);
  const queue = documents.filter((d) => d.status === "quarantined");
  const siemOn = siem.some((d) => d.enabled);
  const openSev1 = incidents.filter((i) => i.severity === "sev1" && i.status !== "resolved").length;

  const posture = [
    { label: "SIEM streaming enabled", ok: siemOn },
    { label: "Quarantine queue reviewed < 4h target", ok: queue.length === 0 },
    { label: "No unresolved SEV-1", ok: openSev1 === 0 },
    { label: "Audit trail populated", ok: audit.length > 0 },
  ];
  const score = Math.round((posture.filter((p) => p.ok).length / posture.length) * 100);

  function exportEvidence() {
    const payload = {
      generatedAt: new Date().toISOString(),
      posture,
      score,
      incidents: incidents.length,
      documents: documents.length,
      audit: audit.slice(0, 50),
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "sentinai-evidence.json";
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Compliance posture" subtitle="Derived from live state" />
      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard label="Posture score" value={`${score}%`} tone={score >= 75 ? "success" : "warning"} />
        <StatCard label="Triage queue" value={queue.length} hint="Unreviewed quarantined docs escalate to Compliance Officer" />
        <StatCard label="Evidence records" value={audit.length} hint="Audit records available for compliance export" />
      </div>
      <Panel title="Controls">
        <ul className="space-y-2 text-sm">
          {posture.map((p) => (
            <li key={p.label} className="flex items-center justify-between rounded-md border border-border px-3 py-2">
              <span>{p.label}</span>
              <span className={p.ok ? "text-success" : "text-warning"}>{p.ok ? "pass" : "gap"}</span>
            </li>
          ))}
        </ul>
        <Button className="mt-3" size="sm" disabled={!allow("evidence.verify")} onClick={exportEvidence}>
          Export evidence pack
        </Button>
      </Panel>
      <Panel title="Triage queue" subtitle="Unreviewed quarantined docs escalate to Compliance Officer">
        {queue.length === 0 ? (
          <p className="text-sm text-muted-foreground">Queue is clear.</p>
        ) : (
          <ul className="space-y-2">
            {queue.map((d) => (
              <li key={d.id} className="flex flex-wrap items-center gap-2 rounded-md border border-border px-3 py-2">
                <StatusBadge status={d.status} />
                <span className="flex-1 text-sm">{d.name}</span>
                <span className="text-mono-xs text-muted-foreground">{formatTime(d.createdAt)}</span>
                <Button size="sm" disabled={!allow("document.release")} onClick={() => setStatus(d.id, "released")}>
                  Release
                </Button>
              </li>
            ))}
          </ul>
        )}
      </Panel>
    </div>
  );
}
