import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, Panel } from "@/components/chrome";
import { Badge } from "@/components/ui/badge";
import { GOVERNANCE_POLICIES } from "@/lib/sentinai/seed";
import { ACTORS, ROLES } from "@/lib/sentinai/roles";
import { useSentinai } from "@/lib/sentinai/store";

export const Route = createFileRoute("/governance")({
  head: () => ({ meta: [{ title: "Governance · Retention, Dry-Run & Notifications · SentinAI" }] }),
  component: GovernancePage,
});

function GovernancePage() {
  const retention = useSentinai((s) => s.retention);
  const webhook = useSentinai((s) => s.webhookUrl);
  const emails = useSentinai((s) => s.emails);
  const role = useSentinai((s) => s.role);

  return (
    <div className="space-y-6">
      <PageHeader title="Governance policies" subtitle="Agent security controls for acme-core" />
      <Panel>
        <ul className="space-y-2">
          {GOVERNANCE_POLICIES.map((p) => (
            <li key={p.id} className="flex flex-wrap items-center gap-3 rounded-md border border-border px-3 py-2">
              <Badge tone="success">{p.status}</Badge>
              <span className="flex-1 text-sm">{p.title}</span>
              <span className="text-xs text-muted-foreground">{p.owner}</span>
            </li>
          ))}
        </ul>
      </Panel>
      <div className="grid gap-4 lg:grid-cols-2">
        <Panel title="Policy authority" subtitle="Who owns what in the agent security lifecycle">
          <ul className="space-y-2 text-sm">
            {(Object.keys(ROLES) as (keyof typeof ROLES)[]).slice(0, 6).map((id) => (
              <li key={id} className="rounded-md border border-border px-3 py-2">
                <div className="font-medium">{ROLES[id].label}</div>
                <div className="text-xs text-muted-foreground">{ROLES[id].blurb}</div>
                <div className="text-mono-xs text-muted-foreground">{ACTORS[id]}</div>
              </li>
            ))}
          </ul>
        </Panel>
        <Panel title="Retention, dry-run & notifications">
          <dl className="grid grid-cols-2 gap-3 text-sm">
            <div>
              <dt className="text-xs text-muted-foreground">Document retention</dt>
              <dd className="tabular">{retention.documentDays} days</dd>
            </div>
            <div>
              <dt className="text-xs text-muted-foreground">Scan artifacts</dt>
              <dd className="tabular">{retention.scanArtifactHours} hours</dd>
            </div>
            <div>
              <dt className="text-xs text-muted-foreground">Audit retention</dt>
              <dd className="tabular">{retention.auditYears} years</dd>
            </div>
            <div>
              <dt className="text-xs text-muted-foreground">Auto-purge</dt>
              <dd>{retention.autoPurge ? "on" : "dry-run only"}</dd>
            </div>
          </dl>
          <div className="mt-4 text-xs text-muted-foreground">
            Webhook {webhook}
            <br />
            Notify {emails.join(", ")}
            <br />
            Viewing as {ROLES[role].label}
          </div>
        </Panel>
      </div>
    </div>
  );
}
