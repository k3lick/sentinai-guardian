import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { IntegrityBanner, Surface } from "@/components/app-shell";
import { PageHeader } from "@/components/page-header";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { downloadJson } from "@/lib/cn";
import { ENROLLMENT_CODE } from "@/lib/seed";
import { useGuardian } from "@/lib/store";
import type { Mode } from "@/lib/types";

export const Route = createFileRoute("/settings")({ component: SettingsPage });

function SettingsPage() {
  const session = useGuardian((s) => s.session);
  const mode = useGuardian((s) => s.mode);
  const setMode = useGuardian((s) => s.setMode);
  const operators = useGuardian((s) => s.operators);
  const signOut = useGuardian((s) => s.signOut);
  const resetDemo = useGuardian((s) => s.resetDemo);
  const simulateTamper = useGuardian((s) => s.simulateTamper);
  const integrityOk = useGuardian((s) => s.integrityOk);
  const audit = useGuardian((s) => s.audit);

  return (
    <div className="stagger-in space-y-6">
      <IntegrityBanner />
      <PageHeader
        kicker="Settings"
        title="Console"
        description="Mode, operators, and controls that exist so you can break the chain on purpose — then see the integrity badge fail."
      />

      <Surface className="space-y-4">
        <h2 className="text-sm font-medium">Probe mode</h2>
        <div className="flex w-full max-w-sm rounded-lg border border-border bg-bg p-1">
          {(["demo", "live"] as Mode[]).map((m) => (
            <button
              key={m}
              type="button"
              onClick={() => setMode(m)}
              className={`h-9 flex-1 rounded-md text-xs font-medium uppercase tracking-wide ${
                mode === m ? "bg-elevated text-fg" : "text-muted hover:text-fg"
              }`}
            >
              {m}
            </button>
          ))}
        </div>
        <p className="max-w-xl text-sm text-pretty text-muted">
          Demo simulates Ollama, LM Studio and vLLM latency. Live asks those
          local runtimes from this browser; if they are not there, the node is
          marked offline. Policy and quarantine do not change with the mode.
        </p>
      </Surface>

      <Surface className="space-y-3">
        <h2 className="text-sm font-medium">This operator</h2>
        <p className="text-sm">
          {session?.name} · {session?.role}
        </p>
        <p className="font-mono text-xs text-subtle">{session?.email}</p>
        <p className="text-xs text-subtle">
          Enrollment code for new operators: {ENROLLMENT_CODE}
        </p>
        <Button variant="outline" size="sm" onClick={signOut}>
          End session
        </Button>
      </Surface>

      <Surface>
        <h2 className="text-sm font-medium">Operators · dual-control PINs</h2>
        <ul className="mt-3 divide-y divide-border">
          {operators.map((o) => (
            <li
              key={o.id}
              className="flex flex-wrap items-center justify-between gap-2 py-2.5"
            >
              <div>
                <p className="text-sm">
                  {o.name}
                  <span className="text-muted"> · {o.role}</span>
                </p>
                <p className="font-mono text-xs text-subtle">{o.email}</p>
              </div>
              <span className="font-mono text-xs text-muted">PIN {o.pin}</span>
            </li>
          ))}
        </ul>
      </Surface>

      <Surface className="space-y-3">
        <h2 className="text-sm font-medium">Integrity drills</h2>
        <p className="max-w-xl text-sm text-pretty text-muted">
          Tamper rewrites a historical canonical payload without updating its
          hash. The chain cannot be “repaired” — only reset to a fresh genesis.
        </p>
        <div className="flex flex-wrap gap-2">
          <Button
            variant="danger"
            size="sm"
            onClick={async () => {
              await simulateTamper();
              toast.error("Chain verification failed");
            }}
            disabled={!integrityOk}
          >
            Simulate tamper
          </Button>
          <Button
            variant="secondary"
            size="sm"
            onClick={async () => {
              await resetDemo();
              toast.success("Demo workspace reset");
            }}
          >
            Reset demo data
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() =>
              downloadJson(`sentinai-audit-${Date.now()}.json`, audit)
            }
          >
            Export audit
          </Button>
        </div>
        <Badge tone={integrityOk ? "ok" : "danger"}>
          {integrityOk ? "Chain intact" : "Chain broken"}
        </Badge>
      </Surface>
    </div>
  );
}
