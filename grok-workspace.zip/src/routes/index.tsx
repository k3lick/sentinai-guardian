import { createFileRoute, Link } from "@tanstack/react-router";
import { Activity, FileWarning, Gauge, ShieldAlert } from "lucide-react";
import { PageHeader, Panel, StatCard, StatusBadge } from "@/components/chrome";
import { ScenarioCta } from "@/components/scenarios";
import { Button } from "@/components/ui/button";
import { percentile } from "@/lib/utils";
import { formatTime } from "@/lib/utils";
import { useSentinai } from "@/lib/sentinai/store";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [{ title: "SentinAI Overview · Fleet, Quarantine & Access Events" }] }),
  component: Overview,
});

const SEV_COLOR: Record<string, string> = {
  critical: "var(--color-destructive)",
  high: "var(--color-warning)",
  medium: "var(--color-chart-1)",
  low: "var(--color-success)",
};

function Overview() {
  const endpoints = useSentinai((s) => s.endpoints);
  const documents = useSentinai((s) => s.documents);
  const audit = useSentinai((s) => s.audit);
  const incidents = useSentinai((s) => s.incidents);

  const healthy = endpoints.filter((e) => e.status === "healthy").length;
  const degraded = endpoints.filter((e) => e.status === "degraded" || e.status === "offline").length;
  const availability = endpoints.length
    ? Math.round(
        (endpoints.reduce((sum, e) => sum + (e.totalRequests - e.failedRequests), 0) /
          Math.max(1, endpoints.reduce((sum, e) => sum + e.totalRequests, 0))) *
          100,
      )
    : 0;
  const avgP95 = Math.round(
    endpoints.reduce((sum, e) => sum + (percentile(e.latencies, 95) ?? 0), 0) / Math.max(1, endpoints.length),
  );
  const quarantined = documents.filter((d) => d.status === "quarantined");
  const released = documents.filter((d) => d.status === "released" || d.status === "false_positive");
  const releaseRate = documents.length ? Math.round((released.length / Math.max(1, released.length + quarantined.length)) * 100) : 0;
  const findings = documents.flatMap((d) => d.findings);
  const dist = (["critical", "high", "medium", "low"] as const).map((sev) => ({
    sev,
    count: findings.filter((f) => f.severity === sev).length,
  }));
  const total = Math.max(1, dist.reduce((s, d) => s + d.count, 0));
  let offset = 0;
  const slices = dist.map((d) => {
    const pct = (d.count / total) * 100;
    const slice = { ...d, pct, offset };
    offset += pct;
    return slice;
  });
  const stream = audit.filter((e) => e.category !== "scan").slice(0, 8);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Security operations overview"
        subtitle="Cross-system posture across inference fleet, document pipeline, and policy enforcement."
      />
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          label="Fleet availability"
          value={`${availability}%`}
          hint={`${healthy} healthy · ${degraded} degraded/offline · avg p95 ${avgP95 || "—"}ms`}
          icon={<Gauge className="size-4" />}
        />
        <StatCard
          label="Quarantine volume"
          value={quarantined.length}
          hint={`${quarantined.length} pending review · ${releaseRate}% release rate`}
          tone="destructive"
          icon={<FileWarning className="size-4" />}
        />
        <StatCard
          label="Scan findings"
          value={findings.length}
          hint={`${dist[0]?.count ?? 0} critical across ${documents.length} documents`}
          tone="warning"
          icon={<ShieldAlert className="size-4" />}
        />
        <StatCard
          label="Open incidents"
          value={incidents.filter((i) => i.status !== "resolved").length}
          hint={`${incidents.length} total tracked`}
          tone="primary"
          icon={<Activity className="size-4" />}
        />
      </div>
      <div className="grid gap-4 lg:grid-cols-3">
        <Panel title="Severity distribution" subtitle="All active scan findings" className="lg:col-span-1">
          <div className="mt-1 flex items-center gap-5">
            <div
              className="size-32 shrink-0 rounded-full"
              style={{
                background: `conic-gradient(${slices.map((s) => `${SEV_COLOR[s.sev]} ${s.offset}% ${s.offset + s.pct}%`).join(", ")})`,
                mask: "radial-gradient(circle, transparent 54%, black 55%)",
                WebkitMask: "radial-gradient(circle, transparent 54%, black 55%)",
              }}
            />
            <ul className="w-full space-y-2 text-sm">
              {dist.map((d) => (
                <li key={d.sev} className="flex items-center gap-2">
                  <span className="size-2.5 rounded-sm" style={{ background: SEV_COLOR[d.sev] }} />
                  <span className="capitalize text-muted-foreground">{d.sev}</span>
                  <span className="ml-auto font-mono tabular">{d.count}</span>
                </li>
              ))}
            </ul>
          </div>
        </Panel>
        <Panel title="Model fleet" subtitle="Live endpoint health and latency" className="lg:col-span-2">
          <div className="space-y-2">
            {endpoints.map((ep) => (
              <div
                key={ep.id}
                className="flex flex-wrap items-center gap-3 rounded-lg border border-border/70 bg-background/40 px-3 py-2"
              >
                <StatusBadge status={ep.status} />
                <span className="text-sm font-medium">{ep.name}</span>
                <span className="text-mono-xs text-muted-foreground">{ep.model}</span>
                <span className="ml-auto text-mono-xs text-muted-foreground">
                  p50 {percentile(ep.latencies, 50) ?? "—"}ms · p95 {percentile(ep.latencies, 95) ?? "—"}ms ·{" "}
                  {ep.tokensPerSec ? `${ep.tokensPerSec.toFixed(0)} tok/s` : "no tokens"}
                </span>
              </div>
            ))}
          </div>
          <div className="mt-4 flex flex-wrap gap-2">
            <Button asChild size="sm" variant="outline">
              <Link to="/models">Orchestration console</Link>
            </Button>
            <Button asChild size="sm" variant="outline">
              <Link to="/documents">Documents</Link>
            </Button>
            <Button asChild size="sm" variant="outline">
              <Link to="/audit">Audit log</Link>
            </Button>
            <Button asChild size="sm" variant="outline">
              <Link to="/guardrails">Policies</Link>
            </Button>
          </div>
        </Panel>
      </div>
      <Panel title="Live security & access-control stream" subtitle="Role changes, blocked actions, policy decisions">
        {stream.length === 0 ? (
          <ScenarioCta
            title="No access-control activity recorded yet"
            body="Scenarios drive real quarantine decisions, policy verdicts and role events straight into this stream."
            scenario="credential_leak"
          />
        ) : null}
        <ul className="mt-3 divide-y divide-border/70">
          {stream.map((ev) => (
            <li key={ev.id} className="flex flex-wrap items-center gap-3 py-2.5 text-sm">
              <span className="rounded-md border border-border px-1.5 py-0.5 text-mono-xs uppercase text-muted-foreground">
                {ev.action}
              </span>
              <span className="min-w-0 flex-1 truncate">{ev.message}</span>
              <span className="text-mono-xs text-muted-foreground">{formatTime(ev.at)}</span>
            </li>
          ))}
        </ul>
      </Panel>
    </div>
  );
}
