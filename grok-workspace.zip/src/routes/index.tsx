import { createFileRoute, Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { IntegrityBanner, Surface } from "@/components/app-shell";
import { PageHeader } from "@/components/page-header";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { StatusDot } from "@/components/verdict";
import { formatAgo } from "@/lib/cn";
import { deriveMetrics } from "@/lib/metrics";
import { SCENARIOS } from "@/lib/scenarios";
import { useGuardian } from "@/lib/store";
import type { Severity } from "@/lib/types";

export const Route = createFileRoute("/")({ component: OverviewPage });

function Kpi({
  label,
  value,
  hint,
}: {
  label: string;
  value: string;
  hint: string;
}) {
  return (
    <Surface className="p-4">
      <p className="text-xs font-medium uppercase tracking-[0.12em] text-muted">
        {label}
      </p>
      <p className="mt-2 text-3xl font-medium tabular tracking-tight">{value}</p>
      <p className="mt-1 text-xs text-subtle">{hint}</p>
    </Surface>
  );
}

function OverviewPage() {
  const models = useGuardian((s) => s.models);
  const documents = useGuardian((s) => s.documents);
  const incidents = useGuardian((s) => s.incidents);
  const siem = useGuardian((s) => s.siem);
  const running = useGuardian((s) => s.scenarioRunning);
  const runScenario = useGuardian((s) => s.runScenario);
  const m = deriveMetrics(models, documents, incidents);
  const open = incidents.find((i) => i.status !== "closed");
  const sevOrder: Severity[] = ["critical", "high", "medium", "low"];
  const sevTotal = sevOrder.reduce((s, k) => s + m.severity[k], 0) || 1;

  async function play(id: (typeof SCENARIOS)[number]["id"]) {
    const def = SCENARIOS.find((s) => s.id === id);
    toast.message("Running scenario", { description: def?.title });
    await runScenario(id);
    toast.success("Scenario recorded", {
      description: "Verdict, SIEM and audit chain updated.",
    });
  }

  return (
    <div className="stagger-in space-y-6">
      <IntegrityBanner />
      <PageHeader
        kicker="Overview"
        title="Fleet, quarantine and access events"
        description="Cross-system posture across the inference fleet, document pipeline, and policy enforcement."
        actions={
          <Button
            size="sm"
            onClick={() => play("cred-leak")}
            disabled={running}
          >
            Run scenario
          </Button>
        }
      />

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Kpi
          label="Fleet availability"
          value={`${m.availability}%`}
          hint={`${m.healthy} healthy · ${m.degraded} degraded · ${m.offline} offline · avg p95 ${m.avgP95}ms`}
        />
        <Kpi
          label="Quarantine volume"
          value={String(m.quarantine)}
          hint={`${m.pendingReview} pending review · ${m.releaseRate}% release rate`}
        />
        <Kpi
          label="Scan findings"
          value={String(m.findings)}
          hint={`${m.criticalFindings} critical across ${m.documents} documents`}
        />
        <Kpi
          label="Open incidents"
          value={String(m.openIncidents)}
          hint={`${m.totalIncidents} total tracked`}
        />
      </div>

      <div className="grid gap-3 lg:grid-cols-2">
        <Surface>
          <h2 className="text-sm font-medium">Severity distribution</h2>
          <p className="mt-0.5 text-xs text-muted">
            Active findings on held documents
          </p>
          <div className="mt-4 space-y-3">
            {sevOrder.map((k) => (
              <div key={k}>
                <div className="mb-1 flex justify-between text-xs">
                  <span className="capitalize text-muted">{k}</span>
                  <span className="tabular text-fg">{m.severity[k]}</span>
                </div>
                <div className="h-1.5 overflow-hidden rounded-full bg-elevated">
                  <div
                    className={
                      k === "critical"
                        ? "h-full bg-danger"
                        : k === "high"
                          ? "h-full bg-warn"
                          : k === "medium"
                            ? "h-full bg-info"
                            : "h-full bg-subtle"
                    }
                    style={{
                      width: `${Math.round((m.severity[k] / sevTotal) * 100)}%`,
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </Surface>

        <Surface>
          <div className="flex items-center justify-between gap-2">
            <div>
              <h2 className="text-sm font-medium">Model fleet</h2>
              <p className="mt-0.5 text-xs text-muted">
                Live endpoint health and latency
              </p>
            </div>
            <Link
              to="/fleet"
              className="text-xs text-muted hover:text-fg"
            >
              Open fleet
            </Link>
          </div>
          <ul className="mt-4 divide-y divide-border">
            {models.map((model) => (
              <li key={model.id} className="flex items-start gap-3 py-3 first:pt-0 last:pb-0">
                <div className="mt-1.5">
                  <StatusDot status={model.status} />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm">
                    {model.name}
                    <span className="text-muted"> · {model.runtime} {model.model}</span>
                  </p>
                  <p className="tabular text-xs text-subtle">
                    p50 {model.p50} ms · p95 {model.p95} ms · {model.tokPerSec} tok/s
                  </p>
                </div>
                <span className="shrink-0 text-xs capitalize text-muted">
                  {model.status}
                </span>
              </li>
            ))}
          </ul>
        </Surface>
      </div>

      {open ? (
        <Surface className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <Badge tone="danger">{open.severity}</Badge>
            <p className="mt-2 text-sm font-medium">{open.title}</p>
            <p className="mt-1 text-xs text-muted">{open.summary}</p>
          </div>
          <Link
            to="/incidents"
            className="text-sm text-accent hover:opacity-80"
          >
            Open incident
          </Link>
        </Surface>
      ) : null}

      <div className="grid gap-3 lg:grid-cols-[1.2fr_0.8fr]">
        <Surface>
          <h2 className="text-sm font-medium">Live security stream</h2>
          <p className="mt-0.5 text-xs text-muted">
            Role changes, blocked actions, policy decisions
          </p>
          <ul className="mt-4 max-h-80 space-y-3 overflow-auto">
            {siem.length === 0 ? (
              <li className="text-sm text-muted">
                No access-control activity recorded yet.
              </li>
            ) : (
              siem.slice(0, 12).map((ev) => (
                <li key={ev.id} className="flex gap-3 text-sm">
                  <span className="w-16 shrink-0 tabular text-xs text-subtle">
                    {formatAgo(ev.ts)}
                  </span>
                  <div className="min-w-0">
                    <p className="truncate text-fg">{ev.message}</p>
                    <p className="truncate font-mono text-[0.6875rem] text-subtle">
                      {typeof ev.extras.excerpt === "string"
                        ? ev.extras.excerpt
                        : ev.severity}
                    </p>
                  </div>
                </li>
              ))
            )}
          </ul>
        </Surface>
        <Surface>
          <h2 className="text-sm font-medium">Scenarios</h2>
          <p className="mt-0.5 text-xs text-muted">
            Drive real quarantine decisions, policy verdicts and SIEM fan-out.
          </p>
          <ul className="mt-4 space-y-2">
            {SCENARIOS.map((s) => (
              <li key={s.id}>
                <button
                  type="button"
                  disabled={running}
                  onClick={() => play(s.id)}
                  className="w-full rounded-lg border border-border px-3 py-2.5 text-left transition-colors duration-150 hover:border-border-strong hover:bg-elevated disabled:opacity-50"
                >
                  <p className="text-sm text-fg">{s.title}</p>
                  <p className="mt-0.5 text-xs text-pretty text-muted">{s.blurb}</p>
                </button>
              </li>
            ))}
          </ul>
        </Surface>
      </div>
    </div>
  );
}
