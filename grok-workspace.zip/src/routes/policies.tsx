import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { IntegrityBanner, Surface } from "@/components/app-shell";
import { PageHeader } from "@/components/page-header";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/input";
import { SeverityBadge, VerdictBadge } from "@/components/verdict";
import { formatAgo } from "@/lib/cn";
import { POLICY_RULES, SAMPLE_PROMPTS } from "@/lib/policy";
import { useGuardian } from "@/lib/store";

export const Route = createFileRoute("/policies")({ component: PoliciesPage });

function PoliciesPage() {
  const [text, setText] = useState(SAMPLE_PROMPTS[0]!.text);
  const evaluate = useGuardian((s) => s.evaluate);
  const history = useGuardian((s) => s.evaluations);
  const [busy, setBusy] = useState(false);
  const latest = history[0];

  async function onEval() {
    if (!text.trim()) return;
    setBusy(true);
    try {
      const ev = await evaluate(text, "playground");
      toast.message(`Verdict ${ev.verdict}`, {
        description: ev.primaryId
          ? `Matched ${ev.primaryId} in ${ev.latencyMs}ms`
          : `Default allow in ${ev.latencyMs}ms`,
      });
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="stagger-in space-y-6">
      <IntegrityBanner />
      <PageHeader
        kicker="Policies"
        title="Deterministic policy engine"
        description="Content is matched against a closed rule set. The model never unlocks a DENY. HUMAN holds for an operator."
      />

      <div className="grid gap-3 lg:grid-cols-[1.1fr_0.9fr]">
        <Surface>
          <h2 className="text-sm font-medium">Playground</h2>
          <p className="mt-0.5 text-xs text-muted">
            Paste an agent action, prompt, or SQL. The engine returns exactly one verdict.
          </p>
          <div className="mt-3 flex flex-wrap gap-1.5">
            {SAMPLE_PROMPTS.map((s) => (
              <button
                key={s.label}
                type="button"
                onClick={() => setText(s.text)}
                className="h-8 rounded-full border border-border px-2.5 text-xs text-muted hover:border-border-strong hover:text-fg"
              >
                {s.label}
              </button>
            ))}
          </div>
          <Textarea
            className="mt-3 min-h-36 font-mono text-xs"
            value={text}
            onChange={(e) => setText(e.target.value)}
          />
          <div className="mt-3 flex items-center gap-2">
            <Button onClick={onEval} disabled={busy} size="sm">
              {busy ? "Evaluating…" : "Evaluate"}
            </Button>
            {latest && latest.input === text ? (
              <div className="flex items-center gap-2">
                <VerdictBadge verdict={latest.verdict} />
                <span className="tabular text-xs text-subtle">
                  {latest.latencyMs} ms
                </span>
              </div>
            ) : null}
          </div>
          {latest && latest.input === text ? (
            <ul className="mt-4 space-y-2">
              {latest.matched.length === 0 ? (
                <li className="text-sm text-muted">
                  No rules matched · default ALLOW (AL-000).
                </li>
              ) : (
                latest.matched.map((h) => (
                  <li
                    key={h.ruleId}
                    className="rounded-md border border-border bg-bg px-3 py-2"
                  >
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-mono text-xs">{h.ruleId}</span>
                      <span className="text-sm">{h.title}</span>
                      <VerdictBadge verdict={h.verdict} />
                    </div>
                    <p className="mt-1 font-mono text-[0.6875rem] text-subtle">
                      {h.excerpt}
                    </p>
                  </li>
                ))
              )}
            </ul>
          ) : null}
        </Surface>

        <Surface>
          <h2 className="text-sm font-medium">Recent verdicts</h2>
          <ul className="mt-4 max-h-[28rem] space-y-3 overflow-auto">
            {history.length === 0 ? (
              <li className="text-sm text-muted">
                Evaluate a sample to populate history. Seeded incidents already sit on the audit chain.
              </li>
            ) : (
              history.slice(0, 16).map((ev) => (
                <li key={ev.id} className="flex items-start gap-3">
                  <VerdictBadge verdict={ev.verdict} />
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-mono text-xs">
                      {ev.primaryId ?? "AL-000"} · {ev.source}
                    </p>
                    <p className="truncate text-xs text-muted">{ev.input}</p>
                  </div>
                  <span className="shrink-0 text-[0.6875rem] text-subtle">
                    {formatAgo(ev.ts)}
                  </span>
                </li>
              ))
            )}
          </ul>
        </Surface>
      </div>

      <Surface className="overflow-x-auto p-0">
        <table className="w-full min-w-[40rem] text-left text-sm">
          <thead className="border-b border-border text-xs uppercase tracking-wide text-muted">
            <tr>
              <th className="px-5 py-3 font-medium">ID</th>
              <th className="px-3 py-3 font-medium">Rule</th>
              <th className="px-3 py-3 font-medium">Category</th>
              <th className="px-3 py-3 font-medium">Verdict</th>
              <th className="px-5 py-3 font-medium">Severity</th>
            </tr>
          </thead>
          <tbody>
            {POLICY_RULES.map((r) => (
              <tr key={r.id} className="border-b border-border last:border-0">
                <td className="px-5 py-3 font-mono text-xs">{r.id}</td>
                <td className="px-3 py-3">
                  <p>{r.title}</p>
                  <p className="max-w-md text-xs text-pretty text-muted">
                    {r.description}
                  </p>
                </td>
                <td className="px-3 py-3 capitalize text-muted">{r.category}</td>
                <td className="px-3 py-3">
                  <VerdictBadge verdict={r.verdict} />
                </td>
                <td className="px-5 py-3">
                  <SeverityBadge severity={r.severity} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Surface>
    </div>
  );
}
