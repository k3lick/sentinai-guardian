import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { EmptyState, IntegrityBanner, Surface } from "@/components/app-shell";
import { PageHeader } from "@/components/page-header";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input, Label } from "@/components/ui/input";
import { SeverityBadge } from "@/components/verdict";
import { formatAgo } from "@/lib/cn";
import { useGuardian } from "@/lib/store";
import type { GuardianDoc } from "@/lib/types";

export const Route = createFileRoute("/quarantine")({
  component: QuarantinePage,
});

function DualDots({ doc }: { doc: GuardianDoc }) {
  return (
    <div className="flex items-center gap-2 text-xs text-muted">
      <span
        className={`size-2 rounded-full ${doc.firstAuth ? "bg-ok" : "bg-subtle"}`}
      />
      <span>{doc.firstAuth ? doc.firstAuth.name : "First signature"}</span>
      <span className="text-subtle">→</span>
      <span
        className={`size-2 rounded-full ${doc.secondAuth ? "bg-ok" : "bg-subtle"}`}
      />
      <span>{doc.secondAuth ? doc.secondAuth.name : "Countersign"}</span>
    </div>
  );
}

function QuarantinePage() {
  const documents = useGuardian((s) => s.documents);
  const operators = useGuardian((s) => s.operators);
  const session = useGuardian((s) => s.session);
  const signFirst = useGuardian((s) => s.signFirst);
  const signSecond = useGuardian((s) => s.signSecond);
  const held = documents.filter((d) => d.status !== "clean");
  const [active, setActive] = useState<string | null>(null);
  const [opId, setOpId] = useState(operators.find((o) => o.id !== session?.operatorId)?.id ?? "");
  const [pin, setPin] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const doc = useMemo(
    () => documents.find((d) => d.id === active) ?? null,
    [documents, active],
  );

  async function first(id: string) {
    const msg = await signFirst(id);
    if (msg) toast.error(msg);
    else toast.success("First signature recorded");
  }

  async function second() {
    if (!doc) return;
    const msg = await signSecond(doc.id, opId, pin);
    if (msg) {
      setErr(msg);
      return;
    }
    toast.success("Released under 4-eyes");
    setActive(null);
    setPin("");
    setErr(null);
  }

  return (
    <div className="stagger-in space-y-6">
      <IntegrityBanner />
      <PageHeader
        kicker="Quarantine"
        title="Four-eyes release"
        description="Held documents require two distinct operators. The second signature is PIN-gated and written to the hash chain."
      />

      {held.length === 0 ? (
        <Surface>
          <EmptyState
            title="Nothing held"
            body="Scan a document with live keys or PII, or run the credential-leak scenario from Overview."
          />
        </Surface>
      ) : (
        <div className="grid gap-3">
          {held.map((d) => (
            <Surface key={d.id} className="space-y-3">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <h2 className="font-mono text-sm">{d.name}</h2>
                    <Badge
                      tone={
                        d.status === "released"
                          ? "ok"
                          : d.status === "awaiting-second"
                            ? "warn"
                            : "danger"
                      }
                    >
                      {d.status.replace("-", " ")}
                    </Badge>
                    <span className="tabular text-xs text-muted">
                      risk {d.riskScore}
                    </span>
                  </div>
                  <p className="mt-1 text-xs text-subtle">{formatAgo(d.ts)}</p>
                </div>
                <div className="flex flex-wrap gap-2">
                  {d.status === "quarantined" ? (
                    <Button size="sm" onClick={() => first(d.id)}>
                      Sign as first
                    </Button>
                  ) : null}
                  {d.status === "awaiting-second" ? (
                    <Button size="sm" onClick={() => setActive(d.id)}>
                      Countersign
                    </Button>
                  ) : null}
                </div>
              </div>
              <DualDots doc={d} />
              <ul className="flex flex-wrap gap-1.5">
                {d.findings.slice(0, 6).map((f) => (
                  <li key={f.id}>
                    <SeverityBadge severity={f.severity} />
                    <span className="ml-1 text-xs text-muted">{f.label}</span>
                  </li>
                ))}
              </ul>
            </Surface>
          ))}
        </div>
      )}

      {doc ? (
        <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center">
          <button
            type="button"
            className="absolute inset-0 bg-bg/70"
            aria-label="Dismiss"
            onClick={() => setActive(null)}
          />
          <div className="relative m-4 w-full max-w-md rounded-xl border border-border bg-surface p-5">
            <h3 className="text-base font-medium">Countersign {doc.name}</h3>
            <p className="mt-1 text-sm text-muted">
              First signature: {doc.firstAuth?.name}. Choose a different operator
              and enter their PIN.
            </p>
            <div className="mt-4 space-y-3">
              <div className="space-y-1.5">
                <Label htmlFor="op">Second operator</Label>
                <select
                  id="op"
                  value={opId}
                  onChange={(e) => setOpId(e.target.value)}
                  className="h-11 w-full rounded-md border border-border bg-bg px-3 text-sm text-fg outline-none focus:ring-2 focus:ring-accent/25"
                >
                  {operators.map((o) => (
                    <option key={o.id} value={o.id}>
                      {o.name} · {o.role}
                    </option>
                  ))}
                </select>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="pin">PIN</Label>
                <Input
                  id="pin"
                  inputMode="numeric"
                  value={pin}
                  onChange={(e) => setPin(e.target.value)}
                  placeholder="Four digits"
                />
                <p className="text-xs text-subtle">
                  Demo PINs — Maya 2210 · Jordan 4821 · Samira 7730
                </p>
              </div>
              {err ? <p className="text-sm text-danger">{err}</p> : null}
              <div className="flex justify-end gap-2">
                <Button variant="ghost" size="sm" onClick={() => setActive(null)}>
                  Cancel
                </Button>
                <Button size="sm" onClick={second}>
                  Release document
                </Button>
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
