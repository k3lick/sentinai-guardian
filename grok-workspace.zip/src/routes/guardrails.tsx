import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader, Panel } from "@/components/chrome";
import { ScenarioCta } from "@/components/scenarios";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { TOOL_LABELS } from "@/lib/sentinai/policies";
import type { ToolKind } from "@/lib/sentinai/types";
import { useSentinai } from "@/lib/sentinai/store";
import { formatTime } from "@/lib/utils";

export const Route = createFileRoute("/guardrails")({
  head: () => ({ meta: [{ title: "Agent Guardrails & MCP Interceptor · SentinAI" }] }),
  component: GuardrailsPage,
});

const TOOLS: ToolKind[] = ["db.query", "http.request", "fs.write", "mcp.invoke", "mail.send"];

function GuardrailsPage() {
  const run = useSentinai((s) => s.runToolCall);
  const calls = useSentinai((s) => s.toolCalls);
  const allow = useSentinai((s) => s.allow);
  const [tool, setTool] = useState<ToolKind>("db.query");
  const [statement, setStatement] = useState("select * from invoices limit 20");
  const [url, setUrl] = useState("https://api.company.com/v1/health");
  const [server, setServer] = useState("internal-crm");
  const [mcpTool, setMcpTool] = useState("lookup_account");
  const [to, setTo] = useState("soc@company.com");
  const [path, setPath] = useState("/workspace/out/notes.md");
  const last = calls[0];

  function simulate() {
    if (!allow("guardrail.test")) return;
    const params: Record<string, string | number> =
      tool === "db.query"
        ? { statement }
        : tool === "http.request"
          ? { url, method: "GET" }
          : tool === "fs.write"
            ? { path, bytes: 420 }
            : tool === "mcp.invoke"
              ? { server, tool: mcpTool }
              : { to, subject: "Weekly digest" };
    run("prompt-testbed", tool, params);
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Tool call simulator"
        subtitle="Real policy engine — verdicts derived from statement content"
      />
      <div className="grid gap-4 lg:grid-cols-2">
        <Panel title="Prompt testbed" subtitle="Check a prompt against guardrails">
          <label className="block text-xs text-muted-foreground">
            Tool
            <select
              value={tool}
              onChange={(e) => setTool(e.target.value as ToolKind)}
              className="mt-1 h-9 w-full rounded-md border border-input bg-background px-2 text-sm"
            >
              {TOOLS.map((t) => (
                <option key={t} value={t}>
                  {TOOL_LABELS[t]}
                </option>
              ))}
            </select>
          </label>
          {tool === "db.query" ? (
            <textarea
              value={statement}
              onChange={(e) => setStatement(e.target.value)}
              rows={4}
              className="mt-3 w-full rounded-md border border-input bg-background p-2 font-mono text-xs"
            />
          ) : null}
          {tool === "http.request" ? (
            <input
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              className="mt-3 h-9 w-full rounded-md border border-input bg-background px-2 text-sm"
            />
          ) : null}
          {tool === "fs.write" ? (
            <input
              value={path}
              onChange={(e) => setPath(e.target.value)}
              className="mt-3 h-9 w-full rounded-md border border-input bg-background px-2 text-sm"
            />
          ) : null}
          {tool === "mcp.invoke" ? (
            <div className="mt-3 grid gap-2 sm:grid-cols-2">
              <input
                value={server}
                onChange={(e) => setServer(e.target.value)}
                className="h-9 rounded-md border border-input bg-background px-2 text-sm"
              />
              <input
                value={mcpTool}
                onChange={(e) => setMcpTool(e.target.value)}
                className="h-9 rounded-md border border-input bg-background px-2 text-sm"
              />
            </div>
          ) : null}
          {tool === "mail.send" ? (
            <input
              value={to}
              onChange={(e) => setTo(e.target.value)}
              className="mt-3 h-9 w-full rounded-md border border-input bg-background px-2 text-sm"
            />
          ) : null}
          <Button className="mt-3" size="sm" disabled={!allow("guardrail.test")} onClick={simulate}>
            Evaluate
          </Button>
        </Panel>
        <Panel title="Policy inspector" subtitle="Verdict · matched rule · timestamp">
          {!last ? (
            <ScenarioCta
              title="No policy decisions yet"
              body="Simulate a destructive SQL statement or run the malicious tool-call scenario."
              scenario="malicious_tool"
            />
          ) : (
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <Badge
                  tone={last.verdict === "denied" ? "destructive" : last.verdict === "approval_required" ? "warning" : "success"}
                >
                  {last.verdict.replace("_", " ")}
                </Badge>
                <span className="text-sm font-medium">{last.rule}</span>
              </div>
              <p className="mt-2 text-sm text-muted-foreground">{last.rationale}</p>
              <ul className="mt-3 space-y-1 text-xs">
                {last.checks.map((c) => (
                  <li key={c.label} className="flex items-center gap-2">
                    <span className={c.pass ? "text-success" : "text-destructive"}>{c.pass ? "pass" : "fail"}</span>
                    <span className="text-muted-foreground">{c.field}</span>
                    <span>{c.label}</span>
                  </li>
                ))}
              </ul>
              <div className="mt-2 text-mono-xs text-muted-foreground">{formatTime(last.at)}</div>
            </div>
          )}
        </Panel>
      </div>
      <Panel title="Recent policy decisions" subtitle="Every verdict logged with correct severity">
        {calls.length === 0 ? (
          <p className="text-sm text-muted-foreground">Empty until a tool call is evaluated.</p>
        ) : (
          <ul className="divide-y divide-border/70">
            {calls.slice(0, 12).map((c) => (
              <li key={c.id} className="flex flex-wrap items-center gap-3 py-2.5 text-sm">
                <Badge tone={c.verdict === "denied" ? "destructive" : c.verdict === "approval_required" ? "warning" : "success"}>
                  {c.verdict}
                </Badge>
                <span className="flex-1 truncate">{c.rule}</span>
                <span className="text-mono-xs text-muted-foreground">{c.agent}</span>
                <span className="text-mono-xs text-muted-foreground">{formatTime(c.at)}</span>
              </li>
            ))}
          </ul>
        )}
      </Panel>
    </div>
  );
}
