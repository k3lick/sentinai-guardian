import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { PageHeader, Panel } from "@/components/chrome";
import { formatTime } from "@/lib/utils";
import { useSentinai } from "@/lib/sentinai/store";

export const Route = createFileRoute("/registry")({
  head: () => ({ meta: [{ title: "Model Registry & Rollback · SentinAI" }] }),
  component: RegistryPage,
});

function RegistryPage() {
  const models = useSentinai((s) => s.models);
  const deployments = useSentinai((s) => s.deployments);
  const deploy = useSentinai((s) => s.deploy);
  const rollback = useSentinai((s) => s.rollback);
  const flag = useSentinai((s) => s.flagVersion);
  const allow = useSentinai((s) => s.allow);
  const [selected, setSelected] = useState(models[0]?.id);
  const current = models.find((m) => m.id === selected) ?? models[0];
  const families = [...new Set(models.map((m) => m.family))];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Registered models"
        subtitle={`${families.length} distinct models across ${models.length} versions`}
      />
      <div className="grid gap-4 lg:grid-cols-3">
        <Panel title="Catalog" className="lg:col-span-1">
          <ul className="space-y-1.5">
            {models.map((m) => (
              <li key={m.id}>
                <button
                  onClick={() => setSelected(m.id)}
                  className={`w-full rounded-md border px-3 py-2 text-left text-sm ${m.id === current?.id ? "border-primary/40 bg-primary/5" : "border-border bg-background/40"}`}
                >
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{m.family}</span>
                    <span className="text-mono-xs text-muted-foreground">{m.version}</span>
                    {m.active ? <Badge tone="success">active</Badge> : null}
                    {m.problematic ? <Badge tone="destructive">break</Badge> : null}
                  </div>
                  <div className="mt-0.5 text-mono-xs text-muted-foreground">
                    {m.provider} · {m.quantization}
                  </div>
                </button>
              </li>
            ))}
          </ul>
        </Panel>
        {current ? (
          <Panel title="Model detail" subtitle="Deployment metadata & rollback" className="lg:col-span-2">
            <dl className="grid grid-cols-2 gap-3 text-sm">
              <div>
                <dt className="text-xs text-muted-foreground">Family</dt>
                <dd>{current.family}</dd>
              </div>
              <div>
                <dt className="text-xs text-muted-foreground">Version</dt>
                <dd className="tabular">{current.version}</dd>
              </div>
              <div>
                <dt className="text-xs text-muted-foreground">Context</dt>
                <dd className="tabular">{current.contextWindow.toLocaleString()}</dd>
              </div>
              <div>
                <dt className="text-xs text-muted-foreground">Quantization</dt>
                <dd>{current.quantization}</dd>
              </div>
            </dl>
            <div className="mt-3 flex flex-wrap gap-1.5">
              {current.tags.map((t) => (
                <Badge key={t} tone="muted">
                  {t}
                </Badge>
              ))}
            </div>
            <div className="mt-4 grid grid-cols-2 gap-2 text-xs">
              {(
                [
                  ["Context length", current.compat.contextLength],
                  ["Tool-calling schema", current.compat.toolCallingSchema],
                  ["SSE streaming", current.compat.streamingSse],
                  ["Embeddings", current.compat.embeddings],
                ] as const
              ).map(([label, ok]) => (
                <div key={label} className="rounded-md border border-border px-2 py-1.5">
                  {ok ? "Pass" : "Fail"} · {label}
                </div>
              ))}
            </div>
            <div className="mt-4 flex flex-wrap gap-2">
              <Button size="sm" disabled={!allow("registry.manage")} onClick={() => deploy(current.id)}>
                Deploy
              </Button>
              <Button size="sm" variant="outline" disabled={!allow("rollback.execute")} onClick={() => rollback(current.family)}>
                Rollback
              </Button>
              <Button size="sm" variant="ghost" onClick={() => flag(current.id)}>
                Mark problematic
              </Button>
            </div>
          </Panel>
        ) : null}
      </div>
      <Panel title="Deployment history" subtitle="Promotions & rollbacks">
        <ul className="divide-y divide-border/70">
          {deployments.map((d) => (
            <li key={d.id} className="flex flex-wrap items-center gap-3 py-2.5 text-sm">
              <Badge tone={d.kind === "rollback" ? "warning" : d.kind === "flag" ? "destructive" : "primary"}>{d.kind}</Badge>
              <span className="flex-1">{d.versionLabel}</span>
              <span className="text-mono-xs text-muted-foreground">{d.actor}</span>
              <span className="text-mono-xs text-muted-foreground">{formatTime(d.at)}</span>
            </li>
          ))}
        </ul>
      </Panel>
    </div>
  );
}
