//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DtUBSAPv.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/approvals",
			"/audit",
			"/compliance",
			"/documents",
			"/governance",
			"/guardrails",
			"/incidents",
			"/models",
			"/registry",
			"/siem",
			"/sla"
		],
		preloads: ["/assets/index-vixYyLpj.js", "/assets/store-CexRa3sp.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-vixYyLpj.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-B3-NPaAs.js", "/assets/chrome-Bh56kLAY.js"]
	},
	"/approvals": {
		filePath: "/workspace/src/routes/approvals.tsx",
		children: void 0,
		preloads: ["/assets/approvals-CAisc9bb.js", "/assets/chrome-Bh56kLAY.js"]
	},
	"/audit": {
		filePath: "/workspace/src/routes/audit.tsx",
		children: void 0,
		preloads: ["/assets/audit-B_ZRHaGM.js", "/assets/chrome-Bh56kLAY.js"]
	},
	"/compliance": {
		filePath: "/workspace/src/routes/compliance.tsx",
		children: void 0,
		preloads: ["/assets/compliance-D5Ejoi6K.js", "/assets/chrome-Bh56kLAY.js"]
	},
	"/documents": {
		filePath: "/workspace/src/routes/documents.tsx",
		children: void 0,
		preloads: ["/assets/documents-1hCgI8oq.js", "/assets/chrome-Bh56kLAY.js"]
	},
	"/governance": {
		filePath: "/workspace/src/routes/governance.tsx",
		children: void 0,
		preloads: ["/assets/governance-jXvfJtTl.js", "/assets/chrome-Bh56kLAY.js"]
	},
	"/guardrails": {
		filePath: "/workspace/src/routes/guardrails.tsx",
		children: void 0,
		preloads: ["/assets/guardrails-ll8rGwDl.js", "/assets/chrome-Bh56kLAY.js"]
	},
	"/incidents": {
		filePath: "/workspace/src/routes/incidents.tsx",
		children: void 0,
		preloads: ["/assets/incidents-CpVKn06y.js", "/assets/chrome-Bh56kLAY.js"]
	},
	"/models": {
		filePath: "/workspace/src/routes/models.tsx",
		children: void 0,
		preloads: ["/assets/models-DynAFrbY.js", "/assets/chrome-Bh56kLAY.js"]
	},
	"/registry": {
		filePath: "/workspace/src/routes/registry.tsx",
		children: void 0,
		preloads: ["/assets/registry-B1KiGtRQ.js", "/assets/chrome-Bh56kLAY.js"]
	},
	"/siem": {
		filePath: "/workspace/src/routes/siem.tsx",
		children: void 0,
		preloads: ["/assets/siem-BYW92UE_.js", "/assets/chrome-Bh56kLAY.js"]
	},
	"/sla": {
		filePath: "/workspace/src/routes/sla.tsx",
		children: void 0,
		preloads: ["/assets/sla-7waceZ2x.js", "/assets/chrome-Bh56kLAY.js"]
	}
} });
//#endregion
export { tsrStartManifest };
