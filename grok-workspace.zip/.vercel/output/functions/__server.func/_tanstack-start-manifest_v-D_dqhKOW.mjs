//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D_dqhKOW.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/audit",
			"/fleet",
			"/incidents",
			"/policies",
			"/quarantine",
			"/scanner",
			"/settings"
		],
		preloads: ["/assets/index-CQfmiNp1.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CQfmiNp1.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-DY46-WLC.js",
			"/assets/page-header-DabCJYFy.js",
			"/assets/verdict-DMpSs94L.js"
		]
	},
	"/audit": {
		filePath: "/workspace/src/routes/audit.tsx",
		children: void 0,
		preloads: [
			"/assets/audit-B2rgpJoU.js",
			"/assets/page-header-DabCJYFy.js",
			"/assets/verdict-DMpSs94L.js"
		]
	},
	"/fleet": {
		filePath: "/workspace/src/routes/fleet.tsx",
		children: void 0,
		preloads: [
			"/assets/fleet-DD04xT4i.js",
			"/assets/page-header-DabCJYFy.js",
			"/assets/verdict-DMpSs94L.js"
		]
	},
	"/incidents": {
		filePath: "/workspace/src/routes/incidents.tsx",
		children: void 0,
		preloads: [
			"/assets/incidents-BGavCc-R.js",
			"/assets/page-header-DabCJYFy.js",
			"/assets/verdict-DMpSs94L.js"
		]
	},
	"/policies": {
		filePath: "/workspace/src/routes/policies.tsx",
		children: void 0,
		preloads: [
			"/assets/policies-CSmTWG9X.js",
			"/assets/page-header-DabCJYFy.js",
			"/assets/verdict-DMpSs94L.js"
		]
	},
	"/quarantine": {
		filePath: "/workspace/src/routes/quarantine.tsx",
		children: void 0,
		preloads: [
			"/assets/quarantine-Wh-ejPO1.js",
			"/assets/page-header-DabCJYFy.js",
			"/assets/verdict-DMpSs94L.js"
		]
	},
	"/scanner": {
		filePath: "/workspace/src/routes/scanner.tsx",
		children: void 0,
		preloads: [
			"/assets/scanner-DP0p0YSO.js",
			"/assets/page-header-DabCJYFy.js",
			"/assets/verdict-DMpSs94L.js"
		]
	},
	"/settings": {
		filePath: "/workspace/src/routes/settings.tsx",
		children: void 0,
		preloads: ["/assets/settings-CQikHBxO.js", "/assets/page-header-DabCJYFy.js"]
	}
} });
//#endregion
export { tsrStartManifest };
