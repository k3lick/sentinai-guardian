import { i as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, z as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as truncateHash, h as formatClock, n as Badge, o as IntegrityBanner, p as downloadJson, r as Button, u as Surface, v as useGuardian } from "./button-CkMlNtAY.mjs";
import { t as PageHeader } from "./page-header-CfTViCKd.mjs";
import { r as VerdictBadge } from "./verdict-LAWMSaCb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/audit-BZ6-z014.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AuditPage() {
	const audit = useGuardian((s) => s.audit);
	const siem = useGuardian((s) => s.siem);
	const ok = useGuardian((s) => s.integrityOk);
	const brokenAt = useGuardian((s) => s.integrityBrokenAt);
	const recheck = useGuardian((s) => s.recheckIntegrity);
	const [tab, setTab] = (0, import_react.useState)("chain");
	const [open, setOpen] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "stagger-in space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IntegrityBanner, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: "Audit",
				title: "Tamper-evident chain",
				description: "Each entry commits SHA-256(prevHash | canonical payload). SIEM is a fan-out of the same events, not a second source of truth.",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "secondary",
					onClick: () => recheck(),
					children: "Recheck"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "outline",
					onClick: () => downloadJson(`sentinai-audit-${Date.now()}.json`, audit),
					children: "Export JSON"
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Surface, {
				className: "flex flex-wrap items-center gap-3",
				children: [ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					tone: "ok",
					children: "Chain intact"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					tone: "danger",
					children: "Chain broken"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "tabular text-sm text-muted",
					children: [
						audit.length,
						" entries",
						brokenAt !== null ? ` · first break at index ${brokenAt}` : ""
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-1 rounded-lg border border-border bg-surface p-1 w-fit",
				children: ["chain", "siem"].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setTab(t),
					className: `h-9 rounded-md px-3 text-xs font-medium uppercase tracking-wide ${tab === t ? "bg-elevated text-fg" : "text-muted hover:text-fg"}`,
					children: t === "chain" ? "Hash chain" : "SIEM fan-out"
				}, t))
			}),
			tab === "chain" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Surface, {
				className: "overflow-x-auto p-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[48rem] text-left text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "border-b border-border text-xs uppercase tracking-wide text-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Time"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3 font-medium",
								children: "Actor"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3 font-medium",
								children: "Action"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3 font-medium",
								children: "Verdict"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Hash"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: [...audit].reverse().map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b border-border last:border-0 align-top",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 tabular text-xs text-subtle whitespace-nowrap",
								children: formatClock(e.ts)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-3 text-xs",
								children: e.actor
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "px-3 py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: "text-left text-xs hover:underline",
									onClick: () => setOpen(open === e.id ? null : e.id),
									children: [e.action, e.policyId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "ml-1 font-mono text-subtle",
										children: e.policyId
									}) : null]
								}), open === e.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
									className: "mt-2 max-w-md overflow-auto rounded-md bg-bg p-2 font-mono text-[0.6875rem] text-muted",
									children: e.canonical
								}) : null]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-3",
								children: e.verdict ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VerdictBadge, { verdict: e.verdict }) : "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 font-mono text-[0.6875rem] text-subtle",
								children: truncateHash(e.hash)
							})
						]
					}, e.id)) })]
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Surface, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-3",
				children: siem.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex gap-3 border-b border-border pb-3 last:border-0 last:pb-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "w-32 shrink-0 tabular text-xs text-subtle",
						children: formatClock(e.ts)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm",
							children: e.message
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-mono text-[0.6875rem] text-subtle",
							children: [
								e.source,
								" · ",
								e.type,
								" · ",
								e.severity
							]
						})]
					})]
				}, e.id))
			}) })
		]
	});
}
//#endregion
export { AuditPage as component };
