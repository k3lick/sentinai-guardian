import { R as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as slaClock, m as formatDuration, n as Badge, v as useSentinai } from "./store-BJrHZyzO.mjs";
import { t as Button } from "./button-DB9ClE7Q.mjs";
import { n as Panel, t as PageHeader } from "./chrome-CyQP5BSz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/sla-CAzIVlg2.js
var import_jsx_runtime = require_jsx_runtime();
var TIERS = [
	{
		id: 0,
		label: "On track",
		tone: "success"
	},
	{
		id: 1,
		label: "Tier 1 · assignee warned",
		tone: "warning"
	},
	{
		id: 2,
		label: "Tier 2 · escalated to team lead",
		tone: "warning"
	},
	{
		id: 3,
		label: "Tier 3 · critical SLA breach",
		tone: "destructive"
	}
];
function SlaPage() {
	const sla = useSentinai((s) => s.sla);
	const update = useSentinai((s) => s.updateSla);
	const incidents = useSentinai((s) => s.incidents);
	const documents = useSentinai((s) => s.documents);
	const can = useSentinai((s) => s.allow)("sla.manage");
	const quarantined = documents.filter((d) => d.status === "quarantined");
	function field(key, label) {
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "block text-xs text-muted-foreground",
			children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "number",
				min: 1,
				value: sla[key],
				disabled: !can,
				onChange: (e) => update({ [key]: Number(e.target.value) }),
				className: "mt-1 h-9 w-full rounded-md border border-input bg-background px-2 text-sm"
			})]
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Response deadlines",
				subtitle: "Configurable SLA per severity (hours to response)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
					title: "Policy",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [
							field("sev1Minutes", "SEV-1 minutes"),
							field("sev2Minutes", "SEV-2 minutes"),
							field("sev3Minutes", "SEV-3 minutes"),
							field("quarantineMinutes", "Quarantine triage minutes"),
							field("rollbackMinutes", "Rollback minutes"),
							field("tier2Pct", "Tier 2 %"),
							field("tier3Pct", "Tier 3 %")
						]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
					title: "Escalation tiers",
					subtitle: "Thresholds for human escalation",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-2",
						children: TIERS.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: t.tone,
							children: t.label
						}) }, t.id))
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				title: "Live countdowns",
				subtitle: "Incidents & quarantine triage deadlines",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "space-y-3",
					children: [incidents.filter((i) => i.status !== "resolved").map((i) => {
						const c = slaClock(sla, "incident", i.createdAt, i.severity);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-md border border-border px-3 py-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									i.id,
									" · ",
									i.title
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-mono-xs text-muted-foreground",
									children: c.breached ? "breach" : formatDuration(c.remainingMs)
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1 h-1 overflow-hidden rounded-full bg-muted",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full bg-primary",
									style: { width: `${c.pct}%` }
								})
							})]
						}, i.id);
					}), quarantined.map((d) => {
						const c = slaClock(sla, "quarantine", d.createdAt);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-md border border-border px-3 py-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["quarantine triage → Compliance Officer · ", d.name] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-mono-xs text-muted-foreground",
									children: c.breached ? "breach" : formatDuration(c.remainingMs)
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1 h-1 overflow-hidden rounded-full bg-muted",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full bg-warning",
									style: { width: `${c.pct}%` }
								})
							})]
						}, d.id);
					})]
				}), !can ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-xs text-warning",
					children: "SLA configuration is restricted for this role."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-3",
					size: "sm",
					variant: "outline",
					onClick: () => update({}),
					children: "Write SLA audit event"
				})]
			})
		]
	});
}
//#endregion
export { SlaPage as component };
