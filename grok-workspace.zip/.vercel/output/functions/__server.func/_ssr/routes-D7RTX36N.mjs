import { b as require_jsx_runtime, v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as deriveMetrics, m as formatAgo, n as Badge, o as IntegrityBanner, r as Button, u as Surface, v as useGuardian } from "./button-CkMlNtAY.mjs";
import { t as PageHeader } from "./page-header-CfTViCKd.mjs";
import { n as StatusDot } from "./verdict-LAWMSaCb.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-D7RTX36N.js
var import_jsx_runtime = require_jsx_runtime();
var SCENARIOS = [
	{
		id: "cred-leak",
		title: "Credential leak in vendor runbook",
		blurb: "A markdown file with live cloud keys is submitted to the finance copilot."
	},
	{
		id: "prompt-inject",
		title: "Prompt injection on support RAG",
		blurb: "An inbound ticket tries to override the system prompt and list tools."
	},
	{
		id: "drop-table",
		title: "DROP TABLE from coding agent",
		blurb: "A coding agent proposes destroying the users table to 'fix' a migration."
	},
	{
		id: "crm-export",
		title: "Bulk CRM extract",
		blurb: "An agent is asked to dump every customer record to a vendor."
	}
];
function Kpi({ label, value, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Surface, {
		className: "p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium uppercase tracking-[0.12em] text-muted",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-3xl font-medium tabular tracking-tight",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-subtle",
				children: hint
			})
		]
	});
}
function OverviewPage() {
	const models = useGuardian((s) => s.models);
	const documents = useGuardian((s) => s.documents);
	const incidents = useGuardian((s) => s.incidents);
	const siem = useGuardian((s) => s.siem);
	const running = useGuardian((s) => s.scenarioRunning);
	const runScenario = useGuardian((s) => s.runScenario);
	const m = deriveMetrics(models, documents, incidents);
	const open = incidents.find((i) => i.status !== "closed");
	const sevOrder = [
		"critical",
		"high",
		"medium",
		"low"
	];
	const sevTotal = sevOrder.reduce((s, k) => s + m.severity[k], 0) || 1;
	async function play(id) {
		const def = SCENARIOS.find((s) => s.id === id);
		toast.message("Running scenario", { description: def?.title });
		await runScenario(id);
		toast.success("Scenario recorded", { description: "Verdict, SIEM and audit chain updated." });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "stagger-in space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IntegrityBanner, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: "Overview",
				title: "Fleet, quarantine and access events",
				description: "Cross-system posture across the inference fleet, document pipeline, and policy enforcement.",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					onClick: () => play("cred-leak"),
					disabled: running,
					children: "Run scenario"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						label: "Fleet availability",
						value: `${m.availability}%`,
						hint: `${m.healthy} healthy · ${m.degraded} degraded · ${m.offline} offline · avg p95 ${m.avgP95}ms`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						label: "Quarantine volume",
						value: String(m.quarantine),
						hint: `${m.pendingReview} pending review · ${m.releaseRate}% release rate`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						label: "Scan findings",
						value: String(m.findings),
						hint: `${m.criticalFindings} critical across ${m.documents} documents`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						label: "Open incidents",
						value: String(m.openIncidents),
						hint: `${m.totalIncidents} total tracked`
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Surface, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium",
						children: "Severity distribution"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-0.5 text-xs text-muted",
						children: "Active findings on held documents"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 space-y-3",
						children: sevOrder.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-1 flex justify-between text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "capitalize text-muted",
								children: k
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular text-fg",
								children: m.severity[k]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-1.5 overflow-hidden rounded-full bg-elevated",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: k === "critical" ? "h-full bg-danger" : k === "high" ? "h-full bg-warn" : k === "medium" ? "h-full bg-info" : "h-full bg-subtle",
								style: { width: `${Math.round(m.severity[k] / sevTotal * 100)}%` }
							})
						})] }, k))
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Surface, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium",
						children: "Model fleet"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-0.5 text-xs text-muted",
						children: "Live endpoint health and latency"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/fleet",
						className: "text-xs text-muted hover:text-fg",
						children: "Open fleet"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 divide-y divide-border",
					children: models.map((model) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-start gap-3 py-3 first:pt-0 last:pb-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1.5",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusDot, { status: model.status })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "truncate text-sm",
									children: [model.name, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-muted",
										children: [
											" · ",
											model.runtime,
											" ",
											model.model
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "tabular text-xs text-subtle",
									children: [
										"p50 ",
										model.p50,
										" ms · p95 ",
										model.p95,
										" ms · ",
										model.tokPerSec,
										" tok/s"
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "shrink-0 text-xs capitalize text-muted",
								children: model.status
							})
						]
					}, model.id))
				})] })]
			}),
			open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Surface, {
				className: "flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: "danger",
						children: open.severity
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm font-medium",
						children: open.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted",
						children: open.summary
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/incidents",
					className: "text-sm text-accent hover:opacity-80",
					children: "Open incident"
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 lg:grid-cols-[1.2fr_0.8fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Surface, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium",
						children: "Live security stream"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-0.5 text-xs text-muted",
						children: "Role changes, blocked actions, policy decisions"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 max-h-80 space-y-3 overflow-auto",
						children: siem.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "text-sm text-muted",
							children: "No access-control activity recorded yet."
						}) : siem.slice(0, 12).map((ev) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "w-16 shrink-0 tabular text-xs text-subtle",
								children: formatAgo(ev.ts)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-fg",
									children: ev.message
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-mono text-[0.6875rem] text-subtle",
									children: ev.type
								})]
							})]
						}, ev.id))
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Surface, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium",
						children: "Scenarios"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-0.5 text-xs text-muted",
						children: "Drive real quarantine decisions, policy verdicts and SIEM fan-out."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 space-y-2",
						children: SCENARIOS.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							disabled: running,
							onClick: () => play(s.id),
							className: "w-full rounded-lg border border-border px-3 py-2.5 text-left transition-colors duration-150 hover:border-border-strong hover:bg-elevated disabled:opacity-50",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-fg",
								children: s.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-0.5 text-xs text-pretty text-muted",
								children: s.blurb
							})]
						}) }, s.id))
					})
				] })]
			})
		]
	});
}
//#endregion
export { OverviewPage as component };
