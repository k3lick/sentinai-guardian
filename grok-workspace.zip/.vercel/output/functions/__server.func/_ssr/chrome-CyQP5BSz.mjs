import { R as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Badge, p as cn } from "./store-BJrHZyzO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/chrome-CyQP5BSz.js
var import_jsx_runtime = require_jsx_runtime();
function PageHeader({ title, subtitle, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-start justify-between gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-lg font-semibold tracking-tight",
			children: title
		}), subtitle ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-0.5 max-w-2xl text-sm text-muted-foreground",
			children: subtitle
		}) : null] }), action ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-wrap items-center gap-2",
			children: action
		}) : null]
	});
}
function StatCard({ label, value, hint, tone = "muted", icon }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "rounded-xl border border-border bg-card/70 p-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs font-medium uppercase tracking-wider text-muted-foreground",
						children: label
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-1 tabular text-2xl font-semibold tracking-tight",
						children: value
					}),
					hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-1 text-xs text-muted-foreground",
						children: hint
					}) : null
				]
			}), icon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: cn("grid size-8 place-items-center rounded-md border", tone === "destructive" && "border-destructive/30 bg-destructive/10 text-destructive", tone === "warning" && "border-warning/30 bg-warning/10 text-warning", tone === "success" && "border-success/30 bg-success/10 text-success", tone === "primary" && "border-primary/30 bg-primary/10 text-primary", tone === "muted" && "border-border bg-muted text-muted-foreground"),
				children: icon
			}) : null]
		})
	});
}
function Panel({ title, subtitle, action, children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: cn("rounded-xl border border-border bg-card/70 p-4", className),
		children: [title ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-3 flex flex-wrap items-start justify-between gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-sm font-semibold",
				children: title
			}), subtitle ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: subtitle
			}) : null] }), action]
		}) : null, children]
	});
}
function StatusBadge({ status }) {
	const item = {
		healthy: {
			label: "Healthy",
			tone: "success"
		},
		degraded: {
			label: "Degraded",
			tone: "warning"
		},
		offline: {
			label: "Offline / Failed",
			tone: "destructive"
		},
		unknown: {
			label: "Not probed",
			tone: "muted"
		},
		clean: {
			label: "Clean",
			tone: "success"
		},
		flagged: {
			label: "Flagged",
			tone: "warning"
		},
		quarantined: {
			label: "Quarantined",
			tone: "destructive"
		},
		released: {
			label: "Released to ingestion",
			tone: "success"
		},
		blocked: {
			label: "Blocked & archived",
			tone: "destructive"
		},
		false_positive: {
			label: "False positive",
			tone: "muted"
		}
	}[status] ?? {
		label: status,
		tone: "muted"
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		tone: item.tone,
		dot: true,
		children: item.label
	});
}
//#endregion
export { StatusBadge as i, Panel as n, StatCard as r, PageHeader as t };
