import { i as __toESM } from "../_runtime.mjs";
import { R as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { h as formatTime, n as Badge, v as useSentinai } from "./store-BJrHZyzO.mjs";
import { n as ScenarioCta } from "./router-BAYnTcJM.mjs";
import { n as Panel, t as PageHeader } from "./chrome-CyQP5BSz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/audit-DOF8TdRw.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AuditPage() {
	const audit = useSentinai((s) => s.audit);
	const allow = useSentinai((s) => s.allow);
	const [q, setQ] = (0, import_react.useState)("");
	const [cat, setCat] = (0, import_react.useState)("all");
	const filtered = (0, import_react.useMemo)(() => audit.filter((e) => {
		if (cat !== "all" && e.category !== cat) return false;
		if (!q) return true;
		return `${e.action} ${e.message} ${e.actor}`.toLowerCase().includes(q.toLowerCase());
	}), [
		audit,
		q,
		cat
	]);
	if (!allow("audit.read")) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-border bg-card/70 p-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-lg font-semibold",
			children: "Access restricted"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted-foreground",
			children: "Audit log access is not granted to the active role."
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Audit log",
				subtitle: `${audit.length} immutable records · tamper-evident chain`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: q,
					onChange: (e) => setQ(e.target.value),
					placeholder: "Search actions, actors, messages",
					className: "h-9 min-w-56 flex-1 rounded-md border border-input bg-background px-2 text-sm"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					value: cat,
					onChange: (e) => setCat(e.target.value),
					className: "h-9 rounded-md border border-input bg-background px-2 text-sm",
					children: [
						"all",
						"scan",
						"access",
						"policy",
						"incident",
						"model",
						"sla",
						"approval",
						"siem",
						"role"
					].map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: c,
						children: c
					}, c))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, { children: filtered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScenarioCta, {
				title: "No access-control activity recorded yet",
				body: "Scenarios drive real quarantine decisions, policy verdicts and role events straight into this stream.",
				scenario: "credential_leak"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y divide-border/70",
				children: filtered.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex flex-wrap items-start gap-3 py-2.5 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: e.severity === "critical" || e.severity === "high" ? "destructive" : e.severity === "medium" ? "warning" : "muted",
							children: e.action
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: e.message }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-mono-xs text-muted-foreground",
								children: [
									e.actor,
									" · ",
									e.role,
									" · ",
									e.category
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-mono-xs text-muted-foreground",
							children: formatTime(e.at)
						})
					]
				}, e.id))
			}) })
		]
	});
}
//#endregion
export { AuditPage as component };
