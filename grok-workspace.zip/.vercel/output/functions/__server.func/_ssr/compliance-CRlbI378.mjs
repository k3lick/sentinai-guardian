import { R as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { h as formatTime, v as useSentinai } from "./store-BJrHZyzO.mjs";
import { t as Button } from "./button-DB9ClE7Q.mjs";
import { i as StatusBadge, n as Panel, r as StatCard, t as PageHeader } from "./chrome-CyQP5BSz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/compliance-CRlbI378.js
var import_jsx_runtime = require_jsx_runtime();
function CompliancePage() {
	const documents = useSentinai((s) => s.documents);
	const audit = useSentinai((s) => s.audit);
	const incidents = useSentinai((s) => s.incidents);
	const siem = useSentinai((s) => s.siem);
	const setStatus = useSentinai((s) => s.setDocumentStatus);
	const allow = useSentinai((s) => s.allow);
	const queue = documents.filter((d) => d.status === "quarantined");
	const siemOn = siem.some((d) => d.enabled);
	const openSev1 = incidents.filter((i) => i.severity === "sev1" && i.status !== "resolved").length;
	const posture = [
		{
			label: "SIEM streaming enabled",
			ok: siemOn
		},
		{
			label: "Quarantine queue reviewed < 4h target",
			ok: queue.length === 0
		},
		{
			label: "No unresolved SEV-1",
			ok: openSev1 === 0
		},
		{
			label: "Audit trail populated",
			ok: audit.length > 0
		}
	];
	const score = Math.round(posture.filter((p) => p.ok).length / posture.length * 100);
	function exportEvidence() {
		const payload = {
			generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
			posture,
			score,
			incidents: incidents.length,
			documents: documents.length,
			audit: audit.slice(0, 50)
		};
		const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
		const url = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		a.download = "sentinai-evidence.json";
		a.click();
		URL.revokeObjectURL(url);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Compliance posture",
				subtitle: "Derived from live state"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Posture score",
						value: `${score}%`,
						tone: score >= 75 ? "success" : "warning"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Triage queue",
						value: queue.length,
						hint: "Unreviewed quarantined docs escalate to Compliance Officer"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Evidence records",
						value: audit.length,
						hint: "Audit records available for compliance export"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				title: "Controls",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-2 text-sm",
					children: posture.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between rounded-md border border-border px-3 py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: p.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: p.ok ? "text-success" : "text-warning",
							children: p.ok ? "pass" : "gap"
						})]
					}, p.label))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-3",
					size: "sm",
					disabled: !allow("evidence.verify"),
					onClick: exportEvidence,
					children: "Export evidence pack"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "Triage queue",
				subtitle: "Unreviewed quarantined docs escalate to Compliance Officer",
				children: queue.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Queue is clear."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-2",
					children: queue.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex flex-wrap items-center gap-2 rounded-md border border-border px-3 py-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: d.status }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex-1 text-sm",
								children: d.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-mono-xs text-muted-foreground",
								children: formatTime(d.createdAt)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								disabled: !allow("document.release"),
								onClick: () => setStatus(d.id, "released"),
								children: "Release"
							})
						]
					}, d.id))
				})
			})
		]
	});
}
//#endregion
export { CompliancePage as component };
