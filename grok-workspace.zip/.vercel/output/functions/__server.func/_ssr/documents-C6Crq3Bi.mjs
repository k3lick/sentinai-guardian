import { i as __toESM } from "../_runtime.mjs";
import { R as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { a as RELIABILITY_SUMMARY, f as VENDOR_RUNBOOK, h as formatTime, n as Badge, u as TENANT, v as useSentinai } from "./store-BJrHZyzO.mjs";
import { t as Button } from "./button-DB9ClE7Q.mjs";
import { n as ScenarioCta } from "./router-BAYnTcJM.mjs";
import { i as StatusBadge, n as Panel, t as PageHeader } from "./chrome-CyQP5BSz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/documents-C6Crq3Bi.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DocumentsPage() {
	const documents = useSentinai((s) => s.documents);
	const ingest = useSentinai((s) => s.ingest);
	const setStatus = useSentinai((s) => s.setDocumentStatus);
	const allow = useSentinai((s) => s.allow);
	const role = useSentinai((s) => s.role);
	const [name, setName] = (0, import_react.useState)("q3-reliability-summary.txt");
	const [body, setBody] = (0, import_react.useState)(RELIABILITY_SUMMARY);
	const [openId, setOpenId] = (0, import_react.useState)(null);
	const selected = documents.find((d) => d.id === openId) ?? documents[0];
	const canRaw = allow("document.raw_view");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Document library",
				subtitle: `${documents.length} documents · scanned before agent context · quarantined docs excluded from RAG`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
					title: "Ingest document",
					className: "lg:col-span-1",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "space-y-3",
						onSubmit: (e) => {
							e.preventDefault();
							if (!allow("document.ingest")) return;
							const doc = ingest(name || "untitled.txt", TENANT, body);
							setOpenId(doc.id);
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block text-xs text-muted-foreground",
								children: ["Filename", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: name,
									onChange: (e) => setName(e.target.value),
									className: "mt-1 h-9 w-full rounded-md border border-input bg-background px-2 text-sm"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block text-xs text-muted-foreground",
								children: ["Contents", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									value: body,
									onChange: (e) => setBody(e.target.value),
									rows: 8,
									className: "mt-1 w-full rounded-md border border-input bg-background p-2 font-mono text-xs"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "submit",
									size: "sm",
									disabled: !allow("document.ingest"),
									children: "Scan & ingest"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									size: "sm",
									variant: "outline",
									onClick: () => {
										setName("vendor-runbook.txt");
										setBody(VENDOR_RUNBOOK);
									},
									children: "Load vendor runbook"
								})]
							})
						]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
					title: "Library",
					className: "lg:col-span-2",
					children: documents.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScenarioCta, {
						title: "No documents ingested yet",
						body: "Run the credential-leak scenario or paste a runbook to see the scanner quarantine live secrets.",
						scenario: "credential_leak"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-1.5",
						children: documents.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => setOpenId(d.id),
							className: `flex w-full flex-wrap items-center gap-2 rounded-md border px-3 py-2 text-left text-sm ${selected?.id === d.id ? "border-primary/40 bg-primary/5" : "border-border bg-background/40"}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: d.status }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: d.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-mono-xs text-muted-foreground",
									children: ["risk ", d.risk]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ml-auto text-mono-xs text-muted-foreground",
									children: formatTime(d.createdAt)
								})
							]
						}) }, d.id))
					})
				})]
			}),
			selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				title: selected.name,
				subtitle: `${selected.findings.length} findings · tenant ${selected.tenant}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								disabled: !allow("document.release"),
								onClick: () => setStatus(selected.id, "released", `Notes: released by ${role}`),
								children: "Release"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "outline",
								onClick: () => setStatus(selected.id, "false_positive"),
								children: "False positive"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "ghost",
								onClick: () => setStatus(selected.id, "blocked"),
								children: "Block & archive"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 space-y-2",
						children: selected.findings.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-md border border-border bg-background/40 px-3 py-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										tone: f.severity === "critical" || f.severity === "high" ? "destructive" : "warning",
										children: f.severity
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: f.label }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "ml-auto text-mono-xs text-muted-foreground",
										children: ["line ", f.line]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 truncate font-mono text-xs text-muted-foreground",
								children: f.excerpt
							})]
						}, f.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
						className: "mt-3 max-h-64 overflow-auto rounded-md border border-border bg-background/60 p-3 font-mono text-xs whitespace-pre-wrap",
						children: canRaw ? selected.raw : selected.sanitized
					})
				]
			}) : null
		]
	});
}
//#endregion
export { DocumentsPage as component };
