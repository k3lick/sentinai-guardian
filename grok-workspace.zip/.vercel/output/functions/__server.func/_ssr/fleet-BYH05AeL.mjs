import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { m as formatAgo, n as Badge, o as IntegrityBanner, r as Button, u as Surface, v as useGuardian } from "./button-CkMlNtAY.mjs";
import { t as PageHeader } from "./page-header-CfTViCKd.mjs";
import { n as StatusDot } from "./verdict-LAWMSaCb.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/fleet-BYH05AeL.js
var import_jsx_runtime = require_jsx_runtime();
function FleetPage() {
	const models = useGuardian((s) => s.models);
	const mode = useGuardian((s) => s.mode);
	const probing = models.some((m) => m.status === "probing");
	const probeAll = useGuardian((s) => s.probeAll);
	async function onProbe() {
		toast.message(mode === "demo" ? "Simulated probe" : "Live probe");
		await probeAll();
		toast.success("Fleet probe complete");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "stagger-in space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IntegrityBanner, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: "Fleet",
				title: "Model registry",
				description: "Ollama, LM Studio and vLLM endpoints. Demo mode uses deterministic latency; live mode probes the local runtimes.",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: onProbe,
					disabled: probing,
					size: "sm",
					children: probing ? "Probing…" : "Probe fleet"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3",
				children: models.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Surface, {
					className: "flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusDot, { status: m.status }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "text-sm font-medium",
											children: m.name
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
											tone: "neutral",
											children: m.runtime
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "capitalize text-xs text-muted",
											children: m.status
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 font-mono text-xs text-subtle",
									children: [
										m.model,
										" · ",
										m.endpoint
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-xs text-muted",
									children: m.place
								}),
								m.lastError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-xs text-danger",
									children: m.lastError
								}) : null
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "grid grid-cols-3 gap-4 text-right",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-[0.6875rem] uppercase tracking-wide text-subtle",
									children: "p50"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
									className: "tabular text-sm",
									children: [m.p50, " ms"]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-[0.6875rem] uppercase tracking-wide text-subtle",
									children: "p95"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
									className: "tabular text-sm",
									children: [m.p95, " ms"]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-[0.6875rem] uppercase tracking-wide text-subtle",
									children: "tok/s"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "tabular text-sm",
									children: m.tokPerSec
								})] })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-subtle sm:w-28 sm:text-right",
							children: m.lastProbedAt ? formatAgo(m.lastProbedAt) : "Never probed"
						})
					]
				}, m.id))
			})
		]
	});
}
//#endregion
export { FleetPage as component };
