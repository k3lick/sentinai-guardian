import { i as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, z as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { h as formatClock, m as formatAgo, n as Badge, o as IntegrityBanner, r as Button, u as Surface, v as useGuardian } from "./button-CkMlNtAY.mjs";
import { t as PageHeader } from "./page-header-CfTViCKd.mjs";
import { t as SeverityBadge } from "./verdict-LAWMSaCb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/incidents-7IwUL1FJ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var NEXT = {
	open: "investigating",
	investigating: "contained",
	contained: "closed",
	closed: null
};
function IncidentsPage() {
	const incidents = useGuardian((s) => s.incidents);
	const documents = useGuardian((s) => s.documents);
	const setStatus = useGuardian((s) => s.setIncidentStatus);
	const [id, setId] = (0, import_react.useState)(incidents[0]?.id ?? null);
	const selected = incidents.find((i) => i.id === id) ?? incidents[0];
	const next = selected ? NEXT[selected.status] : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "stagger-in space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IntegrityBanner, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: "Incidents",
				title: "Response queue",
				description: "Opened automatically when a scan crosses the critical risk band, or from a denied high-severity verdict."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 lg:grid-cols-[0.9fr_1.1fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Surface, {
					className: "p-2 sm:p-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: incidents.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setId(i.id),
						className: `w-full rounded-lg px-3 py-3 text-left transition-colors duration-150 ${selected?.id === i.id ? "bg-elevated" : "hover:bg-elevated/60"}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SeverityBadge, { severity: i.severity }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: i.status === "closed" ? "ok" : "warn",
									children: i.status
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1.5 text-sm",
								children: i.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs text-subtle",
								children: formatAgo(i.openedAt)
							})
						]
					}) }, i.id)) })
				}), selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Surface, {
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-mono text-xs text-subtle",
									children: selected.id
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-1 text-lg font-medium tracking-tight text-balance",
									children: selected.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-pretty text-muted",
									children: selected.summary
								})
							] }), next ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "secondary",
								onClick: () => setStatus(selected.id, next),
								children: ["Mark ", next]
							}) : null]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted",
							children: [
								"Assignee ",
								selected.assignee,
								" · opened ",
								formatClock(selected.openedAt)
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-xs font-medium uppercase tracking-wide text-muted",
							children: "Linked documents"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-2 space-y-1",
							children: selected.documentIds.map((did) => {
								const d = documents.find((x) => x.id === did);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "font-mono text-xs text-fg",
									children: [d?.name ?? did, d ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "ml-2 text-subtle",
										children: d.status
									}) : null]
								}, did);
							})
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-xs font-medium uppercase tracking-wide text-muted",
							children: "Timeline"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
							className: "mt-2 space-y-2",
							children: selected.timeline.map((t, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex gap-3 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "w-28 shrink-0 tabular text-xs text-subtle",
									children: formatClock(t.ts)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t.text })]
							}, `${t.ts}-${idx}`))
						})] })
					]
				}) : null]
			})
		]
	});
}
//#endregion
export { IncidentsPage as component };
