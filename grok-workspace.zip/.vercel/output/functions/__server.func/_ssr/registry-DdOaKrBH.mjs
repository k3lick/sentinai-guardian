import { i as __toESM } from "../_runtime.mjs";
import { R as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { h as formatTime, n as Badge, v as useSentinai } from "./store-BJrHZyzO.mjs";
import { t as Button } from "./button-DB9ClE7Q.mjs";
import { n as Panel, t as PageHeader } from "./chrome-CyQP5BSz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/registry-DdOaKrBH.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function RegistryPage() {
	const models = useSentinai((s) => s.models);
	const deployments = useSentinai((s) => s.deployments);
	const deploy = useSentinai((s) => s.deploy);
	const rollback = useSentinai((s) => s.rollback);
	const flag = useSentinai((s) => s.flagVersion);
	const allow = useSentinai((s) => s.allow);
	const [selected, setSelected] = (0, import_react.useState)(models[0]?.id);
	const current = models.find((m) => m.id === selected) ?? models[0];
	const families = [...new Set(models.map((m) => m.family))];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Registered models",
				subtitle: `${families.length} distinct models across ${models.length} versions`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
					title: "Catalog",
					className: "lg:col-span-1",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-1.5",
						children: models.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => setSelected(m.id),
							className: `w-full rounded-md border px-3 py-2 text-left text-sm ${m.id === current?.id ? "border-primary/40 bg-primary/5" : "border-border bg-background/40"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium",
										children: m.family
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-mono-xs text-muted-foreground",
										children: m.version
									}),
									m.active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										tone: "success",
										children: "active"
									}) : null,
									m.problematic ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										tone: "destructive",
										children: "break"
									}) : null
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-0.5 text-mono-xs text-muted-foreground",
								children: [
									m.provider,
									" · ",
									m.quantization
								]
							})]
						}) }, m.id))
					})
				}), current ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
					title: "Model detail",
					subtitle: "Deployment metadata & rollback",
					className: "lg:col-span-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "grid grid-cols-2 gap-3 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-xs text-muted-foreground",
									children: "Family"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: current.family })] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-xs text-muted-foreground",
									children: "Version"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "tabular",
									children: current.version
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-xs text-muted-foreground",
									children: "Context"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "tabular",
									children: current.contextWindow.toLocaleString()
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-xs text-muted-foreground",
									children: "Quantization"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: current.quantization })] })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 flex flex-wrap gap-1.5",
							children: current.tags.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: "muted",
								children: t
							}, t))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 grid grid-cols-2 gap-2 text-xs",
							children: [
								["Context length", current.compat.contextLength],
								["Tool-calling schema", current.compat.toolCallingSchema],
								["SSE streaming", current.compat.streamingSse],
								["Embeddings", current.compat.embeddings]
							].map(([label, ok]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-md border border-border px-2 py-1.5",
								children: [
									ok ? "Pass" : "Fail",
									" · ",
									label
								]
							}, label))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex flex-wrap gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									disabled: !allow("registry.manage"),
									onClick: () => deploy(current.id),
									children: "Deploy"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "outline",
									disabled: !allow("rollback.execute"),
									onClick: () => rollback(current.family),
									children: "Rollback"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "ghost",
									onClick: () => flag(current.id),
									children: "Mark problematic"
								})
							]
						})
					]
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "Deployment history",
				subtitle: "Promotions & rollbacks",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "divide-y divide-border/70",
					children: deployments.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex flex-wrap items-center gap-3 py-2.5 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: d.kind === "rollback" ? "warning" : d.kind === "flag" ? "destructive" : "primary",
								children: d.kind
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex-1",
								children: d.versionLabel
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-mono-xs text-muted-foreground",
								children: d.actor
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-mono-xs text-muted-foreground",
								children: formatTime(d.at)
							})
						]
					}, d.id))
				})
			})
		]
	});
}
//#endregion
export { RegistryPage as component };
