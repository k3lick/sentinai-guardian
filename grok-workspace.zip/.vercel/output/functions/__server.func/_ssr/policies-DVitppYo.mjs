import { i as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, z as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as POLICY_RULES, l as SAMPLE_PROMPTS, m as formatAgo, o as IntegrityBanner, r as Button, u as Surface, v as useGuardian } from "./button-CkMlNtAY.mjs";
import { t as PageHeader } from "./page-header-CfTViCKd.mjs";
import { r as VerdictBadge, t as SeverityBadge } from "./verdict-LAWMSaCb.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { i as Textarea } from "./router-pRE2o39U.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/policies-DVitppYo.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PoliciesPage() {
	const [text, setText] = (0, import_react.useState)(SAMPLE_PROMPTS[0].text);
	const evaluate = useGuardian((s) => s.evaluate);
	const history = useGuardian((s) => s.evaluations);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const latest = history[0];
	async function onEval() {
		if (!text.trim()) return;
		setBusy(true);
		try {
			const ev = await evaluate(text, "playground");
			toast.message(`Verdict ${ev.verdict}`, { description: ev.primaryId ? `Matched ${ev.primaryId} in ${ev.latencyMs}ms` : `Default allow in ${ev.latencyMs}ms` });
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "stagger-in space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IntegrityBanner, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: "Policies",
				title: "Deterministic policy engine",
				description: "Content is matched against a closed rule set. The model never unlocks a DENY. HUMAN holds for an operator."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 lg:grid-cols-[1.1fr_0.9fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Surface, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium",
						children: "Playground"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-0.5 text-xs text-muted",
						children: "Paste an agent action, prompt, or SQL. The engine returns exactly one verdict."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 flex flex-wrap gap-1.5",
						children: SAMPLE_PROMPTS.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setText(s.text),
							className: "h-8 rounded-full border border-border px-2.5 text-xs text-muted hover:border-border-strong hover:text-fg",
							children: s.label
						}, s.label))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						className: "mt-3 min-h-36 font-mono text-xs",
						value: text,
						onChange: (e) => setText(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: onEval,
							disabled: busy,
							size: "sm",
							children: busy ? "Evaluating…" : "Evaluate"
						}), latest && latest.input === text ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VerdictBadge, { verdict: latest.verdict }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "tabular text-xs text-subtle",
								children: [latest.latencyMs, " ms"]
							})]
						}) : null]
					}),
					latest && latest.input === text ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 space-y-2",
						children: latest.matched.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "text-sm text-muted",
							children: "No rules matched · default ALLOW (AL-000)."
						}) : latest.matched.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-md border border-border bg-bg px-3 py-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono text-xs",
										children: h.ruleId
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm",
										children: h.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VerdictBadge, { verdict: h.verdict })
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 font-mono text-[0.6875rem] text-subtle",
								children: h.excerpt
							})]
						}, h.ruleId))
					}) : null
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Surface, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-medium",
					children: "Recent verdicts"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 max-h-[28rem] space-y-3 overflow-auto",
					children: history.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "text-sm text-muted",
						children: "Evaluate a sample to populate history. Seeded incidents already sit on the audit chain."
					}) : history.slice(0, 16).map((ev) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-start gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VerdictBadge, { verdict: ev.verdict }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "truncate font-mono text-xs",
									children: [
										ev.primaryId ?? "AL-000",
										" · ",
										ev.source
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-xs text-muted",
									children: ev.input
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "shrink-0 text-[0.6875rem] text-subtle",
								children: formatAgo(ev.ts)
							})
						]
					}, ev.id))
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Surface, {
				className: "overflow-x-auto p-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[40rem] text-left text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "border-b border-border text-xs uppercase tracking-wide text-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-5 py-3 font-medium",
								children: "ID"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3 font-medium",
								children: "Rule"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3 font-medium",
								children: "Category"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3 font-medium",
								children: "Verdict"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-5 py-3 font-medium",
								children: "Severity"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: POLICY_RULES.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b border-border last:border-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-5 py-3 font-mono text-xs",
								children: r.id
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "px-3 py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: r.title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "max-w-md text-xs text-pretty text-muted",
									children: r.description
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-3 capitalize text-muted",
								children: r.category
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VerdictBadge, { verdict: r.verdict })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-5 py-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SeverityBadge, { severity: r.severity })
							})
						]
					}, r.id)) })]
				})
			})
		]
	});
}
//#endregion
export { PoliciesPage as component };
