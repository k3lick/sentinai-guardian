import { i as __toESM } from "../_runtime.mjs";
import { R as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { g as percentile, v as useSentinai } from "./store-BJrHZyzO.mjs";
import { t as Button } from "./button-DB9ClE7Q.mjs";
import { i as StatusBadge, n as Panel, t as PageHeader } from "./chrome-CyQP5BSz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/models-CwWV3DoQ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ModelsPage() {
	const endpoints = useSentinai((s) => s.endpoints);
	const ping = useSentinai((s) => s.pingEndpoint);
	const add = useSentinai((s) => s.addEndpoint);
	const remove = useSentinai((s) => s.removeEndpoint);
	const allow = useSentinai((s) => s.allow);
	const [name, setName] = (0, import_react.useState)("");
	const [url, setUrl] = (0, import_react.useState)("");
	const [model, setModel] = (0, import_react.useState)("llama-3.1-8b-instruct");
	const canConfigure = allow("model.configure");
	const canExecute = allow("model.execute");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Local model endpoints",
			subtitle: "Ping to probe health · fallback priority 1 = primary"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 lg:grid-cols-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "Register endpoint",
				className: "lg:col-span-1",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "space-y-3",
					onSubmit: (e) => {
						e.preventDefault();
						if (!canConfigure || !name || !url) return;
						add({
							name,
							provider: "custom",
							url,
							model
						});
						setName("");
						setUrl("");
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-xs text-muted-foreground",
							children: ["Name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: name,
								onChange: (e) => setName(e.target.value),
								className: "mt-1 h-9 w-full rounded-md border border-input bg-background px-2 text-sm"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-xs text-muted-foreground",
							children: ["Base URL", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: url,
								onChange: (e) => setUrl(e.target.value),
								placeholder: "http://localhost:11434",
								className: "mt-1 h-9 w-full rounded-md border border-input bg-background px-2 text-sm"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-xs text-muted-foreground",
							children: ["Model", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: model,
								onChange: (e) => setModel(e.target.value),
								className: "mt-1 h-9 w-full rounded-md border border-input bg-background px-2 text-sm"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							size: "sm",
							disabled: !canConfigure,
							children: "Register endpoint"
						}),
						!canConfigure ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-warning",
							children: "Model configuration is restricted for this role."
						}) : null
					]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "Fleet",
				subtitle: `${endpoints.length} endpoints`,
				className: "lg:col-span-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-2",
					children: endpoints.slice().sort((a, b) => a.priority - b.priority).map((ep) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg border border-border bg-background/40 p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: ep.status }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm font-medium",
										children: ep.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-mono-xs text-muted-foreground",
										children: ["P", ep.priority]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "ml-auto text-mono-xs text-muted-foreground",
										children: ep.provider
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1 truncate text-mono-xs text-muted-foreground",
								children: ep.url
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex flex-wrap items-center gap-3 text-mono-xs text-muted-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: ep.model }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										"p50 ",
										percentile(ep.latencies, 50) ?? "—",
										"ms"
									] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										"p95 ",
										percentile(ep.latencies, 95) ?? "—",
										"ms"
									] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: ep.tokensPerSec != null ? `${ep.tokensPerSec.toFixed(0)} tok/s` : "awaiting first probe" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										ep.failedRequests,
										"/",
										ep.totalRequests,
										" failed"
									] })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex flex-wrap gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "outline",
									disabled: !canExecute,
									onClick: () => void ping(ep.id),
									children: "Ping"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "ghost",
									disabled: !canConfigure,
									onClick: () => remove(ep.id),
									children: "Remove"
								})]
							})
						]
					}, ep.id))
				})
			})]
		})]
	});
}
//#endregion
export { ModelsPage as component };
