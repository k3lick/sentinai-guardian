import { R as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { h as formatTime, n as Badge, v as useSentinai } from "./store-BJrHZyzO.mjs";
import { t as Button } from "./button-DB9ClE7Q.mjs";
import { n as Panel, t as PageHeader } from "./chrome-CyQP5BSz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/siem-DcgLKbvX.js
var import_jsx_runtime = require_jsx_runtime();
function SiemPage() {
	const siem = useSentinai((s) => s.siem);
	const events = useSentinai((s) => s.siemEvents);
	const toggle = useSentinai((s) => s.toggleSiem);
	const stream = useSentinai((s) => s.streamSiem);
	const webhook = useSentinai((s) => s.webhookUrl);
	const can = useSentinai((s) => s.allow)("siem.manage");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Stream status",
				subtitle: "Event stream in real time"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 lg:grid-cols-2",
				children: siem.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
					title: d.name,
					subtitle: `${d.platform} · ${d.schema} · index ${d.index}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: d.enabled ? "success" : "muted",
								children: d.enabled ? "enabled" : "paused"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-mono-xs text-muted-foreground",
								children: [
									"sent ",
									d.sent,
									" · failed ",
									d.failed
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 truncate text-mono-xs text-muted-foreground",
							children: d.endpoint
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 flex flex-wrap gap-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "outline",
								disabled: !can,
								onClick: () => toggle(d.id),
								children: d.enabled ? "Disable" : "Enable"
							})
						})
					]
				}, d.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				title: "Slack notification rules",
				subtitle: "Only critical events page the security team — minor logs stay in SIEM/audit",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "space-y-2 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex flex-wrap items-center gap-2 rounded-md border border-border px-3 py-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "SEV-1 incident created" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-mono-xs text-muted-foreground",
										children: "immediate · severity critical"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "ml-auto text-xs",
										children: "→ Slack"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex flex-wrap items-center gap-2 rounded-md border border-border px-3 py-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Critical policy breach (deny + critical)" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-mono-xs text-muted-foreground",
										children: "immediate · severity critical"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "ml-auto text-xs",
										children: "→ Slack"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex flex-wrap items-center gap-2 rounded-md border border-border px-3 py-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "All other SIEM & audit events" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-mono-xs text-muted-foreground",
										children: "logged only · no Slack alert"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "ml-auto text-xs",
										children: "→ SIEM/audit"
									})
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 text-xs text-muted-foreground",
						children: ["Webhook endpoint ", webhook]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-3",
						size: "sm",
						onClick: () => stream("incident", "SEV-1 incident created", "critical"),
						children: "Send test event"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "Event stream",
				subtitle: `${events.length} events · live feed`,
				children: events.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Waiting for the first streamed event."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "divide-y divide-border/70",
					children: events.slice(0, 40).map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex flex-wrap items-center gap-3 py-2 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: e.severity === "critical" || e.severity === "high" ? "destructive" : "muted",
								children: e.channel
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex-1 truncate",
								children: e.message
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-mono-xs text-muted-foreground",
								children: formatTime(e.at)
							})
						]
					}, e.id))
				})
			})
		]
	});
}
//#endregion
export { SiemPage as component };
