import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Badge } from "./button-CkMlNtAY.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/verdict-LAWMSaCb.js
var import_jsx_runtime = require_jsx_runtime();
function VerdictBadge({ verdict }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		tone: verdict === "ALLOW" ? "ok" : verdict === "DENY" ? "danger" : verdict === "HUMAN" ? "warn" : "info",
		children: verdict
	});
}
function SeverityBadge({ severity }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		tone: severity === "critical" ? "danger" : severity === "high" ? "warn" : severity === "medium" ? "info" : "neutral",
		children: severity
	});
}
function StatusDot({ status }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `inline-block size-1.5 rounded-full ${status === "healthy" ? "bg-ok" : status === "degraded" || status === "probing" ? "bg-warn" : status === "offline" ? "bg-danger" : "bg-subtle"} ${status === "probing" ? "live-dot" : ""}` });
}
//#endregion
export { StatusDot as n, VerdictBadge as r, SeverityBadge as t };
