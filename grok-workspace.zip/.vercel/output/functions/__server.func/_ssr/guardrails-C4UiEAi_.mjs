import { i as __toESM } from "../_runtime.mjs";
import { R as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { d as TOOL_LABELS, h as formatTime, n as Badge, v as useSentinai } from "./store-BJrHZyzO.mjs";
import { t as Button } from "./button-DB9ClE7Q.mjs";
import { n as ScenarioCta } from "./router-BAYnTcJM.mjs";
import { n as Panel, t as PageHeader } from "./chrome-CyQP5BSz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/guardrails-C4UiEAi_.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TOOLS = [
	"db.query",
	"http.request",
	"fs.write",
	"mcp.invoke",
	"mail.send"
];
function GuardrailsPage() {
	const run = useSentinai((s) => s.runToolCall);
	const calls = useSentinai((s) => s.toolCalls);
	const allow = useSentinai((s) => s.allow);
	const [tool, setTool] = (0, import_react.useState)("db.query");
	const [statement, setStatement] = (0, import_react.useState)("select * from invoices limit 20");
	const [url, setUrl] = (0, import_react.useState)("https://api.company.com/v1/health");
	const [server, setServer] = (0, import_react.useState)("internal-crm");
	const [mcpTool, setMcpTool] = (0, import_react.useState)("lookup_account");
	const [to, setTo] = (0, import_react.useState)("soc@company.com");
	const [path, setPath] = (0, import_react.useState)("/workspace/out/notes.md");
	const last = calls[0];
	function simulate() {
		if (!allow("guardrail.test")) return;
		run("prompt-testbed", tool, tool === "db.query" ? { statement } : tool === "http.request" ? {
			url,
			method: "GET"
		} : tool === "fs.write" ? {
			path,
			bytes: 420
		} : tool === "mcp.invoke" ? {
			server,
			tool: mcpTool
		} : {
			to,
			subject: "Weekly digest"
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Tool call simulator",
				subtitle: "Real policy engine — verdicts derived from statement content"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
					title: "Prompt testbed",
					subtitle: "Check a prompt against guardrails",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-xs text-muted-foreground",
							children: ["Tool", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								value: tool,
								onChange: (e) => setTool(e.target.value),
								className: "mt-1 h-9 w-full rounded-md border border-input bg-background px-2 text-sm",
								children: TOOLS.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: t,
									children: TOOL_LABELS[t]
								}, t))
							})]
						}),
						tool === "db.query" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							value: statement,
							onChange: (e) => setStatement(e.target.value),
							rows: 4,
							className: "mt-3 w-full rounded-md border border-input bg-background p-2 font-mono text-xs"
						}) : null,
						tool === "http.request" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: url,
							onChange: (e) => setUrl(e.target.value),
							className: "mt-3 h-9 w-full rounded-md border border-input bg-background px-2 text-sm"
						}) : null,
						tool === "fs.write" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: path,
							onChange: (e) => setPath(e.target.value),
							className: "mt-3 h-9 w-full rounded-md border border-input bg-background px-2 text-sm"
						}) : null,
						tool === "mcp.invoke" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 grid gap-2 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: server,
								onChange: (e) => setServer(e.target.value),
								className: "h-9 rounded-md border border-input bg-background px-2 text-sm"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: mcpTool,
								onChange: (e) => setMcpTool(e.target.value),
								className: "h-9 rounded-md border border-input bg-background px-2 text-sm"
							})]
						}) : null,
						tool === "mail.send" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: to,
							onChange: (e) => setTo(e.target.value),
							className: "mt-3 h-9 w-full rounded-md border border-input bg-background px-2 text-sm"
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "mt-3",
							size: "sm",
							disabled: !allow("guardrail.test"),
							onClick: simulate,
							children: "Evaluate"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
					title: "Policy inspector",
					subtitle: "Verdict · matched rule · timestamp",
					children: !last ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScenarioCta, {
						title: "No policy decisions yet",
						body: "Simulate a destructive SQL statement or run the malicious tool-call scenario.",
						scenario: "malicious_tool"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: last.verdict === "denied" ? "destructive" : last.verdict === "approval_required" ? "warning" : "success",
								children: last.verdict.replace("_", " ")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm font-medium",
								children: last.rule
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted-foreground",
							children: last.rationale
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-3 space-y-1 text-xs",
							children: last.checks.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: c.pass ? "text-success" : "text-destructive",
										children: c.pass ? "pass" : "fail"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: c.field
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: c.label })
								]
							}, c.label))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 text-mono-xs text-muted-foreground",
							children: formatTime(last.at)
						})
					] })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "Recent policy decisions",
				subtitle: "Every verdict logged with correct severity",
				children: calls.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Empty until a tool call is evaluated."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "divide-y divide-border/70",
					children: calls.slice(0, 12).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex flex-wrap items-center gap-3 py-2.5 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: c.verdict === "denied" ? "destructive" : c.verdict === "approval_required" ? "warning" : "success",
								children: c.verdict
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex-1 truncate",
								children: c.rule
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-mono-xs text-muted-foreground",
								children: c.agent
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-mono-xs text-muted-foreground",
								children: formatTime(c.at)
							})
						]
					}, c.id))
				})
			})
		]
	});
}
//#endregion
export { GuardrailsPage as component };
