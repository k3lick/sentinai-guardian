import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as ENROLLMENT_CODE, n as Badge, o as IntegrityBanner, p as downloadJson, r as Button, u as Surface, v as useGuardian } from "./button-CkMlNtAY.mjs";
import { t as PageHeader } from "./page-header-CfTViCKd.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-KfvAKDPa.js
var import_jsx_runtime = require_jsx_runtime();
function SettingsPage() {
	const session = useGuardian((s) => s.session);
	const mode = useGuardian((s) => s.mode);
	const setMode = useGuardian((s) => s.setMode);
	const operators = useGuardian((s) => s.operators);
	const signOut = useGuardian((s) => s.signOut);
	const resetDemo = useGuardian((s) => s.resetDemo);
	const simulateTamper = useGuardian((s) => s.simulateTamper);
	const integrityOk = useGuardian((s) => s.integrityOk);
	const audit = useGuardian((s) => s.audit);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "stagger-in space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IntegrityBanner, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: "Settings",
				title: "Console",
				description: "Mode, operators, and controls that exist so you can break the chain on purpose — then see the integrity badge fail."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Surface, {
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium",
						children: "Probe mode"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex w-full max-w-sm rounded-lg border border-border bg-bg p-1",
						children: ["demo", "live"].map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setMode(m),
							className: `h-9 flex-1 rounded-md text-xs font-medium uppercase tracking-wide ${mode === m ? "bg-elevated text-fg" : "text-muted hover:text-fg"}`,
							children: m
						}, m))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-xl text-sm text-pretty text-muted",
						children: "Demo simulates Ollama, LM Studio and vLLM latency. Live asks those local runtimes from this browser; if they are not there, the node is marked offline. Policy and quarantine do not change with the mode."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Surface, {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium",
						children: "This operator"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm",
						children: [
							session?.name,
							" · ",
							session?.role
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-xs text-subtle",
						children: session?.email
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-subtle",
						children: ["Enrollment code for new operators: ", ENROLLMENT_CODE]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						size: "sm",
						onClick: signOut,
						children: "End session"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Surface, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-sm font-medium",
				children: "Operators · dual-control PINs"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 divide-y divide-border",
				children: operators.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex flex-wrap items-center justify-between gap-2 py-2.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm",
						children: [o.name, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-muted",
							children: [" · ", o.role]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-xs text-subtle",
						children: o.email
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-mono text-xs text-muted",
						children: ["PIN ", o.pin]
					})]
				}, o.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Surface, {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium",
						children: "Integrity drills"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-xl text-sm text-pretty text-muted",
						children: "Tamper rewrites a historical canonical payload without updating its hash. The chain cannot be “repaired” — only reset to a fresh genesis."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "danger",
								size: "sm",
								onClick: async () => {
									await simulateTamper();
									toast.error("Chain verification failed");
								},
								disabled: !integrityOk,
								children: "Simulate tamper"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "secondary",
								size: "sm",
								onClick: async () => {
									await resetDemo();
									toast.success("Demo workspace reset");
								},
								children: "Reset demo data"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								size: "sm",
								onClick: () => downloadJson(`sentinai-audit-${Date.now()}.json`, audit),
								children: "Export audit"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: integrityOk ? "ok" : "danger",
						children: integrityOk ? "Chain intact" : "Chain broken"
					})
				]
			})
		]
	});
}
//#endregion
export { SettingsPage as component };
