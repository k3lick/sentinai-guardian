import { i as __toESM } from "../_runtime.mjs";
import { R as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { _ as slaClock, h as formatTime, m as formatDuration, n as Badge, v as useSentinai } from "./store-BJrHZyzO.mjs";
import { t as Button } from "./button-DB9ClE7Q.mjs";
import { n as Panel, t as PageHeader } from "./chrome-CyQP5BSz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/incidents-PGvqP_PN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SEV = {
	sev1: {
		label: "SEV-1 Critical",
		tone: "destructive"
	},
	sev2: {
		label: "SEV-2 High",
		tone: "warning"
	},
	sev3: {
		label: "SEV-3 Medium",
		tone: "muted"
	}
};
var STATUS = {
	open: "Open",
	investigating: "Under Investigation",
	mitigated: "Mitigated",
	resolved: "Resolved"
};
function IncidentsPage() {
	const incidents = useSentinai((s) => s.incidents);
	const sla = useSentinai((s) => s.sla);
	const create = useSentinai((s) => s.createIncident);
	const advance = useSentinai((s) => s.advanceIncident);
	const allow = useSentinai((s) => s.allow);
	const [title, setTitle] = (0, import_react.useState)("");
	const canTriage = allow("incident.triage");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Incidents",
			subtitle: `${incidents.length} total · click status to advance`,
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex flex-wrap gap-2",
				onSubmit: (e) => {
					e.preventDefault();
					if (!canTriage || !title.trim()) return;
					create({
						title: title.trim(),
						severity: "sev3",
						status: "open",
						assignee: "Unassigned"
					});
					setTitle("");
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: title,
					onChange: (e) => setTitle(e.target.value),
					placeholder: "Create incident",
					className: "h-9 w-56 rounded-md border border-input bg-background px-2 text-sm"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					disabled: !canTriage,
					children: "Create"
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-3",
			children: incidents.map((inc) => {
				const clock = slaClock(sla, "incident", inc.createdAt, inc.severity);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
					title: inc.id,
					subtitle: inc.title,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: SEV[inc.severity].tone,
									children: SEV[inc.severity].label
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									variant: "outline",
									disabled: !canTriage,
									onClick: () => advance(inc.id),
									children: [STATUS[inc.status], " · Advance status"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-muted-foreground",
									children: inc.assignee
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ml-auto text-mono-xs text-muted-foreground",
									children: formatTime(inc.createdAt)
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between text-mono-xs text-muted-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									"SLA ",
									clock.minutes,
									"m"
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: clock.breached ? "breached" : `${formatDuration(clock.remainingMs)} remaining` })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1 h-1.5 overflow-hidden rounded-full bg-muted",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `h-full ${clock.breached ? "bg-destructive" : clock.tier >= 2 ? "bg-warning" : "bg-success"}`,
									style: { width: `${clock.pct}%` }
								})
							})]
						}),
						inc.notes.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-3 space-y-1 text-xs text-muted-foreground",
							children: inc.notes.map((n, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
								n.actor,
								": ",
								n.body
							] }, i))
						}) : null
					]
				}, inc.id);
			})
		})]
	});
}
//#endregion
export { IncidentsPage as component };
