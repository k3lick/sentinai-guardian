import { R as require_jsx_runtime, v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { g as percentile, h as formatTime, v as useSentinai } from "./store-BJrHZyzO.mjs";
import { t as Button } from "./button-DB9ClE7Q.mjs";
import { m as FileWarning, o as ShieldAlert, p as Gauge, y as Activity } from "../_libs/lucide-react.mjs";
import { n as ScenarioCta } from "./router-BAYnTcJM.mjs";
import { i as StatusBadge, n as Panel, r as StatCard, t as PageHeader } from "./chrome-CyQP5BSz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Dd2_RV0X.js
var import_jsx_runtime = require_jsx_runtime();
var SEV_COLOR = {
	critical: "var(--color-destructive)",
	high: "var(--color-warning)",
	medium: "var(--color-chart-1)",
	low: "var(--color-success)"
};
function Overview() {
	const endpoints = useSentinai((s) => s.endpoints);
	const documents = useSentinai((s) => s.documents);
	const audit = useSentinai((s) => s.audit);
	const incidents = useSentinai((s) => s.incidents);
	const healthy = endpoints.filter((e) => e.status === "healthy").length;
	const degraded = endpoints.filter((e) => e.status === "degraded" || e.status === "offline").length;
	const availability = endpoints.length ? Math.round(endpoints.reduce((sum, e) => sum + (e.totalRequests - e.failedRequests), 0) / Math.max(1, endpoints.reduce((sum, e) => sum + e.totalRequests, 0)) * 100) : 0;
	const avgP95 = Math.round(endpoints.reduce((sum, e) => sum + (percentile(e.latencies, 95) ?? 0), 0) / Math.max(1, endpoints.length));
	const quarantined = documents.filter((d) => d.status === "quarantined");
	const released = documents.filter((d) => d.status === "released" || d.status === "false_positive");
	const releaseRate = documents.length ? Math.round(released.length / Math.max(1, released.length + quarantined.length) * 100) : 0;
	const findings = documents.flatMap((d) => d.findings);
	const dist = [
		"critical",
		"high",
		"medium",
		"low"
	].map((sev) => ({
		sev,
		count: findings.filter((f) => f.severity === sev).length
	}));
	const total = Math.max(1, dist.reduce((s, d) => s + d.count, 0));
	let offset = 0;
	const slices = dist.map((d) => {
		const pct = d.count / total * 100;
		const slice = {
			...d,
			pct,
			offset
		};
		offset += pct;
		return slice;
	});
	const stream = audit.filter((e) => e.category !== "scan").slice(0, 8);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Security operations overview",
				subtitle: "Cross-system posture across inference fleet, document pipeline, and policy enforcement."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2 xl:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Fleet availability",
						value: `${availability}%`,
						hint: `${healthy} healthy · ${degraded} degraded/offline · avg p95 ${avgP95 || "—"}ms`,
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gauge, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Quarantine volume",
						value: quarantined.length,
						hint: `${quarantined.length} pending review · ${releaseRate}% release rate`,
						tone: "destructive",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileWarning, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Scan findings",
						value: findings.length,
						hint: `${dist[0]?.count ?? 0} critical across ${documents.length} documents`,
						tone: "warning",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Open incidents",
						value: incidents.filter((i) => i.status !== "resolved").length,
						hint: `${incidents.length} total tracked`,
						tone: "primary",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Activity, { className: "size-4" })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
					title: "Severity distribution",
					subtitle: "All active scan findings",
					className: "lg:col-span-1",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-1 flex items-center gap-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-32 shrink-0 rounded-full",
							style: {
								background: `conic-gradient(${slices.map((s) => `${SEV_COLOR[s.sev]} ${s.offset}% ${s.offset + s.pct}%`).join(", ")})`,
								mask: "radial-gradient(circle, transparent 54%, black 55%)",
								WebkitMask: "radial-gradient(circle, transparent 54%, black 55%)"
							}
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "w-full space-y-2 text-sm",
							children: dist.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "size-2.5 rounded-sm",
										style: { background: SEV_COLOR[d.sev] }
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "capitalize text-muted-foreground",
										children: d.sev
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "ml-auto font-mono tabular",
										children: d.count
									})
								]
							}, d.sev))
						})]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
					title: "Model fleet",
					subtitle: "Live endpoint health and latency",
					className: "lg:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-2",
						children: endpoints.map((ep) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-3 rounded-lg border border-border/70 bg-background/40 px-3 py-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: ep.status }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-medium",
									children: ep.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-mono-xs text-muted-foreground",
									children: ep.model
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "ml-auto text-mono-xs text-muted-foreground",
									children: [
										"p50 ",
										percentile(ep.latencies, 50) ?? "—",
										"ms · p95 ",
										percentile(ep.latencies, 95) ?? "—",
										"ms ·",
										" ",
										ep.tokensPerSec ? `${ep.tokensPerSec.toFixed(0)} tok/s` : "no tokens"
									]
								})
							]
						}, ep.id))
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								size: "sm",
								variant: "outline",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/models",
									children: "Orchestration console"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								size: "sm",
								variant: "outline",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/documents",
									children: "Documents"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								size: "sm",
								variant: "outline",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/audit",
									children: "Audit log"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								size: "sm",
								variant: "outline",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/guardrails",
									children: "Policies"
								})
							})
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				title: "Live security & access-control stream",
				subtitle: "Role changes, blocked actions, policy decisions",
				children: [stream.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScenarioCta, {
					title: "No access-control activity recorded yet",
					body: "Scenarios drive real quarantine decisions, policy verdicts and role events straight into this stream.",
					scenario: "credential_leak"
				}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 divide-y divide-border/70",
					children: stream.map((ev) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex flex-wrap items-center gap-3 py-2.5 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-md border border-border px-1.5 py-0.5 text-mono-xs uppercase text-muted-foreground",
								children: ev.action
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "min-w-0 flex-1 truncate",
								children: ev.message
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-mono-xs text-muted-foreground",
								children: formatTime(ev.at)
							})
						]
					}, ev.id))
				})]
			})
		]
	});
}
//#endregion
export { Overview as component };
