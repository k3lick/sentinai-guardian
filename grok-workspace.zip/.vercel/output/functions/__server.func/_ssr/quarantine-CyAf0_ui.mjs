import { i as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, z as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as EmptyState, m as formatAgo, n as Badge, o as IntegrityBanner, r as Button, u as Surface, v as useGuardian } from "./button-CkMlNtAY.mjs";
import { t as PageHeader } from "./page-header-CfTViCKd.mjs";
import { t as SeverityBadge } from "./verdict-LAWMSaCb.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as Input, r as Label } from "./router-pRE2o39U.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/quarantine-CyAf0_ui.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DualDots({ doc }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2 text-xs text-muted",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `size-2 rounded-full ${doc.firstAuth ? "bg-ok" : "bg-subtle"}` }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: doc.firstAuth ? doc.firstAuth.name : "First signature" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-subtle",
				children: "→"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `size-2 rounded-full ${doc.secondAuth ? "bg-ok" : "bg-subtle"}` }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: doc.secondAuth ? doc.secondAuth.name : "Countersign" })
		]
	});
}
function QuarantinePage() {
	const documents = useGuardian((s) => s.documents);
	const operators = useGuardian((s) => s.operators);
	const session = useGuardian((s) => s.session);
	const signFirst = useGuardian((s) => s.signFirst);
	const signSecond = useGuardian((s) => s.signSecond);
	const held = documents.filter((d) => d.status !== "clean");
	const [active, setActive] = (0, import_react.useState)(null);
	const [opId, setOpId] = (0, import_react.useState)(operators.find((o) => o.id !== session?.operatorId)?.id ?? "");
	const [pin, setPin] = (0, import_react.useState)("");
	const [err, setErr] = (0, import_react.useState)(null);
	const doc = (0, import_react.useMemo)(() => documents.find((d) => d.id === active) ?? null, [documents, active]);
	async function first(id) {
		const msg = await signFirst(id);
		if (msg) toast.error(msg);
		else toast.success("First signature recorded");
	}
	async function second() {
		if (!doc) return;
		const msg = await signSecond(doc.id, opId, pin);
		if (msg) {
			setErr(msg);
			return;
		}
		toast.success("Released under 4-eyes");
		setActive(null);
		setPin("");
		setErr(null);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "stagger-in space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IntegrityBanner, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: "Quarantine",
				title: "Four-eyes release",
				description: "Held documents require two distinct operators. The second signature is PIN-gated and written to the hash chain."
			}),
			held.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Surface, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "Nothing held",
				body: "Scan a document with live keys or PII, or run the credential-leak scenario from Overview."
			}) }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3",
				children: held.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Surface, {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "font-mono text-sm",
										children: d.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										tone: d.status === "released" ? "ok" : d.status === "awaiting-second" ? "warn" : "danger",
										children: d.status.replace("-", " ")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "tabular text-xs text-muted",
										children: ["risk ", d.riskScore]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs text-subtle",
								children: formatAgo(d.ts)
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap gap-2",
								children: [d.status === "quarantined" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									onClick: () => first(d.id),
									children: "Sign as first"
								}) : null, d.status === "awaiting-second" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									onClick: () => setActive(d.id),
									children: "Countersign"
								}) : null]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DualDots, { doc: d }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "flex flex-wrap gap-1.5",
							children: d.findings.slice(0, 6).map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SeverityBadge, { severity: f.severity }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-1 text-xs text-muted",
								children: f.label
							})] }, f.id))
						})
					]
				}, d.id))
			}),
			doc ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-50 flex items-end justify-center sm:items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "absolute inset-0 bg-bg/70",
					"aria-label": "Dismiss",
					onClick: () => setActive(null)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative m-4 w-full max-w-md rounded-xl border border-border bg-surface p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
							className: "text-base font-medium",
							children: ["Countersign ", doc.name]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-muted",
							children: [
								"First signature: ",
								doc.firstAuth?.name,
								". Choose a different operator and enter their PIN."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "op",
										children: "Second operator"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
										id: "op",
										value: opId,
										onChange: (e) => setOpId(e.target.value),
										className: "h-11 w-full rounded-md border border-border bg-bg px-3 text-sm text-fg outline-none focus:ring-2 focus:ring-accent/25",
										children: operators.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
											value: o.id,
											children: [
												o.name,
												" · ",
												o.role
											]
										}, o.id))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											htmlFor: "pin",
											children: "PIN"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											id: "pin",
											inputMode: "numeric",
											value: pin,
											onChange: (e) => setPin(e.target.value),
											placeholder: "Four digits"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-subtle",
											children: "Demo PINs — Maya 2210 · Jordan 4821 · Samira 7730"
										})
									]
								}),
								err ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-danger",
									children: err
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-end gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "ghost",
										size: "sm",
										onClick: () => setActive(null),
										children: "Cancel"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										onClick: second,
										children: "Release document"
									})]
								})
							]
						})
					]
				})]
			}) : null
		]
	});
}
//#endregion
export { QuarantinePage as component };
