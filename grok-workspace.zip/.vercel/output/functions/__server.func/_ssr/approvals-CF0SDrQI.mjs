import { R as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { h as formatTime, i as PERMISSION_LABELS, l as SOD_ACTIONS, n as Badge, o as ROLES, s as ROLE_PERMISSIONS, v as useSentinai } from "./store-BJrHZyzO.mjs";
import { t as Button } from "./button-DB9ClE7Q.mjs";
import { n as ScenarioCta } from "./router-BAYnTcJM.mjs";
import { n as Panel, t as PageHeader } from "./chrome-CyQP5BSz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/approvals-CF0SDrQI.js
var import_jsx_runtime = require_jsx_runtime();
function ApprovalsPage() {
	const approvals = useSentinai((s) => s.approvals);
	const resolve = useSentinai((s) => s.resolveApproval);
	const dual = useSentinai((s) => s.dualControl);
	const toggle = useSentinai((s) => s.toggleDualControl);
	const allow = useSentinai((s) => s.allow);
	const pending = approvals.filter((a) => a.status === "pending");
	const resolved = approvals.filter((a) => a.status !== "pending");
	const canSign = allow("approval.countersign");
	const roles = Object.keys(ROLES);
	const perms = Object.keys(PERMISSION_LABELS);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Pending human approvals",
				subtitle: "Bulk exfiltration & high-risk actions escalated for review"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, { children: pending.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScenarioCta, {
				title: "No pending approvals",
				body: "High-risk MCP exports and mutating egress land here. Run the malicious tool-call scenario to generate one.",
				scenario: "malicious_tool"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: pending.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-lg border border-border bg-background/40 p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm font-medium",
							children: a.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: a.detail
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex flex-wrap gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									disabled: !canSign,
									onClick: () => resolve(a.id, "approved"),
									children: "Approve — allow to take effect"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "outline",
									disabled: !canSign,
									onClick: () => resolve(a.id, "rejected"),
									children: "Reject — block"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-mono-xs text-muted-foreground",
									children: a.requestedBy
								})
							]
						})
					]
				}, a.id))
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "Resolved approvals",
				subtitle: "Signed-off or rejected decisions (take effect on sign-off)",
				children: resolved.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "None yet."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "divide-y divide-border/70",
					children: resolved.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex flex-wrap items-center gap-3 py-2 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: a.status === "approved" ? "success" : "destructive",
								children: a.status
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex-1",
								children: a.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-mono-xs text-muted-foreground",
								children: a.resolvedBy
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-mono-xs text-muted-foreground",
								children: a.resolvedAt ? formatTime(a.resolvedAt) : ""
							})
						]
					}, a.id))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				title: "Segregation of duties matrix",
				subtitle: "Which role may perform which action",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-4 flex flex-wrap gap-3",
						children: SOD_ACTIONS.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-center gap-2 text-xs",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									checked: dual[a.id],
									onChange: () => toggle(a.id)
								}),
								"Dual control · ",
								a.label
							]
						}, a.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full min-w-[720px] text-left text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-b border-border text-muted-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 pr-2 font-medium",
									children: "Permission"
								}), roles.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-1 py-2 font-medium",
									children: ROLES[r].short
								}, r))]
							}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: perms.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-b border-border/60",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-1.5 pr-2",
									children: PERMISSION_LABELS[p]
								}), roles.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-1 py-1.5 text-center",
									children: ROLE_PERMISSIONS[r].includes(p) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-success",
										children: "yes"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: "—"
									})
								}, r))]
							}, p)) })]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-xs text-muted-foreground",
						children: "A reviewer who adjudicates quarantined content must not also administer models or endpoints. Purge authorization stays independent of the platform team."
					})
				]
			})
		]
	});
}
//#endregion
export { ApprovalsPage as component };
