# SentinAI — Compliance-First Agent Security Platform

Source code of the verified SentinAI app (the Base44 version, not the broken
Lovable prototype). React 18 + Vite + Tailwind, zero backend required —
persistence runs on a swappable storage adapter (localStorage by default).

## Quick start

```bash
npm install
npm run dev        # http://localhost:5173
npm run build      # production bundle in dist/
```

First run: sign up with any email. The verification code is displayed in the
dev banner on the auth screen (`659314`). Log out and back in with the same
credentials afterwards.

## What works (verified against the live app)

1. **Real guardrail engine** (`src/lib/engine.js`) — content-based verdicts:
   - `DROP TABLE customers;` → **DENIED** (DB-001 · Destructive statement blocked, HIGH)
   - `DELETE FROM users;` → **DENIED** (DB-001, HIGH)
   - `SELECT * FROM orders WHERE ...;` → **ALLOWED** (DB-000 · Read-only query, LOW)
   - `SELECT * FROM crm.contacts LIMIT 50000` → **HUMAN APPROVAL** (DB-020 · Bulk exfiltration risk, MEDIUM)
   - PII projection without a limit → **HUMAN APPROVAL** (DB-030)
   - Prompt injection (`ignore previous instructions...`) → **DENIED** (PR-001)
   - Unrecognized statements are never silently allowed — they escalate (DB-900).
2. **Persistence** (`src/lib/db.js`) — every evaluation fans out to three
   collections: `PolicyDecision`, `SIEM event`, and `AuditLog`. Reload the app:
   everything is still there.
3. **Accurate metrics** — Overview numbers are computed from the records
   (fleet availability, quarantine volume, findings, incidents, verdict counts).
   Nothing is hardcoded.
4. **Tamper-evident audit chain** — each audit record hashes the previous
   record's hash. The sidebar shows live chain integrity; edit a record in
   localStorage and it flips to TAMPERED.
5. **Auth gate** — signup → email-code verification → session, mirroring the
   live app's flow.

## Layout

```
src/
  lib/engine.js      guardrail / policy engine (pure, unit-testable)
  lib/db.js          persistence, hash chain, metrics, seed data
  auth/AuthGate.jsx  signup / verification / login
  components/        Sidebar + shared UI primitives
  pages/             Overview, Guardrails, Documents, Incidents,
                     Model Registry, Audit Log, SIEM Streaming, + light sections
```

## Going to production

- Swap the storage adapter in `lib/db.js` (`setAdapter`) for a REST client;
  collections already mirror the entity shapes used by the Base44 app.
- Replace the simulated verification code with an email provider.
- Use SHA-256 (`crypto.subtle`) for the audit chain instead of FNV-1a.
- Add per-user record scoping (`createdBy`) enforcement on the server.

## Lovable prototype vs. this app

| Area | Lovable prototype | This app |
|---|---|---|
| `DROP TABLE` verdict | HUMAN APPROVAL (DB-014 PII review — wrong rule) | DENIED, DB-001, HIGH |
| Persistence | none (counters reset) | all verdicts/audits/SIEM stored |
| Metrics | hardcoded (96% availability with 0 healthy nodes) | computed from records |
| Auth | none | signup/verification/login |
